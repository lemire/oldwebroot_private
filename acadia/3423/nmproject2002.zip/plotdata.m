function plotdata(long,lat,data)

global landvalue

array=find(data ~= landvalue);
maxdata=max(data(array));
mindata=min(data(array));
conts=mindata:(maxdata-mindata)/20:maxdata;
%contourf(long,lat,data,conts);colorbar

m_proj('stereographic','lat',-90,'long',30,'radius',60);
[h c]=m_contourf(long,lat,data,conts);
shading flat
m_grid('xtick',12,'xticklabels','','tickdir','out','xlabels','off','ytick',[-70 -60 -50 -40],'yticklabels','','linest','-');
m_coast('patch',[0 0 0],'edgecolor','k');
colorbar
