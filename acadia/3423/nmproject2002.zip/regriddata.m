addpath matlabmaps/MATLAB
warning off

global landvalue

%set value that represents land
landvalue=-9.9999e19;

%read in current data and grid from one of the data file

%this data file has the mean sea surface height 
%[longh lath data]=readdata('meansshMIT.tsv');

%this data file has the root mean square variance of the sea surface height
%[longh lath data]=readdata('newssha.tsv');

%this data file has the mean zonal wind stress (matlab works for this one)
[longh lath data]=readdata('taux.tsv');

%plot the data
plotdata(longh,lath,data)

pause

% form new grid
long=(0.5:1:359.5)'*ones(1,42);
lat=ones(360,1)*(-70.5:1:-29.5);

figure
plot(longh, lath, 'or')
hold
plot(long, lat, '+b')
hold
axis([100 110 -50 -40]) 

pause

%get data on the new grid
newdata=griddata(longh,lath,data,long,lat,'linear');

%plot data on new grid
figure
plotdata(long,lat,newdata)


