%Math 3423 - Numerical Method 2
%Assignment 3 Question 2.1 - 2
%A function that implement find the upper left point with modulo

function [x, y] = matchmoduloupperleft(xarray, yarray, xtarget, ytarget, modulo)

x = [];
y = [];
%find all possible upper right points
[xtarpos, ytarpos] = find(xarray <= xtarget & xarray > xtarget - modulo ...
                          & yarray >= ytarget & yarray < ytarget + modulo);

x = xarray(xtarpos, ytarpos);
y = yarray(xtarpos, ytarpos);
          