%Math 3423 - Numerical Method 2
%Assignment 3 Question 2.1 - 2
%A function that implement find the lower left point

function [x, y] = matchlowerleft(xarray, yarray, xtarget, ytarget)

x = [];
y = [];

%find all possible lower left points
[xtarpos, ytarpos] = find(xarray <= xtarget & yarray <= ytarget);

mindistance = Inf;
[rowSize, colSize] = size(xtarpos);

for i = 1:rowSize
    for j = 1:colSize
        dis = distance(xarray(xtarpos(i, j), ytarpos(i, j)), yarray(xtarpos(i, j), ytarpos(i, j)),...
                       xtarget, ytarget);
        if (dis <= mindistance)
            x = xarray(xtarpos(i, j), ytarpos(i, j));
            y = yarray(xtarpos(i, j), ytarpos(i, j));
            mindistance = dis;
        end
    end
end

