%Math 3423 - Numerical Method 2
%Assignment 3 Question 2.1 - 2
%A function that implement find the lower right point with modulo

function [x, y] = matchmodulolowerright(xarray, yarray, xtarget, ytarget, modulo)

x = [];
y = [];
%find all possible lower right points
[xtarpos, ytarpos] = find(xarray >= xtarget & xarray < xtarget + modulo ...
                          & yarray <= ytarget & yarray > ytarget - modulo);

x = xarray(xtarpos, ytarpos);
y = yarray(xtarpos, ytarpos);

