%MATH3423 - Numerical Methods 2
%Assignment 2 Question 2.1 1
%A linear interpolation over the three data points (x1, y1, z1),...(x3, y3, z3)


function z = mylininterp(x1, y1, z1, x2, y2, z2, x3, y3, z3, x, y)

if ((x2 - x1) * y3 + (x1 - x3)* y2 + (x3 - x2) * y1 == 0)
    point1 = [x1, y1];
    point2 = [x2, y2];
    point3 = [x3, y3];
    posi = ((point2 - point1) / norm(point2 - point1)) .* [x, y] + point1;
    d1 = norm(point1 - posi);
    d2 = norm(point2 - posi);
    d3 = norm(point3 - posi);
    z = (z1*(d2 + d3 - d1) + z2*(d1 + d3 - d2) + z3*(d1 + d2 - d3)) / (d1 + d2 + d3);
    
else
    z = (((x1 - x) * y2 + (x - x2) * y1 + (x2 - x1) * y) * z3 + ...
        ((x - x1) * y3 + (x3 - x) * y1 + (x1 - x3) * y) * z2 + ...
        ((x2 - x) * y3 + (x - x3) * y2 + (x3 - x2) * y) * z1 ) / ...
        ((x2 - x1) * y3 + (x1 - x3) * y2 + (x3 - x2) * y1);
end
