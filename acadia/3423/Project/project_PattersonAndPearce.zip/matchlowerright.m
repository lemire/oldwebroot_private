function ans = matchlowerright(xarray, yarray, xtarget, ytarget)
%Finds the index in xarray and yarray such that
%it is as close as possible to xtarget and ytarget and
%xarray[index] is >= xtarget
%yarray[index] is <= ytarget
%returns -1 for an index that is non existant

lenx = size(xarray,1)*size(xarray,2);
leny = size(yarray,1)*size(yarray,2);
index=-1;

if lenx > 0 & lenx==leny
    dif = inf;
    for i = 1:lenx
        if  xtarget <= xarray(i) & ytarget >= yarray(i)
            if sqrt((xtarget - xarray(i))^2+(ytarget - yarray(i))^2) <= dif
                index = i;
                dif = sqrt((xtarget - xarray(i))^2+(ytarget - yarray(i))^2);
            end
        end
    end
end

ans = index;