Assignment 3
Murray Patterson
Mark Pearce
Numerical Methods 2
Dr. Lemire
March 18/2002


Contents:

interp.m   // the 3 point interpolating function
matchlowerleft.m   // closest point functions
matchupperleft.m
matchlowerright.m
matchupperright.m
matchmodulolowerleft.m   // closest point modulo functions
matchmoduloupperleft.m
matchmodulolowerright.m
matchmoduloupperright.m
karsten.m   // our main function that regrids the data
plotdata.m   // Dr. Karsten's plotter
readdata.m   // Dr. Karsten's file reader
regriddata.m   // Dr. Karsten's regridder (we modified this and put
	       // our own regridding function in it)
readme.txt   // you're reading me!  hehe


Thoughts/Conclusions:

The main reason I think that the interpolant that Dr. Karsten was trying to get didn't work is because the land values propagated so much.  Land values are so small, that any high order interpolant would feel the affects at distances far away from this land.  The interpolant that we use is linear, so the affects of one area are not felt in any area at all (error can't really propagate that well, and land can't spread).  Despite this, the interpolant still highly discourages the spreading of land by giving non-land values a high priority over land when it comes to interpolating.

This program takes a long time to run!  We never actually had time to run a full test, but we're pretty sure it works.  Your desktop can probably spit out the answer pretty quickly, but these laptops couln't handle it in any decent amount of time.  Enjoy!