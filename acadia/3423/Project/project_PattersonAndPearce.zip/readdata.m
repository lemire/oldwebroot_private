function [longxy,latxy,dataxy]=readdata(filename)

global landvalue

fid=fopen(filename,'r');

temp=fgetl(fid);

temp=fgetl(fid);

[temp count]=fscanf(fid,'%g %g %g',[3 inf]);

long=temp(1,:);
lat=temp(2,:);
data=temp(3,:);

maxlong=max(long);
minlong=min(long);
maxlat=max(lat);
minlat=min(lat);
minlat2=min(lat(find(lat>minlat)));

gridlong=abs(long(2)-long(1));
n=round((maxlong-minlong)/gridlong+1);
gridlat=minlat2-minlat;
m=round((maxlat-minlat)/gridlat+1);

longxy=zeros(n,m);
latxy=zeros(n,m);
dataxy=ones(n,m)*landvalue;
for i=1:n
for j=1:m
longxy(i,j)=minlong+(i-1)*gridlong;
latxy(i,j)=minlat+(j-1)*gridlat;
end
end

for k=1:count/3
i=round((long(k)-minlong)/gridlong+1);
j=round((lat(k)-minlat)/gridlat+1);
dataxy(i,j)=data(k);
end

fclose(fid);




