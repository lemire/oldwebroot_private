function ans = matchmodulolowerleft(xarray, yarray, xtarget, ytarget, modval)
%Finds the indexes in xarray and yarray such that
%it is as close as possible to xtarget and ytarget and
%xarray[index] is <= mod(xtarget, modval) + (0 or modval, depending on the situation)
%yarray[index] is <= ytarget
%returns -1 for an index that is non existant

% try to find a lower left value
ans1 = matchlowerleft(xarray, yarray, mod(xtarget,modval), ytarget);

if ans1 == -1 & length(xarray) > 0
% if we can't, we wrap around the globe to find one in the <= 360 zone (instead of the >= 0 zone)
    ans1 = matchlowerleft(xarray, yarray, xtarget + modval, ytarget);
end

ans = ans1;