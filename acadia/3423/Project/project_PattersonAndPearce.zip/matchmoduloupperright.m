function ans = matchmoduloupperright(xarray, yarray, xtarget, ytarget, modval)
%Finds the indexes in xarray and yarray such that
%it is as close as possible to xtarget and ytarget and
%xarray[index] is >= mod(xtarget, modval) + (0 or modval, depending on the situation)
%yarray[index] is >= ytarget
%returns -1 for an index that is non existant

ans1 = matchupperright(xarray, yarray, mod(xtarget,modval), ytarget);

if ans1 == -1 & length(xarray) > 0
    ans1 = matchupperright(xarray, yarray, mod(xtarget,modval) - modval, ytarget);
end

ans = ans1;