% linearly interpolates 3 distinct data points of a function of the form f(x,y) by evaluating the
% equation of the plane that runs through the points (x1, y1, z1), (x2, y2, z2), (x3, y3, z3) at the
% value (x,y).  Also handles cases where there are only 2 and 1 distinct points

function interp = f(x1,y1,z1,x2,y2,z2,x3,y3,z3,x,y)

if((x1 == x2) & (y1 == y2) & (x2 == x3) & (y2 == y3))
% handle the case where there is only 1 distinct point (just give the value at that point)
    interp = z1;
else
    if((x1 == x2) & (y1 == y2))
    % handle first case where there is only 2 distinct points, (x1, y1) = (x2, y2)
        h = ((x3 - x1)^2 + (y3 - y1)^2)^(1/2);   % d(n0, n1)
        deltaZ = z3 - z1;   % change in height b/w the two distinct points
        slope = deltaZ/h;   % slope in going from n0 to n1: (y1 - y0)/d(n0, n1)
        deltaH = ((x1 - x)^2 + (y1 - y)^2)^(1/2);   % d(n0, x)
        interp = z1 + deltaH*slope;   % y0 + d(n0, x)*(y1 - y0)/d(n0, n1)
    else
        if((x1 == x3) & (y1 == y3))
        % handle second case where there is only 2 distinct points, (x1, y1) = (x3, y3)
            h = ((x2 - x1)^2 + (y2 - y1)^2)^(1/2);
            deltaZ = z2 - z1;
            slope = deltaZ/h;
            deltaH = ((x1 - x)^2 + (y1 - y)^2)^(1/2);
            interp = z1 + deltaH*slope;
        else
            if((x2 == x3) & (y2 == y3))
            % handle third case where there is only 2 distinct points, (x2, y2) = (x3, y3)
            % we handle this in the same way we handle the first case of 2 distinct points,
            % but I thought I'd handle it separately anyway
                h = ((x3 - x1)^2 + (y3 - y1)^2)^(1/2);
                deltaZ = z3 - z1;
                slope = deltaZ/h;
                deltaH = ((x1 - x)^2 + (y1 - y)^2)^(1/2);
                interp = z1 + deltaH*slope;
            else
            % otherwise, interpolate as per the 3 point linear interpolation formula
                interp = (((x1 - x)*y2 + (x - x2)*y1 + (x2 - x1)*y)*z3 + ((x - x1)*y3 + (x3 - x)*y1 + (x1 - x3)*y)*z2 + ((x2 - x)*y3 + (x - x3)*y2 + (x3 - x2)*y)*z1)/((x2 - x1)*y3 + (x1 - x3)*y2 + (x3 - x2)*y1);
            end
        end
    end
end