function newData = karsten(long, lat, data, longtarget, lattarget, modval)
%Solves the "Karsten Problem" -- Hopefully!

%where:
%long: array of longitudes modulo some fixed number
%lat: array of latitudes
%data: array of data, with data(i) the data for lat(i) at long(i)
%longtarget: array of longitudes, with unknown data
%lattarget: array of latitudes, with unknown data

%To use this, take a bunch of known data points and fit it to the grid
%of targets.

global landvalue;   % this function knows what a land value is as well

% test to see if the lengths of long, lat, and data arrays are all the same

sizeLong = size(long,1)*size(long,2);
sizeLat = size(lat,1)*size(lat,2);
sizeData = size(data,1)*size(data,2);

if((sizeLong ~= sizeLat) | (sizeLat ~= sizeData))
    'array lengths do not agree'
end

% test to see if the lengths of longtarget and lattarget are all the same

sizeLongT = size(longtarget,1)*size(longtarget,2);
sizeLatT = size(lattarget,1)*size(lattarget,2);

if(sizeLongT ~= sizeLatT)
    'array lengths do not agree'
end

% get the lengths of the arrays

lenOldData = sizeLong;   % the length of the arrays of old data (long, lat, and data)
lenNewData = sizeLongT;   % the length of the arrays of new data (longtarget and lattarget)
newData = zeros(size(longtarget,1), size(longtarget,2));   % allocate memory for the new data array to same size as longtarget

% now the big part:
% we go through the whole set of new data points, interpolating sets of points around it to get
% a new array of data for each (longtarget, lattarget) pair

for i = 1:lenNewData

    % find the 4 closest points around a target point (lowerleft, upperleft . . . etc.)
    point(1) = matchmodulolowerleft(long, lat, longtarget(i), lattarget(i), modval);
    point(2) = matchmoduloupperleft(long, lat, longtarget(i), lattarget(i), modval);
    point(3) = matchmodulolowerright(long, lat, longtarget(i), lattarget(i), modval);
    point(4) = matchmoduloupperright(long, lat, longtarget(i), lattarget(i), modval);
    
    % in getting each point, one of 3 cases has happened, 1) the point is an index of a value that
    % is somewhat close to the rest of the data, 2) the point is an index of a land value (a very
    % largely negative value), or 3) the point is the index of a failed search (a boundary value, or
    % some other pathological case (ie the index is -1))
    
    % what we want to do here, is modify the point so that if it is an index of a land value, we
    % give that point an index of -2 (land values are all the same largely negative number anyway)

    for j = 1:4
        if((point(j) > 0) & (data(point(j)) == landvalue))
            point(j) = -2;   % go through all points setting to -2 if index is of a land value
        end
    end
    
    % now we have 1) indexes of a "normal" value, 2) indexes of -2 (land values), and 3) indexes
    % of -1 (boundary values/pathological cases)

    % special case: if all 4 points are negative, and at least one is a -2, then we set the target's
    % value to that of land.  if all 4 points are -1 then we set the target's value to 0 (a sloppy
    % estimate for an average value).  if just one value is not negative, then we go on with the
    % interpolation . . . this algorithm is very much against the spreading of land
    
    allLessThanZero = 1;   % assume that all points are less than zero
    
    for j = 1:4   % go through the 4 points
        if(point(j) > 0)
            allLessThanZero = 0;   % if we find an exception, all points are not less than zero
        end
    end
    
    if(allLessThanZero)
        notOnePtLand = 1;   % assume that all points are -1 (boundary values, not land values)
        for j = 1:4   % go through the 4 points
            if(point(j) == -2)
                notOnePtLand = 0;   % if we find an exception, at least one point is a land value
            end
        end
        if(notOnePtLand)
        % if all neighbouring points are -1, set the new data point to 0
            newData(i) = 0;
        else
        % else, at least one point is land, so we set the new data point to land
            newData(i) = landvalue;
        end
    else
    % else: we have something other than boundary and land values to go by, so we interpolate
    % all we need is one other value other than a land value, and we won't even consider land, as
    % a "normal" value is way more important than a land value (or boundary value)
    
        for j = 1:4   % go through the 4 points, getting each distance of that point from target
            if(point(j) > 0)
                distance(j) = ((long(point(j)) - longtarget(i))^2 + (lat(point(j)) - lattarget(i))^2)^(1/2);
            else
                distance(j) = -1;
            end
        end
        
        fourDist = 1;   % assume that there are 4 points that we can go by (need to throw one out)
        for j = 1:4   % go through the 4 points (and corresponding distances)
            if(distance(j) == -1)
                fourDist = 0;   % if we find a distance = -1, then there are not 4 distances to go by
            end
        end
        
        if(fourDist)   % we have four distances, we must throw the largest one out
            dist = 0;   % a distance to start by
            ind = 0;   % an index to start by
            for j = 1:4
                if(distance(j) >= dist)
                    ind = j;   % update the index
                    dist = distance(j);   % update the distance
                end
            end
            
            % we now have the index of largest distance
            distance(ind) = -1;   % set this distance to -1 (thus throwing it out)
        end
        
        % at this point in the game, we have at most 3 points, at least 1 point to interpolate
        % since our interpolating function can deal with all of the above situations, we're in
        % good shape

        index1 = -1;   % these are the 3 indexes that will be used to get the data points that we
        index2 = -1;   % want to interpolate (note that it doesn't matter if any or all are
        index3 = -1;   % duplicates, as the interp function will take care of that)

        count = 0;   % counter counts how many indices have been already assigned
        
        if(distance(1) > 0)   % test first distance
            index1 = point(1);   % if it's good, assign and increment
            count = count + 1;
        end
        if(distance(2) > 0)   % test second distance
            if(count == 0)   % if it's good, see if first has been assigned yet
                index1 = point(2);   % if it hasn't, set index1 to point two and increment
                count = count + 1;   % . . . etc.
            end
            index2 = point(2);   % else count = 1, set index2 to point two and increment
            count = count + 1;
        end
        if(distance(3) > 0)   % test third distance
            if(count == 0)
                index1 = point(3);
                count = count + 1;
            end
            if(count == 1)
                index2 = point(3);
                count = count + 1;
            end
            index3 = point(3);
            count = count + 1;
        end
        if(distance(4) > 0)   % test fourth distance
            if(count == 0)
                index1 = point(4);
                index2 = point(4);
                index3 = point(4);
                count = count + 3;
            end
            if(count == 1)
                index2 = point(4);
                index3 = point(4);
                count = count + 2;
            end
            if(count == 2)
                index3 = point(4);
                count = count + 1;
            end
        end
        
        if(count == 1)   % handle all cases to make sure index1, 2 and 3 have values
            index2 = index1;
            index3 = index1;
        end
        if(count == 2)
            index3 = index1;
        end
        
        % at this point in the game, we have 3 (not necessarily unique, but that's okay) indexes.  we
        % can now throw the values at these indicies into the interp function with confidence, for
        % the interp function will handle cases of duplicate values
        
        % set up all the points to interpolate
        
        x1 = long(index1);
        y1 = lat(index1);
        z1 = data(index1);
        x2 = long(index2);
        y2 = lat(index2);
        z2 = data(index2);
        x3 = long(index3);
        y3 = lat(index3);
        z3 = data(index3);
        x = longtarget(i);
        y = lattarget(i);
              
        z = interp(x1,y1,z1,x2,y2,z2,x3,y3,z3,x,y);
        
        newData(i) = z;   % here's what we are looking for!  the interpolated value
    end
end