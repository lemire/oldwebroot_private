--------------------------

To generate PDF file, run
pdflatex HRschemes_2.tex

--------------------------
