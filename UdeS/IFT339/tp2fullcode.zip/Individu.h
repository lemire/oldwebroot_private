
#if !defined(_INDIVIDU_H_)
#define _INDIVIDU_H_

#include <iostream>

using namespace std;


class Individu {
public:
	Individu() {
		age = -1;
		memset(Nom,0,sizeof(Nom));
		memset(Prenom,0,sizeof(Nom));
		memset(Ville,0,sizeof(Nom));
		memset(Province,0,sizeof(Nom));
	}

	const int& donneAge() const {return age;}
	const char* donneNom() const {return Nom;}
	const char* donnePrenom() const {return Prenom;}
	const char* donneVille() const {return Ville;}
	const char* donneProvince() const {return Province;}

	virtual ~Individu();

	
	friend istream& operator>>(istream& is, Individu& i) {
		is >> i.Nom;
		is >> i.Prenom;
		is >> i.Ville;
		is >> i.Province;
		is >> i.age;
		return is;
	}

	friend ostream& operator<<(ostream& os, const Individu& i) {
		os << i.Nom << " ";
		os << i.Prenom << " ";
		os << i.Ville << " ";
		os << i.Province << " ";
		os << i.age;
		return os;
	}


	const bool operator==(const Individu& i) const {
		return ((strcmp(Nom,i.Nom) == 0) &&
			(strcmp(Prenom,i.Prenom) == 0) &&
			(strcmp(Ville,i.Ville) == 0) &&
			(strcmp(Province,i.Province) == 0) &&
			(age == i.age)); 
	}

	const bool operator<(const Individu& i) const {
		return 	compare(i); 
	}
	const bool operator>(const Individu& i) const {
		return 	!compare(i); 
	}

	 virtual bool compare(const Individu& i) const {
		 return (age < i.age); 
	 }

private:
	char Nom[256],Prenom[256],Ville[256], Province[256];
	int age;
};

#endif 
