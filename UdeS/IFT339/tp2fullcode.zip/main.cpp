#include "Individu.h"
#include <iostream>
#include <fstream>
#include <list>
using namespace std;



void main(int n, char** arg) {
	list<Individu> li;
	cout << "Ouverture de " <<arg[1] << endl;
	ifstream is(arg[1]);
	if( ! is ) {
		cout << "J'ai un probl�me!"<<endl;
	}	
	while(!is.eof()) {
		Individu i;
		is >> i;
		if(i.donneAge() >= 0) {
		  cout << i << endl;
		  li.push_back(i);
		}
	}
	is.close();
	cout << endl;
	li.sort(greater<Individu>());
	cout << "Ouverture de " << arg[2] <<endl;
	ofstream os(arg[2]);
	if (! os ) {
		cout << "J'ai un probl�me!"<<endl;
	}
	list<Individu>::iterator p = li.begin();
	while( p != li.end()) {
		os << *p << endl;
		cout << *p << endl;
		p++;
	}
	os.close();
}