
#include "Triangle.h"

Triangle::Triangle() {
	// on doit s'assurer d'avoir 3 points...
	Point P;
	enfiler(P);
	enfiler(P);
	enfiler(P);
}

Triangle::Triangle(const Point& a, const Point& b, const Point& c)
{
	enfiler(a);
	enfiler(b);
	enfiler(c);
}

Triangle::Triangle(const Triangle& t)
{
	cout <<"copieur de triangle..." <<endl;
	cout <<t.point1()<<endl;
	cout <<t.point2()<<endl;
	cout <<t.point3()<<endl;
	enfiler(t.point1());
	enfiler(t.point2());
	enfiler(t.point3());
}

Triangle::~Triangle()
{
	cout <<"destruction d'un triangle..." <<endl;
}

const Point& Triangle::point1() const {
	return TETE->valeur();
	
}

const Triangle& Triangle::operator=(const Triangle& t) {
	enfiler(t.point1());
	enfiler(t.point2());
	enfiler(t.point3());
	return *this;
}

const Point& Triangle::point2() const {
	assert(TETE->suivant() != NULL);
	return TETE->suivant()->valeur();
}

const Point& Triangle::point3() const {
	// personne n'a dit que c'�tait tr�s fut� ou
	// tr�s performant!
	assert(TETE->suivant() != NULL);
	assert(TETE->suivant()->suivant() != NULL);
	return TETE->suivant()->suivant()->valeur();
}

const int Triangle::aire() const {
	// on peut faire mieux!
	return Point::arrondi( (point1() - point2()) * (point1() - point3()) / 2.0 );

}
const bool Triangle::estRegulier() const {
	// on peut faire mieux!
	int segment1 = (point1() - point2()).normeAuCarre();
	int segment2 = (point2() - point3()).normeAuCarre();
	int segment3 = (point3() - point1()).normeAuCarre();
	return (segment1 == segment2) && (segment2 == segment3) && (segment3 == segment1);
}
