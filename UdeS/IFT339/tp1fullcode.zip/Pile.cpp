
#include "Pile.h"

#ifndef _Pile_cpp_
#define _Pile_cpp_


#include <assert.h>
template <class TYPE>
Pile<TYPE>::Pile() {	
	premier = NULL;
}

template <class TYPE>
Pile<TYPE>::Pile(const Pile& P) {	
	cout <<"copieur de pile!"<<endl;
}

template <class TYPE>
Pile<TYPE>::~Pile() {
	vider();
}

template <class TYPE>
void Pile<TYPE>::empiler(const TYPE& e) {
	cout << "Empilage d'un triangle..." <<endl;
	cout << e.point1() <<endl;
	cout << e.point2() <<endl;
	cout << e.point3() <<endl;
	premier = new Cellule(e,premier);
}

template <class TYPE>
TYPE Pile<TYPE>::depiler() {
	assert(!estVide());
	TYPE valeur = premier->element();
	Cellule *aDetruire=premier;
	premier= premier->suivant();
	delete aDetruire;
	return valeur;
}

template <class TYPE>
bool Pile<TYPE>::estVide() const {
	return premier == NULL;
}

template <class TYPE>
void Pile<TYPE>::vider() {
	while(!estVide()) depiler();
}
#endif