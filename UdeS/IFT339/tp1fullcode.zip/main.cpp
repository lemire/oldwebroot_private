#include "Point.h"
#include "Triangle.h"
#include "File.h"
#include "Pile.h"
#include <fstream>
#include <time.h>

int main(int na, char **argv) {
		if(na < 2) {
			cout << "Vous devez passer le nom du fichier en param�tre."<<endl;
			return -1;
		}
		char * Fichier = argv[1];
		ifstream in(Fichier);
		if(!in) {
			cout << "Impossible de lire dans "<< Fichier<<"." <<endl;
			return -1;
		}
		// on suppose maintenant qu'on pourra lire
		// au moins 3 points dans le fichier...
		Point a, b, c;
		in >> a >> b >> c;
		if (in.fail()) {
			cout << "Je n'ai pas pu lire un minimum de trois points dans "<<Fichier<<"."<<endl;
			return -2;
		}
		Triangle t(a,b,c);
		Pile<Triangle> PileDeTriangles;
		if( t.estRegulier() )  PileDeTriangles.empiler(t);
		while( in ) {
			in >> t;
			if (in.fail()) break;//en cas de prob, on arr�te!
			if( t.estRegulier() ) PileDeTriangles.empiler(t);
		}
		in.close();
		// maintenant, on devrait avoir trouv�
		// tous les triangles r�guliers!
		if(na < 3) {
			cout << "Vous devez passer le nom d'un fichier de sortie en param�tre."<<endl;
			return -4;
		}
		char * FichierSortie = argv[2];
		ofstream out(FichierSortie);
		if(!out) {
			cout << "Impossible d'�crire dans "<< FichierSortie<<"." <<endl;
			return -5;
		}
		while(!PileDeTriangles.estVide()) {
			 out << PileDeTriangles.depiler().aire() << endl;
		}
		out.close();
		return 0;

}

int maina(int na, char **argv) {
	srand( (unsigned)time( NULL ) );
	if(na < 2) {
		cout << "Vous devez passer le nom du fichier en param�tre."<<endl;
		return -1;
	}
	char * Fichier = argv[1];
	ofstream out(Fichier);
	if(!out) {
		cout << "Impossible d'�crire dans "<< Fichier <<endl;
		return -1;
	}
	for (int k = 0; k < 100000; ++k)  {
		const int x = rand() % 32;
		const int y = rand() % 32;
		Point a(x,y);
		out << a;
	}
	out.close();
	return 0;
}