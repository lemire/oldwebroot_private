// THEMFilter.h: interface for the THEMFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THEMFILTER_H__E1C44C32_E9BC_4C57_B037_6C993D707B84__INCLUDED_)
#define AFX_THEMFILTER_H__E1C44C32_E9BC_4C57_B037_6C993D707B84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class THEMFilter  
{
public:
	THEMFilter();
	virtual ~THEMFilter();

};

#endif // !defined(AFX_THEMFILTER_H__E1C44C32_E9BC_4C57_B037_6C993D707B84__INCLUDED_)
