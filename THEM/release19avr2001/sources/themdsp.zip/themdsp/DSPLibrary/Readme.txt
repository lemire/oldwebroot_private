Daniel Lemire, Ph.D.
http://www.ondelette.com

=========================

This library is a module that should contain only DSP
algorithms and no depedencies to non trivial file formats.


Usage: please use or modify the THEMFilter class
provided in the THEMDSPLibrary. It is very simple,
a lot simpler that what you'll find in this package!