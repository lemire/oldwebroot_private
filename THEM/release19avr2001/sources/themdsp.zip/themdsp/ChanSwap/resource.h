//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ChanSwap.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHANSWAP_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_RAW_FILE                    1000
#define IDC_SELECT_RAW                  1001
#define IDC_IN1                         1002
#define IDC_IN2                         1003
#define IDC_IN3                         1004
#define IDC_IN4                         1005
#define IDC_OUT1                        1007
#define IDC_OUT2                        1008
#define IDC_OUT3                        1009
#define IDC_OUT4                        1010
#define IDC_CREATE_NEW                  1011
#define IDC_IN_PLACE                    1012
#define IDC_HEADERONLY                  1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
