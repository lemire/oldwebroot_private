Daniel Lemire, Ph.D.
http://www.ondelette.com

=========================

This library depends on both the DSPLibrary and
the FileFormatLibrary and should provide the
upper level code. You should try to keep this
library as thin as possible.

The THEMFile class is an excellent example of
how one can use the DSP library to extend a Signal
object so that it becomes smarter. Please refer
to it.