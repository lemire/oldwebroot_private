
function openMiniWindow( url )
{
	if ( isFrameView() )
	  window.open( url, "MiniWindow" );
	else
	  window.open( url, "MiniWindow", "toolbar=no,width=350,height=400,directories=no,status=no,scrollbars=yes,resize=yes,menubar=no");
}

function openTOC( url )
{
	if ( isFrameView() )
	  window.open( url, "TOC" );
	else
	  window.open( url, "TOC",
		"toolbar=no,width=350,height=600,directories=no,status=no,scrollbars=yes,resize=yes,menubar=no" );
}

function openBody(url)
{
	if ( url != "" ) {
		window.open( url, "Body" );
	}
}

function isFrameView()
{
	return window.parent != null && window.parent != window.self;
}

function toggleFrames()
{
	if ( isFrameView() ) {
		window.parent.open( document.URL, "_self" );
	}
	else {
		// open the frameset with the current page
		//  in the body window.
		var querystring = "bodyURL=" + escape( document.URL );
		if ( window.miniWindowURL != null )
		  querystring += ",miniURL=" + escape( window.miniWindowURL );
		if ( window.contentsWindowURL != null )
		  querystring += ",contentsURL=" + escape( window.contentsWindowURL );
		window.parent.open( "contentsf.html" + "?" + querystring, "_self" );
	}
}

function accessError(message,url,line) {
	window.close();
	return true;
}

function checkMiniWindowOpener()
{
	if ( window.opener == null ) {
		// Don't know how this happened.
		window.close();
	}
	else if ( window.opener.closed ) {
		window.close();
	}
	else {
		errorHappened = false;
		var ooe = window.onerror;
		window.onerror = accessError;
		var s = window.opener.name;
		window.onerror = ooe;
		if ( s == "Body" ) {
			window.opener.miniWindowURL = document.URL;
		}
		else {
			window.close();
		}
	}
}

function checkContentsWindowOpener()
{
	if ( window.opener == null ) {
		// Don't know how this happened.
		window.close();
	}
	else if ( window.opener.closed ) {
		window.close();
	}
	else {
		errorHappened = false;
		var ooe = window.onerror;
		window.onerror = accessError;
		var s = window.opener.name;
		window.onerror = ooe;
		if ( s == "Body" ) {
			window.opener.contentsWindowURL = document.URL;
		}
		else {
			window.close();
		}
	}
}

function toggleTOC()
{
	var vSrc = window.event.srcElement;
	var menuName = vSrc.id + "_sub";
	var menu = document.all(menuName);

	if ( menu.style.display == "none" ) {
		// Change from + to -
		vSrc.src = "minus.gif";
		menu.style.display = "";
	}
	else {
		vSrc.src = "plus.gif";
		menu.style.display = "none";
	}
}

function getArgs() {
	var args = new Object();
	var query = location.search.substring(1);
	var pairs = query.split(",");
	for ( var i = 0; i < pairs.length; i++ ) {
		var pos = pairs[i].indexOf('=');
		if ( pos == -1 ) continue;
		var argname = pairs[i].substring(0,pos);
		var value = pairs[i].substring(pos+1);
		args[argname] = unescape(value);
	}
	return args;
}


function ViewInVB( objname )
{
	if ( VSControl.IsVBRunning() ) {
		wentok = VSControl.ShowInVB( objname );
		if ( !wentok ) {
			alert( "Something went wrong -- probably VB is not open to the right project" );
		}
	}
	else {
	    alert( "VB or the VB plug-in is not running" );
	}
}
function ViewInDevStudio( project, file, line )
{
	if ( !VSControl.ShowInDevStudio( project, file, line) ) {
		// Could just be the user canceled the action.
	}
}


args = getArgs();

window.focus();

