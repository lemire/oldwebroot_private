Daniel Lemire, Ph.D.
http://www.ondelette.com

=========================

This library should contain THEM's specifications for
the file format.

Currently, all the software in this library was 
provided by Robin.
