
/**
 *  Just some constants and options for data cubes.
 *
 *@author     Daniel Lemire
 *@created    July 25th 2002
 */

public class Options {
	public static final boolean mIntensePyRPSDebugging = false; 
	public static final boolean mPyRPSTransformDebug = false;
	public static final boolean mDisplayQueries = false;
	public static final boolean mPyRPSUpdateDebug = false; 
}
