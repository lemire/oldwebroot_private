
/**
 *  This class will model a data cube using a flat binary file.
 * The data cube is assumed to be of size n**d (regular).
 *
 *@author     Daniel Lemire
 *@created    July 25th 2002
 */

import java.io.*;
import java.util.*;
import Options;

public class DataCube {
	
	String mFilename;
	RandomAccessFile mRandomAccess;	
	int mN = 0 , mD = 0;
	long[] powermN;
	int[] indices;
	long[] cumulindices;
	/*
	* create a file
	*/
	public DataCube() {
	}
	
	public DataCube(int n, int d, String filename) {
		config(n,d,filename);
	}
	
	public int getN() {
		return mN;
	}
	
	public int getD() {
		return mD;
	}
	
	public String getFilename() {
		return mFilename;
	}
	
	public void config(int n, int d, String filename) {
		if(isOpen())
			close();
		if(n <= 0)
			throw new IllegalArgumentException("Trying to build an empty cube!");
		if(d < 1)
			throw new IllegalArgumentException("The dimension of a cube must be at least 1.");
		mN = n;
		mD = d;
		mFilename = filename;
		powermN = new long[mD + 1];
		powermN[0] = 1;
		for(int dim = 1; dim < powermN.length; ++dim) {
			powermN[dim] = powermN[dim - 1 ] * mN;
		}
		indices = new int[mD];
		cumulindices = new long[mD + 1];
	}
	
	public boolean open() {
		if (mRandomAccess != null) return true; // already open, so yes, we opened it
		try {
			mRandomAccess = new RandomAccessFile(mFilename,"rw");
			mRandomAccess.setLength(powermN[mD]);
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean isOpen() {
		return (mRandomAccess != null);
		// after a close, we set the random access to null
	}
	
	/* TODO : might want to add a constructor that will read an existing flat file */
	
	public boolean close() {
		if (mRandomAccess == null)
			return true; // closed it since it wasn't open!!!
		try {
			mRandomAccess.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		}
		mRandomAccess = null;
		return true;
	}
	

	public int query(long coordinates) {
		if(Options.mDisplayQueries) {
			System.out.print("[debug] Query : ");
			for (int k = 0; k < mD;++k) {
				System.out.print(((int)(coordinates / powermN[k] )) % mN);
				if( k < mD - 1) System.out.print(" ");
			}
			System.out.println();
			
		}
		final long gotoPos = coordinates * 4;
		try {
			if ((gotoPos > mRandomAccess.length()) || (gotoPos < 0) ) throw new IllegalArgumentException("Out of range : "+coordinates);
			mRandomAccess.seek(gotoPos);
			return mRandomAccess.readInt();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return 0;// do not worry too much about problems, just report them
		}
		
	}
	
	public boolean store(long coordinates, int value) {
		// do your best to write to the file
		final long gotoPos = coordinates * 4;
		
		try {
			if ((gotoPos > mRandomAccess.length()) || (gotoPos < 0) ) throw new IllegalArgumentException("Out of range : "+coordinates);
			mRandomAccess.seek(gotoPos);
			mRandomAccess.writeInt(value);
			
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;// do not worry too much about problems, just report them
		}
		return true;
		
	}
	
	

	
	public static int power(int b, int power) {
		int ans = 1;
		for (int k = 0; k < power; ++k) {
			ans *= b;
		}
		return ans;
	}
	
	public static long powerLong(int b, int power) {
		long ans = 1L;
		for (int k = 0; k < power; ++k) {
			ans *= b;
		}
		return ans;
	}
	
	public void fillWithRandomValues() {
		fillWithRandomValues(131072);
	}
	
	public void fillWithRandomValues(int range) {
		Random rand = new Random();
		long max = powermN[mD];
		try {
			mRandomAccess.seek(0L);
			for (long k = 0; k < max; ++k) {
				mRandomAccess.writeInt(rand.nextInt(range));
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void fillWithZeroes() {
		long max = powerLong(mN,mD);
		try {
			mRandomAccess.seek(0L);
			for (long k = 0; k < max; ++k) {
				mRandomAccess.writeInt(0);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void fillWithOnes() {
		long max = powerLong(mN,mD);
		try {
			mRandomAccess.seek(0L);
			for (long k = 0; k < max; ++k) {
				mRandomAccess.writeInt(1);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public boolean delete() {
		if (isOpen()) {
			close();
		}
		File file = new File(mFilename);
		return file.delete();
	}
	
	
	public long prefixSum(long coordinates) {
		for (int dim = 0; dim < mD; ++dim) {
			indices[dim] =((int) (coordinates / powermN[dim])) % mN + 1;//  the index in the dim dimension
		//	System.out.println("[debug] indices[ "+dim+"] = "+indices[dim]);
		}
		cumulindices[0] = 1;
		for( int dim = 1; dim < mD + 1 ; ++dim) {
			cumulindices[dim] = cumulindices[dim - 1] * indices[dim - 1]; 
		}
		long total = cumulindices[mD];
		//System.out.println("[debug] number of terms to sum up "+total);
		long sum = 0;
		for(int k = 0 ; k < total; ++k) {
			long location = 0;
			for(int dim = 0; dim < mD;++dim) {
				location += ((k / cumulindices[dim ]) % indices[dim])*powermN[dim];
			}
		//	System.out.println("[debug] location = "+location);
			sum += query(location);
		}
		return sum;
	}

	public static void main(String[] arg) {
		int N = 16;
		long before, after;
		// next, testing plain data cube 
		DataCube plaindc = new DataCube(N,3,"testplain.bin");
		plaindc.open();
		plaindc.fillWithOnes();
		boolean plainerror = false; 
		System.out.println("Testing prefix sum for plain data cube");
		System.gc();
		before = System.currentTimeMillis();
		for ( int i = 0; i < N; ++i) {
			for ( int j = 0; j < N; ++j) {
					for (int k = 0; k < N; ++k) {
						if(plaindc.prefixSum(i*N*N+j*N+k) !=(i+1)*(j+1)*(k+1)) {
							System.out.println("************ Error detected at "+i+" "+j+" "+k);
							System.out.println(" got "+plaindc.prefixSum(i*N*N+j*N+k)+" and was expecting "+(i+1)*(j+1)*(k+1));
							plainerror = true;
						}
					}
			}
		}
		after =  System.currentTimeMillis();
		System.out.println("It took "+((after-before)/1024.0)+" s");
		if (plainerror) {
			System.out.println("There was a problem with plain data cube.");
		} else {
			System.out.println("There was no problem with plain data cube.");
		}
		plaindc.close();
		plaindc.delete();
	}


}

