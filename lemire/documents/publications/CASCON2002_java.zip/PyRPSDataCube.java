
/**
 *  This class extends the data cube by adding a secondary 
 * cube used for wavelet tree storage and fast range sum queries.
 *
 * Reference:
 *  Daniel Lemire, Wavelet-Based Relative Prefix Sum Methods for Range Sum Queries in Data Cubes. 
 *  Proceedings of CASCON 2002, Toronto, Canada, October 2002. 
 *
 * See also http://www.ondelette.com/acadia/ (author's homepage)
 * 
 *@author     Daniel Lemire
 *@created    Jyly 25th 2002
 */

import DataCube;
import Options;
import java.util.*;




public class PyRPSDataCube extends DataCube {
	
	int mBasis, mJ;	
	DataCube mPyRPSDataCube;
	int[] powermJ, powermBasis;
	int[][] gammasequences;
	//int[] start;
	//int[] number;

	public PyRPSDataCube(int n, int d, String filename, int base) {
		if(base <= 0)	throw new IllegalArgumentException("Basis must be positive definite");
		// next, we check that we indeed have n = base**j
		int testn = n;
		mJ = 1;
		while (testn > 1) {
			testn /= base;
			++mJ;
			if (testn == 1) break;
			// should still be divisible by n
			if ( testn % base != 0 ) throw new IllegalArgumentException("We must have n = basis**j for some j"); 
		}
		mBasis = base;
		config(n,d,filename);
		powermJ = new int[mD+1];
		powermBasis = new int[mJ + 1];
		if(Options.mIntensePyRPSDebugging) System.out.println("[debug] mJ = "+mJ);
		if(Options.mIntensePyRPSDebugging) System.out.println("[debug] mD = "+mD);
		powermBasis[0] = 1;
		powermJ[0] = 1;
		for(int dim = 1; dim < powermJ.length; ++dim) {
			powermJ[dim] = powermJ[dim - 1 ] * mJ;
		}
		for(int dim = 1; dim < powermBasis.length; ++dim) {
			powermBasis[dim] = mBasis * powermBasis[dim - 1 ];
		}
		gammasequences = new int[mD][(mJ - 1) *mBasis + mBasis]; // ample storage here
	//	start = new int[mD];
	//	number = new int[mD];
		
	}
	
	public int getBasis() {
		return mBasis;
	}
	
	public DataCube getTransformedDataCube() {
		return mPyRPSDataCube;
	}
	
	public void initialize() {
		// this will be used to store the wavelet transform
		mPyRPSDataCube = new DataCube(mN,mD,"PyRPS_"+mFilename);		
	}
	
	public void dump() {
		System.out.println("DUMPING");
		for(long k = 0; k < power(getN(),getD()); ++k) {
			if((k % getN()) == 0) System.out.println();
			if((k % (getN()*getN())) == 0) {
				System.out.println("----");
				System.out.println("");
			}
			if( (k % getN()) != 0) { 
				System.out.print("\t");
			} 
			System.out.print(getTransformedDataCube().query(k));
			if(height(k) > 1) System.out.print("*");
		}
		System.out.println();
	}
	
	public static void main(String[] arg) {
		long before, after;
		System.out.println("init");
		//int N= 16;
		int N= 9;
		int b = 3;
		PyRPSDataCube dc = new PyRPSDataCube(N,3,"test.bin",b);
		System.out.println("file created");
		dc.open();
		System.out.println("filling the file with zeroes");
		before = System.currentTimeMillis();
		dc.fillWithOnes();
		after =  System.currentTimeMillis();
		System.out.println("It took "+((after-before)/1024.0)+" s");
		//System.out.println("filling the file with random values");
		//before = System.currentTimeMillis();
		//dc.fillWithRandomValues();
		//after =  System.currentTimeMillis();
		//System.out.println("It took "+((after-before)/1024.0)+" s");
		System.out.println("transforming");
		before = System.currentTimeMillis();
		dc.transform();
		after =  System.currentTimeMillis();
		System.out.println("It took "+((after-before)/1024.0)+" s");
		/*for(long k = 0; k < power(dc.getN(),dc.getD()); ++k) {
			if((k % dc.getN()) == 0) System.out.println();
			System.out.print(" "+dc.getTransformedDataCube().query(k));			
		}*/
		System.out.println();
		/// next, we are going to test out the prefix sums!!!
		if(false) {
			System.out.println("Testing prefix sum for PyRPS data cube");
			System.gc();
			before = System.currentTimeMillis();
			boolean error = false; 
			for ( int i = 0; i < N; ++i) {
				for ( int j = 0; j < N; ++j) {
						for (int k = 0; k < N; ++k) {
							if(dc.prefixSum(i*N*N+j*N+k) !=(i+1)*(j+1)*(k+1)) {
								System.out.println("************ Error detected at "+i+" "+j+" "+k);
								error = true;
							}
						}
				}
			}
			after =  System.currentTimeMillis();
			System.out.println("It took "+((after-before)/1024.0)+" s");	
			if (error) {
				System.out.println("There was a problem with PyRPS data cube.");
			} else {
				System.out.println("There was no problem with PyRPS data cube.");
			}
		}
		// next, we are going to check the storage mechanism...
		//int iupt = 0; int jupt = 5; int kupt =5;
		Random rand = new Random();
		//dc.dump();
		System.out.println("Increasing by one one of the values");
		int location = rand.nextInt ( (int)dc.powermN[dc.mD ] - 1 );
		
		System.out.println("chosen location = "+location);
		dc.store(location,2);
		System.out.println("Update successful... checking...");
		//dc.dump();
		boolean errorupt = false; 
		int errors = 0;
		
//		System.out.println(dc.prefixSum(3));
//		System.out.println(dc.expensivePrefixSum(3));
		if( true) {
			System.out.println(" test ");
			for (int i = 0 ; i < dc.powermN[dc.mD]; ++i ) {
				if(dc.prefixSum(i) != dc.expensivePrefixSum(i)) {
					System.out.println("*** error at "+i);
					errors++;
					errorupt = true;
				}
			}
		}
		if (errorupt) {
			System.out.println("There was a problem with PyRPS data cube after an update.");
			System.out.println(errors+ " errors !");
		} else {
			System.out.println("There was no problem with PyRPS data cube after an update.");
		}
		/*i=0;j=0;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));
		i=1;j=0;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));

		i=7;j=7;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));
		i=15;j=15;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));
		i=14;j=14;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));
		i=14;j=15;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));
		i=15;j=14;
		System.out.println("prefix [ "+i+" , " +j+" ] = "+dc.prefixSum(i*N+j));
		System.out.println("should be "+(i+1)*(j+1));*/
		/// done testing the prefix sums
		System.out.println("closing");
		dc.close();
		System.out.println("deleting");
		dc.delete();
		/*
		System.out.println("testing transform");
		int[] testarray = new int[64];
		for(int i = 0; i < testarray.length; ++i) {
			testarray[i] = 1;
		}
		dc.transform(testarray);
		//dc.transform(testarray,4);
		//dc.transform(testarray,4);
		//dc.transform(testarray,8);
		for(int i = 0; i < testarray.length; ++i) {
			System.out.print(" "+testarray[i]);
			if(i % dc.mBasis == dc.mBasis - 1) System.out.print ("*");
		}
		System.out.println();*/
	}
	


	public void transform() {
		if (Options.mPyRPSTransformDebug) System.out.println("[debug] mN = " +mN);
		if (Options.mPyRPSTransformDebug) System.out.println("[debug] mBasis = " +mBasis);
		final long subhypercubesize = powermN[mD-1];
		if (Options.mPyRPSTransformDebug) System.out.println("[debug] subhypercubesize = " +subhypercubesize);
		int[] temparray = new int[mN];
		long beforeindex, afterindex, chunk;
		// run accross all dimensions, one at a time
		if (Options.mPyRPSTransformDebug) System.out.println("[debug] fixeddimension = "+0);
		for (long k = 0; k < subhypercubesize; ++k) {// this will traverse all values
			//System.out.println("k = "+k);
			// each time, we need to do a transform
			//beforeindex =  k  ;
			//afterindex =  k  ;
			// we recover the data and buffer it
			for (int l = 0 ; l < mN; ++l) {
				temparray[l] = query( (mN  * k + l) /** chunk*/);
			}
			transform(temparray);
			for (int l = 0 ; l < mN; ++l) {
				mPyRPSDataCube.store( (mN * k + l) /* * chunk*/,temparray[l]);
			}
		}								
		for(int fixeddimension = 1; fixeddimension < mD; ++fixeddimension) {
			// given a dimension, traverse it!
			// we've got n**(d-1) dimensions to traverse
			chunk = powermN[fixeddimension];
			if (Options.mPyRPSTransformDebug) System.out.println("[debug] fixeddimension = "+fixeddimension);
			for (long k = 0; k < subhypercubesize; ++k) {// this will traverse all values
				//System.out.println("k = "+k);
				// each time, we need to do a transform
				beforeindex =  k % chunk ;
				afterindex =  k / chunk ;
				// we recover the data and buffer it
				for (int l = 0 ; l < mN; ++l) {
					temparray[l] = mPyRPSDataCube.query(beforeindex + (mN * afterindex + l) * chunk);
				}
				//System.out.println();
				// next, we do the actual computation
				transform(temparray);
				//finally, we store it inside the new datacube
				for (int l = 0 ; l < mN; ++l) {
					mPyRPSDataCube.store(beforeindex + (mN * afterindex + l)  * chunk,temparray[l]);
				}
			}
				
		}
	}
	
	private int gamma(final int k, final int j) {
		final int b_j = powermBasis[j];
		if (Options.mIntensePyRPSDebugging) System.out.println("[debug] k = "+k+" j = "+j+" b_j = "+b_j +" gamma = "+(b_j * ((k+1)/b_j) -1)); 
		return b_j * ((k+1)/b_j) -1 ;
	}
	
	private void gammaseq(int[] storage, final int i) {
			int pos = 0;
			int r;
			storage[pos] = i;
			for (int j = 1 ; j < mJ ; ++j) {
				r = powermBasis[j] * ((i+1)/powermBasis[j])-1;//gamma(i,j);
				if( r == -1) {
					storage[++pos] = -1;
				} else if (r!= storage[pos]) {// add only if it is worth it!
					storage[++pos] = r;
				}
			}
			for (; ++pos < storage.length; ) {
				storage[pos] = -1;
			}
	}

	public long prefixSum(final long coordinates) {
		int i, pos, r;
		for (int dim = 0; dim < mD; ++dim) {
			i = ((int) (coordinates / powermN[dim])) % mN;// i is the index in the mD dimension
			pos = 0;
			gammasequences[dim][pos] = i;
			for (int j = 1 ; j < mJ ; ++j) {
				r = powermBasis[j] * ((i+1)/powermBasis[j])-1;//gamma(i,j);
				if( r == -1) {
					break;
				} else if (r!= gammasequences[dim][pos]) {// add only if it is worth it!
					gammasequences[dim][++pos] = r;
				}
			}
			indices[dim] = ++pos;
		}
		// at most, we have mJ**mD cells to visit
		cumulindices[0] = 1;
		for( int dim = 1; dim < mD + 1; ++dim) {
			cumulindices[dim] = cumulindices[dim - 1] * indices[dim - 1]; 
		}
		final long numbertovisit = cumulindices[mD];
		if (Options.mIntensePyRPSDebugging) System.out.println("[debug] numbertovisit = "+numbertovisit);
		long sum = 0; long location;
		for(long k = 0; k < numbertovisit; ++k) {
			location = 0;	
			for(int dim = 0;  dim < mD; ++dim) {
				//if(current <0) continue outer;// not valid
				location += gammasequences[dim][(int)( k / cumulindices[dim]) % indices[dim]] * powermN[dim];				
			}
			sum += mPyRPSDataCube.query(location);
			if (Options.mIntensePyRPSDebugging) System.out.println("[debug] location added = "+location+" value = "+mPyRPSDataCube.query(location));
		}
		return sum;
	}
	
	public long expensivePrefixSum(long coordinates) {
		return super.prefixSum(coordinates);
	}

	
	private void transform(int[] data, int sampling) {
		//System.out.println("[debug] sampling = " +sampling);
		final int maxi = data.length/(mBasis*sampling);
		int pos;
		for(int i = 0; i < maxi; ++i) {
			for(int b = 1; b < mBasis; ++b) {
				pos = (mBasis*i+b)*sampling + sampling - 1; 
				data[pos] += data[pos - sampling] ;
			}
		}
	}
	
	private void transform(int[] data) {
		for(int sampling = 1; sampling < data.length; sampling *= mBasis) {
			transform(data,sampling);
		}
	}
	
	public boolean open() {
		if(mPyRPSDataCube == null) initialize();			
		return super.open() && mPyRPSDataCube.open();
	}

	
	/* TODO : might want to add a constructor that will read an existing flat file */
	
	public boolean close() {
		if(mPyRPSDataCube == null) initialize();
		return super.close() &&	mPyRPSDataCube.close();
	}

	public boolean delete() {
		if(mPyRPSDataCube == null) initialize();
		return super.delete() && mPyRPSDataCube.delete();
	}
	
	private int height1d( int k ) {
		int j = 0;
		while ( (powermBasis[j + 1] * ((k + 1)/powermBasis[j + 1]) - 1 ) == k ) {
			++j;
		}
		return j + 1;
	}
	
	public int height (long coordinates ) {
		int h = height1d((int)(coordinates % mN)) ;
		int i, r;
		for (int dim = 1 ; dim < mD; ++dim) {
			i = ((int) (coordinates / powermN[dim])) % mN;
			if(h > (r = height1d(i)) ) {
				h = r;
			}
		}
		return h;
	}
	
	
	public boolean store(long coordinates, int value) {
		if(Options.mPyRPSUpdateDebug) System.out.println("[debug] value = "+value);
		if(Options.mPyRPSUpdateDebug) System.out.println("[debug] coordinates = "+coordinates);
		final int difference = value - query(coordinates);		
		if(super.store(coordinates,value) ) {
			// update the transform
			// we need to transverse the entire tree adding "difference" to all coefficients!
			int i, j, pos, start;
			int end = 0;
			for (int dim = 0; dim < mD; ++dim) {
				i = ((int) (coordinates / powermN[dim])) % mN;// i is the index in the mD dimension
				end = i;
				if(Options.mPyRPSUpdateDebug) System.out.println("[debug] ********* dimension = "+dim);
				if(Options.mPyRPSUpdateDebug) System.out.println("[debug] i = "+i);
				pos = 0;
				for (j = height1d(i) - 1; j < mJ  - 1; ++j ) {
					if(Options.mPyRPSUpdateDebug) System.out.println("[debug] j = "+j+" mJ = "+mJ);
					start =  powermBasis[j] * (i/powermBasis[j]) + powermBasis[j] - 1;
					end =  powermBasis[j + 1] * (i/powermBasis[j+ 1]) + powermBasis[j+ 1] - 1 ;
					if(Options.mPyRPSUpdateDebug) System.out.println("[debug] going from "+start+" and stopping short at "+end+" by steps of "+ powermBasis[j]);
					for(int k = start ; k < end ; k += powermBasis[j]) {
						if(Options.mPyRPSUpdateDebug) System.out.println("gammasequences["+dim+"]["+pos+"] = "+k);
						gammasequences[dim][pos++] = k; 
					}
					
					
				}
				if(Options.mPyRPSUpdateDebug) System.out.println("end point");
				if(Options.mPyRPSUpdateDebug) System.out.println("gammasequences["+dim+"]["+pos+"] = "+end);
				gammasequences[dim][pos++] = end;
				indices[dim] = pos;
				if(Options.mPyRPSUpdateDebug ) {
					for(int k = 0; k < indices[dim];++k) {
						System.out.print(gammasequences[dim][k]+" ");
					}
					System.out.println();
				}
			}
			
			cumulindices[0] = 1;
			for( int dim = 1; dim < mD + 1; ++dim) {
				cumulindices[dim] = cumulindices[dim - 1] * indices[dim - 1]; 
			}
			final long numbertovisit = cumulindices[mD];
			if(Options.mPyRPSUpdateDebug) System.out.println("[debug] numbertovisit = "+numbertovisit);
			long location;
			for(long k = 0; k < numbertovisit; ++k) {
				location = 0;	
				for(int dim = 0;  dim < mD; ++dim) {
					location += gammasequences[dim][(int)( k / cumulindices[dim]) % indices[dim]] * powermN[dim];				
				}
				mPyRPSDataCube.store(location,mPyRPSDataCube.query(location)+difference);
			}
			return true;
		}
		return false;
	}
	
/*	private void update (long coordinates, int j, int difference) {
		System.out.println("[debug] update ( "+ coordinates+" , "+ j + " , "+ difference + ") ");
		// first we find the anchor
		int i;
		//long anchor = 0;
		//int[] start = new int[mD];
		int end;
		//int[] number = new int[mD];
		for( int dim = 0; dim < mD; ++dim) {
			i = ((int) (coordinates / powermN[dim])) % mN;
			start[dim] =  powermBasis[j] * (i/powermBasis[j]) + powermBasis[j] - 1;
			end =  powermBasis[j + 1] * (i/powermBasis[j+ 1]) + powermBasis[j+ 1] - 1 ;
			number[dim] = (end - start[dim])/powermBasis[j] + 1;
		}
		cumulindices[0] = 1;
		for( int dim = 1; dim < mD + 1; ++dim) {
			cumulindices[dim] = cumulindices[dim - 1] * number[dim - 1]; 
		}		
		long total = cumulindices[mD] - 1;
		long location;
		for(long k = 0; k < total; ++k) {
			//System.out.println("[debug] update number "+k);
			location = 0;
			for( int dim = 0; dim < mD; ++dim) {
				i = (((int)(k / cumulindices[dim])) % number[dim]) * powermBasis[j] + start[dim];
				//System.out.println("[debug] dim = "+dim+ " coordinate "+i); 
				location += i*powermN[dim];
			}
			mPyRPSDataCube.store(location,mPyRPSDataCube.query(location)+difference);
		}
		
	}*/
	
}
