/**
* C++ monotone segmentation code.
*
* Based on C code by Franco Lenardon
*
* August 12th 2005 by Daniel Lemire
* http://www.daniel-lemire.com/en/
*
*/

#include <vector>
#include <iostream>

using namespace std;

// determine sign of first pair
int determineSign (float *x, int numsamp)
{
       for (int i = 1; i < numsamp; i++)
               if (x[i] > x[0]) return 1;
               else if (x[i] < x[0]) return -1;
       return 0;
}
// convenience method
void print(vector<int>& v) {
   for(int k = 0 ; k < v.size();++k)
     cout<< v[k] << " ";
   cout << endl;
}
/**
* return the location of the segmentation points
*/
vector<int> DoSegmentation (float *x, float scale, int numsamp, bool verbose = false)
{


       int k = 0;     
       vector<int> out;
       out.push_back(0);           // place first index into queue
       int D = determineSign (x, numsamp);     // determine first trend
       if (D == 0)
       {
               // all the samples in our case are the same, return just
               // 2 point vector from beginning to end
               out.push_back(numsamp-1);   // C++ indexing starts from 0
               return out;               // return number of indices in the output vector
       }

       for (int i = 0; i < numsamp; i++)       // go through all input samples
       {
               if (verbose) cout << " Looking at index = "<< i<< " value is " << x[i] << " direction is " << D << " delta = " << scale << " k is " << k << endl;
               if (verbose) print(out);
               if ((D==1 && (x[k] - x[i]) >= scale) || (D==-1 && (x[i] - x[k]) >= scale))
               {
                       // means: if the direction is positive and we've found that sample i is BELOW threshold, so negative direction
                       // or direction negative and we've found positive movemet
                       if(verbose) cout << "direction reversal at " << k << " found at " << i<< endl;
                       out.push_back(k);
                       if(verbose) print(out);
                       k=i;
                       D *= -1;
               } else if ((D == 1 && (x[i] > x[k])) || (D == -1 && x[i] < x[k]))
                       // means: we move by some element in good direction it doesn't represent a filtration problem
                       // so we can skip it
                       k = i;

       }
       // this is needed if the function is fully monotonous without skipping, then we just move index k but without
       // writing it into our queue. At the end we would finish with queue with one element only.
       if ((out[out.size()-1] != k)&&(out.size() > 0))
       {
               out.push_back(k);
       }
       // we need to finish at the border
       if (out[out.size()-1] != numsamp-1)
       {
               out.push_back(numsamp-1);
       }
       return out;
}
int  main () {
   float signa[] = { 0.,2.5,2., 0.5,0.2,4.,-3.,3.,3.5,3.,2.,5., 0.6};
   int length = 12;
   bool verbose = true;
   float theta = 0.6;
   vector<int> out = DoSegmentation (signa, theta, length, verbose);
   print (out);
}
