# Bunch of Python code for
# the episode paper with Will
#
# By Daniel Lemire, March 16th 2005
#
# Will Fitzgerald, Daniel Lemire, and Martin Brooks, Quasi-monotonic i
# segmentation of state variable behavior for reactive control, AAAI05,
# Pittsburgh, USA, July 2005.
#
# URL : http://www.daniel-lemire.com/fr/abstracts/AAAI05.html
#
# Documentation:
#
# We represent a times series like this t=[(1,2),(4,5),(7,4),...]
# and you can go through it like this for x,y in t: print y

####
# useful functions
####

import math 

def interpolateEndPoints(p1,p2):
        """ given two points, return f(x) = a x +b """
	x1=float(p1[0])
        x2=float(p2[0])
        if(x1==x2): raise "two data points with same x value."
        h = float(x2-x1)
        y1=float(p1[1])
        y2=float(p2[1])
        def f(x) : return (x2 - x) * y1 /h + (x - x1) * y2 / h
        assert abs(f(p1[0])-p1[1])<0.0001, " error:"+str(f(p1[0]))+" <> "+ str(p1[1])
        assert abs(f(p2[0])-p2[1])<0.0001, " error:"+str(f(p2[0]))+" <> "+ str(p2[1])
        return f

def last(x): return x[len(x)-1]

# Sliding window
# this is the simplest splining algorithm possible
# You should be able to parse it and understand it.

def oslide(timeseries,epsilon):
  currentnode = 0
  answer = [currentnode]
  answers = [timeseries[0]]
  while(last(answer) <> len(timeseries)-1 ):
    for nextnode in xrange(currentnode + 1, len(timeseries)):
      #print "current=",currentnode, " nextnode = ", nextnode
      f= interpolateEndPoints(timeseries[currentnode],timeseries[nextnode])
      maxerror = 0.0
      for p in timeseries[currentnode:nextnode]:
        error = abs(f(p[0]) - p[1])
        #print "error for ", p, " is ",error
        if(error > maxerror): maxerror = error
      #print "error = ", error
      if(maxerror > epsilon): 
        currentnode = nextnode - 1
        answer.append(currentnode)
	answers.append(timeseries[currentnode])
        break
      if(nextnode==len(timeseries)-1) : 
        currentnode = nextnode
        answer.append(currentnode)
	answers.append(timeseries[currentnode])
  return answers

true=(1==1)
def slide(timeseries,epsilon):
  currentnode = 0
  answer = [timeseries[0]]
  while true: 
    for nextnode in xrange(currentnode + 1, len(timeseries)):
      #print "current=",currentnode, " nextnode = ", nextnode
      assert currentnode <> nextnode
      f= interpolateEndPoints(timeseries[currentnode],timeseries[nextnode])
      maxerror = 0.0
      for p in timeseries[currentnode:nextnode]:
        error = abs(f(p[0]) - p[1])
        #print "error for ", p, " is ",error
        if(error > maxerror): maxerror = error
      #print "error = ", error
      if(maxerror > epsilon): 
        currentnode = nextnode - 1
	answer.append(timeseries[currentnode])
        break
      if(nextnode==len(timeseries)-1) : 
        currentnode = nextnode
	answer.append(timeseries[currentnode])
	return answer
#
# Tweaked Martin Brooks approach
# I hope this segment into flats/increasing/decreasing, but it probably
# a bit wrong, I blame the lack of time
#

UP=1
DOWN=-1
FLAT=0
def sign(x): 
  if(x < 0): return -1
  if(x > 0): return 1
  return 0

def determineSign(timeseries,startindex=0):
  firstpoint = timeseries[0]
  Direction = 0
  for index in xrange(startindex+1, len(timeseries)):
    nextpoint = timeseries[index]
    if(firstpoint[1] <> nextpoint[1]):
      Direction = sign(nextpoint[1]-firstpoint[1])
      break
  return Direction

def deltaExtrema(timeseries,delta, detectflats=1, dt = 0):
  """ Known bugs: none, but don't worry, there are many 
  It supports stair cases flats (no other flats)"""
  answer = [timeseries[0]]
  # if it is not a flat, then it must be in the given direction
  Direction =  determineSign(timeseries,0) 
  if( Direction is 0 ): 
    answer.append(timeseries[len(timeseries)-1])
    return answer
  ExtremumIndex=0
  AntiExtremumIndex=0
  index = 0
  for index in xrange(len(timeseries)):
     #print "== index ",index, " value is ", timeseries[index], " direction hint is ", Direction, " delta= ",delta, " extrema so far: ", answer
     point = timeseries[index]
     Extremum = timeseries[ExtremumIndex]
     AntiExtremum = timeseries[AntiExtremumIndex]
     if ( (Direction is UP) and (Extremum[1] - point[1] >= delta) ) \
      or ( (Direction is DOWN) and (point[1] - Extremum[1] >= delta) ):#change of direction
        #print "new direction at ", index, " adding index = ",ExtremumIndex
	answer.append(timeseries[ExtremumIndex]) #we have an up or a down
        Direction = Direction * -1
        #print "new hint ", Direction
        AntiExtremumIndex = ExtremumIndex
        ExtremumIndex = index
     elif  ( (Direction is UP) and ( point[1] > Extremum[1]) ) \
      or ( (Direction is DOWN) and (point[1] < Extremum[1] ) ):#new extremum
        #print "new extremum at ",index
        #print "antiextremum = ", AntiExtremumIndex
        #print "extremum = ", ExtremumIndex
        if((AntiExtremumIndex > ExtremumIndex) and (AntiExtremumIndex - ExtremumIndex > dt) and detectflats): #stair case flat segment
          assert ExtremumIndex <> AntiExtremumIndex
          answer.append(timeseries[ExtremumIndex])
          answer.append(timeseries[AntiExtremumIndex])	  
        ExtremumIndex = index
        AntiExtremumIndex = index
     elif  ( (Direction is UP) and ( point[1] < AntiExtremum[1]) ) \
      or ( (Direction is DOWN) and (point[1] > AntiExtremum[1] ) ):#new antiextremum
        #print "new antiextremum at ",index
        AntiExtremumIndex = index
        AntiExtremum = timeseries[AntiExtremumIndex]
  if((answer[len(answer)-1] <> timeseries[ExtremumIndex]) and (len(answer)>1)):
    answer.append( timeseries[ExtremumIndex] )
  if(answer[len(answer)-1] <> timeseries[len(timeseries)-1]):
    answer.append( timeseries[len(timeseries)-1] )
  return answer

#
# Regression analysis using an n^th degree
# polynomial
#

def regression(timeseries, degree):
  import Numeric# you need to install Python Numeric, 
  #http://sourceforge.net/projects/numpy
  # first, we compute the best fitting polynomial using
  # regression (L_2 norm)
  A = Numeric.zeros([degree+1,degree+1], 'f')
  B = Numeric.zeros(degree+1,'f')
  number = len(timeseries)
  for x,y in timeseries:
    for l in range(degree+1):
      B[l] += y * float(x)**l/ number
      for i in range(degree+1):
        A[l][i] += x**(l+i) / number
  import LinearAlgebra
  X,resids,rank,s = LinearAlgebra.linear_least_squares(A,B)
  def f(x):
    answer = 0.0
    xi = 1
    for i in range(len(X)):
      answer += X[i] * xi
      xi *= x
    return (x,answer)
  # next, we find out where to segment...
  regressiony = map(f,[float(x) for x,y in timeseries])
  sign = determineSign(regressiony)
  segment = [timeseries[0]]
  for i in xrange(1,len(timeseries)-1):
    if( (sign is UP) and (timeseries[i][1] < timeseries[i-1][1])) or\
     ((sign is DOWN) and (timeseries[i][1] > timeseries[i-1][1])):
       sign *= -1
       segment.append(timeseries[i])
  segment.append(timeseries[len(timeseries)-1])
  return segment



if __name__ == '__main__':
  data = [(0,1),(1,2),(2,3),(3,4),(4,3),(5,2),(6,1)]
  print slide(data,0.1)
  print deltaExtrema(data,0.1)
  print regression(data,3)
  print "other data (rough plateau)"
  data = [(0,1),(1,2),(2,3),(3,4),(4,3.9),(5,4.1),(6,3)]
  print slide(data,1)
  print deltaExtrema(data,1)
  print "yet other data (stair case)"
  data = [(0,1),(1,2),(2,3),(3,2.8),(4,2.5),(5,4.1),(6,6)]
  print slide(data,1)
  print deltaExtrema(data,1)
  print deltaExtrema(data,1,0)
  data = [ (x,math.sin(x/100.0)) for x in xrange(1000)]
  print slide(data,0.1)
  print deltaExtrema(data,0.1)
  print deltaExtrema(data,0.1,0)


  #print "sin-like wave"
  #import Numeric
  #import random
  #data = [(x,Numeric.sin(x*x)+0.5+random.normalvariate(0,0.05)) for x in Numeric.arange(0.0,2.2,0.05)] \
  #         + [(x,Numeric.sin((4.4-x)*(4.4-x))+0.5+random.normalvariate(0,0.05)) for x in Numeric.arange(2.2,4.4,0.05)]
  #print slide(data,0.3)
  #print deltaExtrema(data,0.3,0)
  print "example requested by Franco from CERN"
  data = [(0,0.0),(1,2.5),(2,2.0),(3,0.5),(4,0.2),(5,4.0),(6,-3.0),(7,3.0),(8,3.5),(9,3.0),(10,2.0),(11,5.0)]
  theta = 0.6
  print deltaExtrema(data,0.6,detectflats=1)
  print deltaExtrema(data,0.6,detectflats=0)

     
