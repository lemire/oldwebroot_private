/**
 * (c) National Research Council of Canada, 2002-2003 by Daniel Lemire, Ph.D.
 * Email lemire at ondelette dot com for support and details.
 */

package algorithms;

import data.*;
import gnu.trove.*;

/**
 *  Most basis CFS.
 *
 *
 *  $Id: Average.java,v 1.8 2003/08/22 13:38:22 howsen Exp $
 *  $Date: 2003/08/22 13:38:22 $
 *  $Author: howsen $
 *  $Revision: 1.8 $
 *  $Log: Average.java,v $
 *  Revision 1.8  2003/08/22 13:38:22  howsen
 *  *** empty log message ***
 *
 *  Revision 1.7  2003/08/21 18:04:29  lemired
 *  Added toString method plus added necessary activation.jar for convenience.
 *
 *  Revision 1.6  2003/08/07 00:37:42  lemired
 *  Mostly, I updated the javadoc.
 *
 *
 *@author     Daniel Lemire
 *@since      December 2002
 */
public class Average
   extends CollaborativeFilteringSystem
{

   /**
    *  Constructor for the Average object
    *
    *@param  set  The EvaluationSet you want to work on
    */
   public Average(EvaluationSet set)
   {
      super(set);
   }

   /**
    *  Return an array that contains predictions for the ratings of the given
    *  user. Note that predictions over already rated items don't have to agree
       *  with the provided ratings. This algorithm takes time O(1) with respect to
    *  the number of users.
    *
    *@param  u  a set of one-dimensional ratings
    *@return    an array containing predictions
    */
   public float[] completeUser(TIntFloatHashMap u)
   {
      int[] indices = u.keys();
      if (indices.length == 0)
      {
	 return new float[mMaxItemID];
      }
      float average = UtilMath.average(u.getValues());
      // else compute the average
      float[] complete = new float[mMaxItemID];
      for (int k = 0; k < mMaxItemID; ++k)
      {
	 complete[k] = average;
      }
      return complete;
   }

   /**
    *  Updates the buffer of the algorithm when a user enters a new rating. For
    *  average, this does nothing.
    *
    *@param  u        User as it were before changes
    */
   /*
       *  public void updateUser( TIntFloatHashMap u, int itemNum, float newVal ) {
    *  }
    */
   /**
    *  This must called after you remove a user
    *
    *@param  u  the evaluation
    */
   public void removedUser(TIntFloatHashMap u)
   {
      // nothing to do!!!
   }

   /**
    *  This must called after you add a user
    *
    *@param  u  the evaluation
    */
   public void addedUser(TIntFloatHashMap u)
   {
      // nothing to do!!!
   }

   public String toString()
   {
      return "Average";
   }
}
