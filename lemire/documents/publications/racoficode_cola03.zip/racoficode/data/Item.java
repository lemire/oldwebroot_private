package data;

import java.io.*;
import java.util.*;

/**
 *  Metadata for an item object.
 *
 *@author     Nancy Howse
 *@since      July 12, 2003
 *@version    1.0
 */

public class Item {
	private String artist, album, url, label;
	private String releaseDate;
	private int numberOfTracks;
	private float priceInCents;
	int itemID;


	/**
	 *  Constructor for the Item object
	 */
	public Item()
				{ }


	/**
	 *  Constructor for the Item object
	 *
	 *@param  anArtist  artist name
	 *@param  anAlbum   album name
	 *@param  itemURL    URL for item
	 *@param  IDnum     Item key in SQL database
	 */
	public Item( String anArtist, String anAlbum, String itemURL, String Alabel, String AreleaseDate, int AnumberOfTracks, float ApriceInCents, int IDnum ) {
		artist = anArtist;
		album = anAlbum;
		url = itemURL;
		itemID = IDnum;
		label = Alabel;
		releaseDate = AreleaseDate;
		numberOfTracks = AnumberOfTracks;
		priceInCents = ApriceInCents;
	}
//String label, Date releaseDate, int numberOfTracks, float priceInCents
	public String getLabel() {
			return label;
	}
	public void setLabel(String l ) {
		label = l;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String d) {
		releaseDate = d;
	}
	public int getNumberOfTracks() {
		return numberOfTracks;
	}
	public void setNumberOfTracks(int t) {
		numberOfTracks = t;
	}
	public float getPriceInCents() {
		return priceInCents;
	}
	public void setPriceInCents(int p) {
		priceInCents = p;
	}
	/**
	 *  Gets the artist attribute of the Item object
	 *
	 *@return    The artist value
	 */
	public String getArtist() {
		return artist;
	}


	/**
	 *  Gets the album attribute of the Item object
	 *
	 *@return    The album value
	 */
	public String getAlbum() {
		return album;
	}


	/**
	 *  Gets the URL attribute of the Item object
	 *
	 *@return    The URL value
	 */
	public String getURL() {
		return url;
	}


	/**
	 *  Returns the itemID attribute of the Item object
	 *
	 *@return    int itemID value
	 */
	public int getItemID() {
		return itemID;
	}


	/**
	 *  Sets the artist attribute of the Item object
	 *
	 *@param  anArtist  The new artist value
	 */
	public void setArtist( String anArtist ) {
		artist = anArtist;
	}


	/**
	 *  Sets the album attribute of the Item object
	 *
	 *@param  anAlbum  The new album value
	 */
	public void setAlbum( String anAlbum ) {
		album = anAlbum;
	}


	/**
	 *  Sets the URL attribute of the Item object
	 *
	 *@param  itemURL  The new url value
	 */
	public void setURL( String itemURL ) {
		url = itemURL;
	}


	/**
	 *  Sets the itemID attribute of the Item object
	 *
	 *@param  IDnum  The new itemID value
	 */
	public void setItemID( int IDnum ) {
		itemID = IDnum;
	}
}

