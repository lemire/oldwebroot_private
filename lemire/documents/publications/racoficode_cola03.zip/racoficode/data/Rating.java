package data;


/**
 *  An object to model a given rating.
 *
 *@author     Daniel Lemire
 *@author     National Research Council of Canada
 *@created    August 3, 2003
 *@since      4 septembre 2002
 */
public class Rating {
	/**
	 *  These are user id and item id respectively
	 */
	public int mUser, mItem;
	/**
	 *  The value of the vote
	 */
	public float mVote;


	/**
	 *  Constructor for the Rating object
	 */
	public Rating() { }

}

