package data;

/**
* These exceptions are supposed to be bugs
*/
public class RacofiDataException extends RuntimeException {

	String message;
	public RacofiDataException()
	{
		super();
		message = "Exception in Racofi data package";
	}
	
	public RacofiDataException(String err)
	{
		super(err);     
		message = err;  
	}
	

	public String getError()
	{
		return message;
	}
}
