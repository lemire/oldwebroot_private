package data;
import java.util.LinkedHashMap;

import java.util.Map;

/**
 *  <p>
 *
 *  Extends LinkedHashMap data structure to specify the maximum
 *  entries to be contained in the hashmap and it also calls 
 * removedUser when items are removed.
 *
 *
 *@author     Nancy Howse
 *@created    August 3, 2003
 *@version    1.0
 */

public class LinkedHash extends LinkedHashMap {

	private  int MAX_ENTRIES = 5000;// no need for final, could change, except for the fact it is private!



	/**
	 *  Constructor for the LinkedHash object
	 */
	public LinkedHash() {
		super();
	}


	/**
	 *  Description of the Method
	 *
	 *@param  eldest  Description of the Parameter
	 *@return         Description of the Return Value
	 */
	protected boolean removeEldestEntry( Map.Entry eldest ) {
		return size() > MAX_ENTRIES;
	}


	/**
	 *  Description of the Method
	 *
	 *@param  o  Description of the Parameter
	 *@return    Description of the Return Value
	 */
	public Object remove( Object o ) {
		CFSSingleton cfss = CFSSingleton.getInstance();
		User user = (User) super.remove( o );
		if ( user != null )
			cfss.removedUser( user );
		return user;
	}


	/**
	 *  Gets the max attribute of the LinkedHash object
	 *
	 *@return    The max value
	 */
	/*public int getMax() {
		return MAX_ENTRIES;
	}*/

	public int getMaxSize() {
		return MAX_ENTRIES ;
	}
}
