/*
 * Sokoban for SuperWaba
 * (c) 2001 Daniel Lemire, Ph.D.
 * http://www.ondelette.com/lemire/Sobokan
 * Special thanks to Georges Ruban for the Jump version
 * http://www.geocities.com/george_ruban/WabaJump/JumpingSokoban.html
 * Original levels are due to Yoshio Murase.
 * Thanks to Peter Dickerson for fixing an byte to short bug.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3)


import waba.io.Catalog;
import waba.ui.*;

/**
 *  Main class for the Sokoban game!
 *
 *@author     Daniel Lemire
 *@created    September 27, 2001
 *@version 1.0.2
 */
public class Sokoban extends MainWindow {

	Button closeButton;
	Button clearButton;
	Button nextButton;
	Button previousButton;
	Gamepad gamepad;
	String name;
	int level;
	int MaxLevel;
	Title title;


	/**
	 *  Constructor for the Sokoban object
	 */
	public Sokoban() {
		gamepad = new Gamepad(this);
		name = "Sobokan (1.0.0) level ";
		level = 0;
		MaxLevel = -1;
		title = new Title(name + (level + 1) + "/" + (getMaxLevel() + 1), "(c) 2001 Daniel Lemire, Ph.D.");
		title.setRect(0, 0, super.width, 15);
		add(title);
		gamepad.setRect(0, 16, super.width, super.height - 40);
		add(gamepad);
		closeButton = new Button("Exit");
		closeButton.setRect(0, super.height - 15, closeButton.getPreferredWidth() + 5, closeButton.getPreferredHeight());
		add(closeButton);
		clearButton = new Button("Restart");
		clearButton.setRect(closeButton.getPreferredWidth() + 7, super.height - 15, clearButton.getPreferredWidth() + 10, clearButton.getPreferredHeight());
		add(clearButton);
		nextButton = new Button(">>");
		nextButton.setRect(closeButton.getPreferredWidth() + 18 + clearButton.getPreferredWidth(), super.height - 15, nextButton.getPreferredWidth() + 10, nextButton.getPreferredHeight());
		add(nextButton);
		previousButton = new Button("<<");
		previousButton.setRect(closeButton.getPreferredWidth() + 30 + clearButton.getPreferredWidth() + nextButton.getPreferredWidth(), super.height - 15, previousButton.getPreferredWidth() + 10, previousButton.getPreferredHeight());
		add(previousButton);
		enableButtons();
	}


	/**
	 *  Gets the MaxLevel attribute of the Sokoban object
	 *
	 *@return    The MaxLevel value
	 */
	public int getMaxLevel() {
		if (MaxLevel >= 0) {
			return MaxLevel;
		}
		Catalog catalog = new Catalog("Level.PUxL.DATA", 1);
		if (!catalog.isOpen()) {
			MaxLevel = 0;
			return 0;
		}
		int i = catalog.getRecordCount();
		if (i == 0) {
			MaxLevel = 0;
			return 0;
		}
		else {
			byte abyte0[] = new byte[2];
			catalog.setRecordPos(0);
			catalog.readBytes(abyte0, 0, 2);
			catalog.close();
			return MaxLevel = (abyte0[0] & 0xFF) + ((abyte0[1] & 0xFF) << 8);
		}
	}


	/**
	 *  Does nothing. Call on exit.
	 */
	public void onExit() {
	}


	/**
	 *  On start... will load the gamepad.
	 */
	public void onStart() {
		gamepad.reload();
	}


	/**
	 *  Manage event when user finished a level
	 */
	public void success() {
		gamepad.displayNow("You won!!!");
		gamepad.waitForInput();
	}


	/**
	 *  The player did let us know he has understood he won.
	 */
	public void playerKnowsHeWon() {
		moveToNextLevel();
	}


	/**
	 *  Moving game to next level
	 */
	public void moveToNextLevel() {
		level++;
		if (!gamepad.reload()) {
			level = 0;
			if (!gamepad.reload()) {
				display("Could not load first level!");
			}
		}
		else {
			gotToLevel(level);
		}
		enableButtons();
		gamepad.repaint();
		title.setName(name + (level + 1) + "/" + (getMaxLevel() + 1));
		title.repaint();
	}


	/**
	 *  Going back to previous level
	 */
	public void moveToPreviousLevel() {
		if (level == 0) {
			return;
		}
		level--;
		enableButtons();
		if (!gamepad.reload()) {
			display("Could not load previous level!");
		}
		else {
			gamepad.repaint();
			title.setName(name + (level + 1) + "/" + (getMaxLevel() + 1));
			title.repaint();
		}
	}


	/**
	 *  Display some string on the gamepad
	 *
	 *@param  s  string to display
	 */
	public void display(String s) {
		gamepad.display(s);
	}


	/**
	 *  Managing the events
	 *
	 *@param  event  your event
	 */
	public void onEvent(Event event) {
		if (event.type == 300) {
			if (event.target == closeButton) {
				exit(0);
			}
			else
					if (event.target == clearButton) {
				if (gamepad.reload()) {
					gamepad.repaint();
				}
				else {
					display("Could not reload!");
				}
			}
			else
					if (event.target == nextButton) {
				moveToNextLevel();
			}
			else
					if (event.target == previousButton) {
				moveToPreviousLevel();
			}
		}
	}


	/**
	 *  Saving the fact that the player got to a certain level
	 * (was modified slightly by George Ruban for compatibility with Jump)
	 *
	 *@param  i  the level he got to
	 */
	public void gotToLevel(int i) {
		if (i <= getMaxLevel()) {
			return;
		}
		MaxLevel = i;
		Catalog catalog = new Catalog("Level.PUxL.DATA", 4);
		if (!catalog.isOpen()) {
			return;
		}
		int j = catalog.getRecordCount();
		if (j == 0) {
			// catalog.addRecord(2, 0);
			catalog.addRecord(2);
		}
		byte abyte0[] = new byte[2];
		abyte0[0] = (byte) (i);
		abyte0[1] = (byte) (i >> 8);
		catalog.writeBytes( (abyte0[0] & 0xFF) + ((abyte0[1] & 0xFF) << 8), 0, 2);
		catalog.close();
	}


	/**
	 *  Enable the buttons
	 */
	private void enableButtons() {
		nextButton.setEnabled(level < getMaxLevel());
		nextButton.setVisible(level < getMaxLevel());
		previousButton.setEnabled(level > 0);
		previousButton.setVisible(level > 0);
	}
}


