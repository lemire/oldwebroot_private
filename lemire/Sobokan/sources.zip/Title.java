/*
 * Sokoban for SuperWaba
 * (c) 2001 Daniel Lemire, Ph.D.
 * http://www.ondelette.com/lemire/Sobokan
 * Special thanks to Georges Ruban for the Jump version
 * http://www.geocities.com/george_ruban/WabaJump/JumpingSokoban.html
 * Original levels are due to Yoshio Murase.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3)

import waba.fx.FontMetrics;
import waba.fx.Graphics;
import waba.ui.Control;
import waba.ui.Event;

/**
 *  A title bar
 *
 *@author     Daniel Lemire
 *@created    September 27, 2001
  *@version 1.0.2
 */
public class Title extends Control {

	String name;
	String copyright;
	boolean pressed;


	/**
	 *  Constructor for the Title object
	 *
	 *@param  s   String to display (name)
	 *@param  s1  Alternate string (when clicked!)
	 */
	public Title(String s, String s1) {
		name = s;
		copyright = s1;
	}


	/**
	 *  Sets the Name attribute of the Title object
	 *
	 *@param  s  The new Name value
	 */
	public void setName(String s) {
		name = s;
	}


	/**
	 *  Painting!
	 *
	 *@param  g  graphics
	 */
	public void onPaint(Graphics g) {
		g.setColor(0, 0, 0);
		int i = super.height - 1;
		g.drawLine(0, i, super.width, i);
		i--;
		g.drawLine(0, i, super.width, i);
		String s = name;
		if (pressed) {
			s = copyright;
		}
		int j = super.fm.getTextWidth(s) + 8;
		g.fillRect(0, 0, j, i);
		g.setColor(255, 255, 255);
		g.drawText(s, 4, 2);
	}


	/**
	 *  Description of the Method
	 *
	 *@param  event  Description of Parameter
	 */
	public void onEvent(Event event) {
		if (event.type == 200) {
			if (!pressed) {
				pressed = true;
				repaint();
			}
		}
		else
				if (event.type == 202 && pressed) {
			pressed = false;
			repaint();
		}
	}
}

