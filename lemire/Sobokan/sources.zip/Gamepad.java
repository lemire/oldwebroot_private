/*
 * Sokoban for SuperWaba
 * (c) 2001 Daniel Lemire, Ph.D.
 * http://www.ondelette.com/lemire/Sobokan
 * Special thanks to Georges Ruban for the Jump version
 * http://www.geocities.com/george_ruban/WabaJump/JumpingSokoban.html
 * Original levels are due to Yoshio Murase..
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3)


import waba.fx.*;
import waba.ui.*;
import waba.util.Vector;

/**
 *  The gamepad is a panel where we draw the tiles.
 *
 *@author     Daniel Lemire
 *@created    September 27, 2001
 *@version 1.0.2
 */
public class Gamepad extends Control {
	Tile mTile[];
	int mWidth;
	int mHeight;
	int mTileWidth;
	int mTileHeight;
	int lastX;
	int lastY;
	String name;
	String author;
	String filename;
	String mWarning;
	String mError;
	Vector mClef;
	Bonhomme mBonhomme;
	Graphics drawg;
	StringReader br;
	/*
	 * static final Image clef = new Image("images/clef.bmp");
	 * static final Image clefsurcible = new Image("images/clefsurcible.bmp");
	 * static final Image bonhomme = new Image("images/bonhomme.bmp");
	 * static final Image bonhommesurcible = new Image("images/bonhommesurcible.bmp");
	 */
	Sokoban mOwner;
	boolean mWaitForInput;
	int offbound;

	final static String first[] = {
			"Yoshio Murase 1", "######", "##  . #", "# * # #", "# .$  #", "#  #$##", "## @ #", " #####", "", "Yoshio Murase 2",
			"#######", "#  .@ #", "# #.# #", "#   $ #", "#.$$ ##", "#  ###", "####", "", "Yoshio Murase 3", "   ####",
			"#### @#", "#  *$ #", "#     #", "## .###", " #$ #", " # .#", " ####", "", "Yoshio Murase 4", "### ###",
			"#.###.#", "# #  .#", "# $$ @#", "#  $  #", "#  #  #", "#  ####", "####", "", "Yoshio Murase 5", "   ####",
			"   # @##", "####   #", "#. #$$ #", "#     ##", "#.  $##", "##.  #", " #####", "", "Yoshio Murase 6", "#####",
			"# ..####", "# $    #", "#  #$# #", "# @ .$ #", "########", "", "Yoshio Murase 7", "  #####", "###  .#", "# $ # #",
			"# *$  #", "# .#@ #", "#    ##", "#   ##", "#####", "", "Yoshio Murase 8", "#######", "#.  @.#", "#  $# ##",
			"# # $. #", "#   $# #", "####   #", "   #####", "", "Yoshio Murase 9", "#####", "#. .###", "#.#$$ #", "#   @ #",
			"# $#  #", "##   ##", " #####", "", "Yoshio Murase 10", "#####", "#.  ###", "# #   #", "# . # #", "# $*$ #",
			"##@ ###", " #  #", " ####", "", "Yoshio Murase 11", "########", "#.   . #", "# # #  #", "#@$  $.#", "##### $#",
			"    #  #", "    ####", "", "Yoshio Murase 12", "####", "#  #", "#  #####", "# .*   #", "##$    #", " # #$###",
			" #. @#", " #####", "", "Yoshio Murase 13", " #####", " # @ ###", "## .   #", "#. $.$ #", "##$# ###", " #   #",
			" #####", "", "Yoshio Murase 14", " #####", "##   #", "# $# #", "# . @##", "# *   #", "## #$ #", " #.  ##",
			" #####", "", "Yoshio Murase 15", " ####", "##  ####", "#..$  .#", "# #$ $ #", "#@  #  #", "#####  #", "    ####",
			"", "Yoshio Murase 16", " ######", " #  .@##", " #   $.#", " ###*# #", "##     #", "#  $  ##", "#   ###", "#####",
			"", "Yoshio Murase 17", " ####", " #@ #", " #  #", "##. ####", "# $$. .#", "#  $ ###", "###  #", "  ####",
			"", "Yoshio Murase 18", "#####", "#.  #", "# # ###", "# *$  #", "#  $. #", "#  @###", "#####", "",
			"Yoshio Murase 19", "  #####", "  #   #", "  # #.#", "###  .#", "#@ $$ #", "#  .$ #", "#######", "", "Yoshio Murase 20",
			"######", "#   @#", "# $# ###", "# * $  #", "#   ## #", "##.  . #", " ##   ##", "  #####", "", "Yoshio Murase 21",
			"######", "#   @##", "#  #  #", "#.  $ #", "# $$#.#", "###  .#", "  #####", "", "Yoshio Murase 22", "  ####",
			"###. #", "# .  ###", "#   $$ #", "## . $@#", " #######", "", "Yoshio Murase 23", " ######", "##@.  #", "# $$* #",
			"#  #  ##", "#  #  .#", "#### # #", "   #   #", "   #####", "", "Yoshio Murase 24", "    ####", "    #  #", "  ###$.#",
			"  #  . #", "###  #.#", "# $  $ #", "#   #@ #", "########", "", "Yoshio Murase 25", "#####", "#  .###", "# $.. #",
			"#  ##$##", "##  #  #", " #$   @#", " #  ####", " ####", "", "Yoshio Murase 26", "  ####", "  #  #", "  #  ###",
			"### .. #", "#  $#  #", "#  .$$ #", "#### @ #", "   #####", "", "Yoshio Murase 27", "#####", "#   ###", "# # *@##",
			"#  *   #", "###$   #", "  #   .#", "  ######", "", "Yoshio Murase 28", "  ######", "### .  #", "# $@#. #", "#  $# ##",
			"#  *  #", "##  # #", " ##   #", "  #####", "", "Yoshio Murase 29", " ####", "##  ###", "#     ##", "#  #$$@#",
			"#  . *.#", "########", "", "Yoshio Murase 30", " #######", "##@    #", "#. #   #", "# $$$.##", "# .#  #", "#  ####",
			"####", "", "Yoshio Murase 31", "########", "#      #", "# # ##*#", "# #@ $ #", "#.$ .  #", "#####  #", "    #  #",
			"    ####", "", "Yoshio Murase 32", " ######", " #@   ##", " ##$   #", "### .  #", "# $ #$##", "# .  .#", "####  #",
			"   ####", "", "Yoshio Murase 33", "#####", "#   ###", "#  $  #", "##$$ .#", " #@ . #", " ## # #", "  #  .#",
			"  #####", "", "Yoshio Murase 34", "#####", "#   ####", "# $$   #", "# .#.  #", "#  ## ##", "#  ##$#", "# @  .#",
			"#######", "", "Yoshio Murase 35", "######", "# .  #", "# .# ###", "# @$$  #", "# $.   #", "########", "",
			"Yoshio Murase 36", "########", "# @.#  #", "# .$ . #", "#  #$  #", "#  $  ##", "###  ##", "  #  #", "  ####", "",
			"Yoshio Murase 37", " #######", "##   . #", "# $  $@#", "#.$.####", "#  ##", "#  #", "#  #", "####", "",
			"Yoshio Murase 38", "######", "# .  #", "#  #@#", "#  $ ##", "##$#  #", "#   # #", "#. *  #", "#######", "",
			"Yoshio Murase 39", "   #####", "#### . #", "# *@ . #", "# $ #  #", "# #  $ #", "#   ####", "#####", "", "Yoshio Murase 40",
			"  ####", "###  ###", "# .. $.#", "#  $$ @#", "####   #", "   #####", "", "Yoshio Murase 41", "    ####", "    #@ #",
			"##### .#", "# $ $ $#", "#   .  #", "### .  #", "  ######", "", "Yoshio Murase 42", "########", "#   #  #", "# #.$ $#",
			"#   $  #", "#####. #", "  #   @#", "  #   .#", "  ######", "", "Yoshio Murase 43", "   ####", "  ##@ ##", " ##  ..#",
			"## $#$##", "#   $. #", "#  #   #", "#    ###", "######", "", "Yoshio Murase 44", "######", "#   @#", "# $$####",
			"# $ .  #", "## #.# #", "#.   # #", "#      #", "########", "", "Yoshio Murase 45", "   ####", "   #  #", "#### $##",
			"# @$.  #", "# ##   #", "#   ## #", "#   * .#", "########", "", "Yoshio Murase 46", "   #####", "   # @ #", " ###   #",
			" # $ $##", "## $  #", "#.  # #", "#..   #", "#######", "", "Yoshio Murase 47", "   #####", "####. @#", "#  .$  #",
			"# #  ###", "# $ $ .#", "####   #", "   #####", "", "Yoshio Murase 48", "########", "#  .# @#", "# # $  #", "# $.#$ #",
			"## .   #", " #  ####", " ####", "", "Yoshio Murase 49", "#######", "#     #", "#.## .#", "#*  $@#", "#  #$ #",
			"#  #  #", "#######", "", "Yoshio Murase 50", "####", "#. #", "# $#", "#  #####", "# .$ @ #", "# .$ # #",
			"###    #", "  ######", "", "Yoshio Murase 51", "########", "#      #", "# #$   #", "# $ @#.#", "##$#.  #", " #    .#",
			" #######", "", "Yoshio Murase 52", "######", "#  . #", "#    ###", "# #$$. #", "#.  ## #", "#@$ ## #", "###    #",
			"  ######"
			};
	static Wall mWall = new Wall();
	static Tile mNothing = new Tile();
	static Cible mCible = new Cible();
	final static Image clef = new Image(104, 16, 16);
	final static Image clefsurcible = new Image(105, 16, 16);
	final static Image bonhomme = new Image(101, 16, 16);
	final static Image bonhommesurcible = new Image(102, 16, 16);


	/**
	 *  Constructor for the Gamepad object
	 *
	 *@param  sokoban  the owner
	 */
	public Gamepad(Sokoban sokoban) {
		br = new StringReader(first);
		mWaitForInput = false;
		offbound = 0;
		mOwner = sokoban;
		mTileWidth = 16;
		mTileHeight = 16;
	}


	/**
	 *  Gets the Drawg attribute of the Gamepad object
	 *
	 *@return    The Graphics component
	 */
	public Graphics getDrawg() {
		if (drawg == null) {
			drawg = createGraphics();
		}
		return drawg;
	}


	/**
	 *  Reload the level
	 *
	 *@return    return false if something goes wrong
	 */
	public boolean reload() {
		displayNow("loading...");
		br.setLineOffset(0);
		if (mOwner.level > 0) {
			int i = 0;
			String s;
			while ((s = br.readLine()) != null) {
				if (s.length() == 0 && ++i == mOwner.level) {
					break;
				}
			}
			if (s == null) {
				displayError("C.E. " + br.toString());
				return false;
			}
		}
		name = br.readLine();
		if (name == null) {
			displayError("C.E. " + br.toString());
			return false;
		}
		Vector vector = new Vector();
		mWidth = 0;
		String s1;
		while ((s1 = br.readLine()) != null) {
			if (s1.length() == 0) {
				break;
			}
			vector.add(s1);
			if (mWidth < s1.length()) {
				mWidth = s1.length();
			}
		}
		mHeight = vector.getCount();
		mTile = new Tile[mWidth * mHeight];
		mClef = new Vector();
		int j = 0;
		for (int k = 0; k < mHeight; k++) {
			String s2 = (String) vector.get(k);
			for (int l = 0; l < mWidth; l++) {
				if (l >= s2.length()) {
					mTile[j++] = mNothing;
				}
				else {
					switch (s2.charAt(l)) {
						case 35:
							// '#'
							mTile[j++] = mWall;
							break;
						case 64:
							// '@'
							mBonhomme = new Bonhomme(j);
							mTile[j++] = mNothing;
							break;
						case 36:
							// '$'
							Clef clef1 = new Clef(j);
							mClef.add(clef1);
							mTile[j++] = mNothing;
							break;
						case 46:
							// '.'
							mTile[j++] = mCible;
							break;
						case 42:
							// '*'
							Clef clef2 = new Clef(j);
							mClef.add(clef2);
							mTile[j++] = mCible;
							break;
						default:
							mTile[j++] = mNothing;
							break;
					}
				}
			}

		}

		return true;
	}


	/**
	 *  Should we freeze the gamepad until user input?
	 */
	public void waitForInput() {
		mWaitForInput = true;
	}


	/**
	 *  Paint the gamepad
	 *
	 *@param  g  Graphics object
	 */
	public void onPaint(Graphics g) {
		g.setColor(0, 0, 0);
		if (mWarning != null) {
			g.drawText(mWarning, 32, 48);
			mWarning = null;
			return;
		}
		if (mError != null) {
			g.drawText(mError, 32, 64);
			mError = null;
			return;
		}
		if (mWidth == 0 || mHeight == 0) {
			g.drawText("Empty!!!", 32, 32);
			return;
		}
		for (int i = 0; i < mWidth; i++) {
			for (int j = 0; j < mHeight; j++) {
				Tile tile = mTile[i + j * mWidth];
				if (tile == null) {
					mTile[i + j * mWidth] = mNothing;
					tile = mNothing;
				}
				tile.paint(g, i * mTileWidth, j * mTileHeight, mTileWidth, mTileHeight);
			}

		}

		mBonhomme.paint(g);
		for (int k = 0; k < mClef.getCount(); k++) {
			Clef clef1 = (Clef) mClef.get(k);
			clef1.paint(g);
		}

	}


	/**
	 *  Manage the event when a key moved onto a target
	 */
	public void clefMovedOnCible() {
		for (int i = 0; i < mClef.getCount(); i++) {
			Clef clef1 = (Clef) mClef.get(i);
			if (mTile[clef1.getPosition()] != mCible) {
				return;
			}
		}

		mOwner.success();
	}


	/**
	 *  Display immediatly
	 *
	 *@param  s  some string you want to print 
	 */
	public void displayNow(String s) {
		getDrawg();
		int i = super.fm.getTextWidth(s) + 8;
		int j = super.fm.getHeight() + 4;
		drawg.setColor(255, 255, 255);
		drawg.fillRect(28, 46, i, j);
		drawg.setColor(0, 0, 0);
		drawg.drawRect(28, 46, i, j);
		drawg.drawText(s, 32, 48);
	}


	/**
	 *  Display some string whenever possible
	 *
	 *@param  s  the string
	 */
	public void display(String s) {
		mWarning = s;
		repaint();
	}


	/**
	 *  Display some error
	 *
	 *@param  s  description of the error
	 */
	public void displayError(String s) {
		mError = s;
		repaint();
	}


	/**
	 *  Manage events
	 *
	 *@param  event  your event
	 */
	public void onEvent(Event event) {
		getDrawg();
		if (event.type == 200) {
			// PenDown Event

			if (mWaitForInput) {
				mWaitForInput = false;
				mOwner.playerKnowsHeWon();
				return;
			}
			PenEvent penevent = (PenEvent) event;
			lastX = penevent.x / mTileWidth;
			lastY = penevent.y / mTileHeight;
			// display(penevent.x + "," + penevent.y + " " + lastX + "," + lastY);
			if (lastX < mWidth && lastY < mHeight) {
				offbound = 0;
				if (moveRequest()) {
					clefMovedOnCible();
				}
			}
			else {
				offbound++;
				if (offbound == 3) {
					offbound = 0;
					mOwner.success();
				}
			}
		}
		if (event.type != 202) {
			if (event.type != 203) {
				;
			}
		}
	}


	/**
	 *  User wants to move!
	 *
	 *@return    whether moving was permitted
	 */
	private boolean moveRequest() {
		int i = lastY * mWidth + lastX;
		// drawg.drawText(i + "/" + mTile.length, 100, 0);
		if (i >= mTile.length) {
			return false;
		}
		if (!mTile[i].canWalk()) {
			return false;
		}
		int j = mBonhomme.getPosition();
		if (j - i != -1 && j - i != 1 && j - i != mWidth && j - i != -mWidth) {
			return false;
		}
		boolean flag = false;
		for (int k = 0; k < mClef.getCount(); k++) {
			Clef clef1 = (Clef) mClef.get(k);
			if (clef1.getPosition() != i) {
				continue;
			}
			int l = 2 * i - j;
			if (l < 0 || l > mTile.length) {
				return false;
			}
			if (!mTile[l].canWalk()) {
				return false;
			}
			for (int i1 = 0; i1 < mClef.getCount(); i1++) {
				Clef clef2 = (Clef) mClef.get(i1);
				if (clef2.getPosition() == l) {
					return false;
				}
			}

			flag = mTile[l] == mCible;
			clef1.setPosition(l);
			clef1.paint(drawg);
			break;
		}

		mTile[j].paint(drawg, (j % mWidth) * mTileWidth, (j / mWidth) * mTileHeight, mTileWidth, mTileHeight);
		mBonhomme.setPosition(i);
		mBonhomme.paint(drawg);
		return flag;
	}


	/**
	 *  The fellow you are moving around!
	 *
	 *@author     Daniel Lemire
	 *@created    September 27, 2001
	 */
	final class Bonhomme extends Actor {

		/**
		 *  Constructor for the Bonhomme object
		 *
		 *@param  i  Description of Parameter
		 */
		public Bonhomme(int i) {
			super(i);
		}


		/**
		 *  Painting!
		 *
		 *@param  g  graphics
		 */
		public void paint(Graphics g) {
			int i = (getPosition() % mWidth) * mTileWidth;
			int j = (getPosition() / mWidth) * mTileHeight;
			if (mTile[super.mPosition] == Gamepad.mCible) {
				g.drawImage(Gamepad.bonhommesurcible, i, j);
			}
			else {
				g.drawImage(Gamepad.bonhomme, i, j);
			}
		}
	}


	/**
	 *  Some key object
	 *
	 *@author     Daniel Lemire
	 *@created    September 27, 2001
	 */
	final class Clef extends Actor {

		/**
		 *  Constructor for the Clef object
		 *
		 *@param  i  starting position (tile number)
		 */
		public Clef(int i) {
			super(i);
		}


		/**
		 *  Painting!
		 *
		 *@param  g  graphics
		 */
		public void paint(Graphics g) {
			int i = (getPosition() % mWidth) * mTileWidth;
			int j = (getPosition() / mWidth) * mTileHeight;
			if (mTile[super.mPosition] == Gamepad.mCible) {
				g.drawImage(Gamepad.clefsurcible, i, j);
			}
			else {
				g.drawImage(Gamepad.clef, i, j);
			}
		}
	}


	/**
	 *  Abstract class to model objects!
	 *
	 *@author     Daniel Lemire
	 *@created    September 27, 2001
	 */
	class Actor {

		int mPosition;


		/**
		 *  Constructor for the Actor object
		 *
		 *@param  i  starting position (tile number)
		 */
		public Actor(int i) {
			mPosition = i;
		}


		/**
		 *  Sets the Position attribute of the Actor object
		 *
		 *@param  i  The new Position value
		 */
		public void setPosition(int i) {
			mPosition = i;
		}


		/**
		 *  Gets the Position attribute of the Actor object
		 *
		 *@return    The Position value
		 */
		public int getPosition() {
			return mPosition;
		}


		/**
		 *  Paint now! you should overwrite this since it does nothing!
		 *
		 *@param  g  graphics
		 */
		public void paint(Graphics g) {
		}
	}

}

