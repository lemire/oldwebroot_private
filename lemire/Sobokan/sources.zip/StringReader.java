/*
 * Sokoban for SuperWaba
 * (c) 2001 Daniel Lemire, Ph.D.
 * http://www.ondelette.com/lemire/Sobokan
 * Special thanks to Georges Ruban for the Jump version
 * http://www.geocities.com/george_ruban/WabaJump/JumpingSokoban.html
 * Original levels are due to Yoshio Murase.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3)


/**
 *  A simple reader for strings
 *
 *@author     Daniel Lemire
 *@created    September 27, 2001
 *@version 1.0.2
 */
final class StringReader {

	String data[];
	int offset;


	/**
	 *  Constructor for the StringReader object
	 *
	 *@param  as  Description of Parameter
	 */
	public StringReader(String as[]) {
		data = as;
		offset = 0;
	}


	/**
	 *  Sets the LineOffset attribute of the StringReader object
	 *
	 *@param  i  The new LineOffset value
	 */
	public void setLineOffset(int i) {
		offset = i;
	}


	/**
	 *  Description of the Method
	 *
	 *@return    Description of the Returned Value
	 */
	public String readLine() {
		if (offset >= data.length) {
			return null;
		}
		else {
			return data[offset++];
		}
	}
}

