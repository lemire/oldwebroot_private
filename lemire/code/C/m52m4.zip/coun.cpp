#include "mat.h"
#include <iostream.h>

int main (int argc, char *argv[]) {
	char * OpenMode = "r";
	char * WriteMode = "w4";
	MATFile * SourceMAT = matOpen(argv[1], OpenMode);
	MATFile * DestinationMAT = matOpen(argv[2], WriteMode);
	mxArray * CurrentArray;
	while((CurrentArray=matGetNextArray(SourceMAT))!= NULL){
		if(matPutArray(DestinationMAT, CurrentArray)!=0)
			return(1);
	}
	
	if(matClose(SourceMAT)!=0)
		return(2);
	if(matClose(DestinationMAT)!=0)
		return(3);
	return(0);
}
