
L'ex�cutable coun.exe exige les DLL : libmat.dll, libmx.dll et libut.dll.
Les DLL en question sont disponibles directement (et gratuitement)
de MathSoft :

FTP  :  ftp.mathsoft.com
Web  :  www.mathsoft.com


____________________________________________________________________

Daniel Lemire, docteur en math�matiques de l'ing�nieur
26 mai 1999

