
package Applet.morse;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public final class Morse extends Applet implements Runnable {

  private boolean isStandalone = false;
  private String forecolor;
  private String background;
  private String soundname;
  private int delaimot, delailigne, delaipage, lignes, w, dist, posy;
  public boolean center;
  private String[] ligne=new String[16];
  private FontMetrics fm;
  private Thread machine;
  private String[] lignesString;
  private AudioClip clip;

  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  public void init() {
    try { forecolor = this.getParameter("Couleur du Texte", "#00FF00"); } catch (Exception e) { e.printStackTrace(); }
    try { background = this.getParameter("Couleur du fond", "#000000"); } catch (Exception e) { e.printStackTrace(); }
    try { soundname = this.getParameter("son", ""); } catch (Exception e) { e.printStackTrace(); }
    try { delaimot = Integer.parseInt(this.getParameter("delai-mot", "100")); } catch (Exception e) { e.printStackTrace(); }
    try { delailigne = Integer.parseInt(this.getParameter("delai-ligne", "500")); } catch (Exception e) { e.printStackTrace(); }
    try { delaipage = Integer.parseInt(this.getParameter("delai-page", "1000")); } catch (Exception e) { e.printStackTrace(); }
    try { lignes = Integer.parseInt(this.getParameter("lignes", "4")); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[0] = this.getParameter("ligne1", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[1] = this.getParameter("ligne2", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[2] = this.getParameter("ligne3", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[3] = this.getParameter("ligne4", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[4] = this.getParameter("ligne5", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[5] = this.getParameter("ligne6", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[6] = this.getParameter("ligne7", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[7] = this.getParameter("ligne8", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[8] = this.getParameter("ligne9", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[9] = this.getParameter("ligne10", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[10] = this.getParameter("ligne11", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[11] = this.getParameter("ligne12", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[12] = this.getParameter("ligne13", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[13] = this.getParameter("ligne14", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[14] = this.getParameter("ligne15", ""); } catch (Exception e) { e.printStackTrace(); }
    try { ligne[15] = this.getParameter("ligne16", ""); } catch (Exception e) { e.printStackTrace(); }
    int r=Integer.valueOf(forecolor.substring(1,3),16).intValue();
    int g=Integer.valueOf(forecolor.substring(3,5),16).intValue();
    int b=Integer.valueOf(forecolor.substring(5,7),16).intValue();
    this.setForeground(new Color(r,g,b));
    r=Integer.valueOf(background.substring(1,3),16).intValue();
    g=Integer.valueOf(background.substring(3,5),16).intValue();
    b=Integer.valueOf(background.substring(5,7),16).intValue();
    this.setBackground(new Color(r,g,b));
    int haut=this.getSize().height;
    clip=getAudioClip(getCodeBase(), soundname);
    center=true;
    this.showStatus(this.getAppletInfo());
 		this.setFont(new Font(getToolkit().getFontList()[0],Font.BOLD,12));
    fm=Toolkit.getDefaultToolkit().getFontMetrics(this.getFont());
    double distdouble=Math.round((haut)/((double) lignes)-(double)fm.getHeight());
    dist=new Double(distdouble).intValue();
  }

  public void start() {
    machine=new Thread(this);
    machine.start();
  }

  public void stop() {
    machine.stop();
    machine=null;
  }

  public void destroy() {
	  clip=null;
  }


	public void update(Graphics g) {
	    paint(g);
	}

  public void paint(Graphics g) {
    Image offscreen=createImage(this.getSize().width,this.getSize().height);
    Graphics offg=offscreen.getGraphics();
    try {
      if(lignesString!=null) {
        if(center) {
              for(int k=0;k<lignesString.length;k++) {
                offg.drawString(lignesString[k],(int) Math.round((this.getSize().width-fm.stringWidth(lignesString[k]))/2.0),(dist+fm.getHeight())*k+fm.getHeight()+posy);
              }

        } else {
              for(int k=0;k<lignesString.length;k++) {
                offg.drawString(lignesString[k],0,(dist+fm.getHeight())*k+fm.getHeight()+posy);
              }
        }
      }
      g.drawImage(offscreen,0,0,this);
    } finally {
      offg.dispose();
    }

  }

  public String getAppletInfo() {
    return "Applet Morse (c) 1998-1999 Daniel Lemire version 0.6";
  }
//Get parameter info

  public String[][] getParameterInfo() {
    String pinfo[][] =
    {
      {"Couleur du Texte", "String", "Couleur du texte"},
      {"Couleur du fond", "String", "Couleur du fond de l'�cran"},
      {"son", "String", "Nom de fichier de son"},
      {"delai-mot", "int", "d�lai entre chaque lettres"},
      {"delai-ligne", "int", "d�lai entre chaque ligne"},
      {"delai-page", "int", "d�lai entre chaque page"},
      {"lignes", "int", "nombre de lignes par page"},
      {"ligne1", "String", "Contenu de la ligne 1"},
      {"ligne2", "String", "Contenu de la ligne 2"},
      {"ligne3", "String", "Contenu de la ligne 3"},
      {"ligne4", "String", "Contenu de la ligne 4"},
      {"ligne5", "String", "Contenu de la ligne 5"},
      {"ligne6", "String", "Contenu de la ligne 6"},
      {"ligne7", "String", "Contenu de la ligne 7"},
      {"ligne8", "String", "Contenu de la ligne 8"},
      {"ligne9", "String", "Contenu de la ligne 9"},
      {"ligne10", "String", "Contenu de la ligne 10"},
      {"ligne11", "String", "Contenu de la ligne 11"},
      {"ligne12", "String", "Contenu de la ligne 12"},
      {"ligne13", "String", "Contenu de la ligne 13"},
      {"ligne14", "String", "Contenu de la ligne 14"},
      {"ligne15", "String", "Contenu de la ligne 15"},
      {"ligne16", "String", "Contenu de la ligne 16"},
    };
    return pinfo;
  }

  public void run() {
    Thread me=Thread.currentThread();
    while (me==machine) {
        me.setPriority(Thread.MAX_PRIORITY);
        lignesString=new String[lignes];
        for(int page=0;page<16/(double)lignes;page++) {
          for(int k=0;k<lignes;k++) {
            lignesString[k]=new String();
          }
          for(int k=0;k<lignes;k++) {
            for(int l=0;l<ligne[k+page*lignes].length();l++) {
              if (l<ligne[k+page*lignes].length()-1) {
                synchronized(this) {
                  lignesString[k]=ligne[k+page*lignes].substring(0,l+1).concat("_");
                  repaint();
                }
              }
              if((clip!=null)&&(!ligne[k+page*lignes].substring(l,l+1).equals(" "))) {
                synchronized(this) {
                clip.stop();
                clip.play();
              }
            }
            try {
              Thread.currentThread().sleep(delaimot);
            } catch(InterruptedException e) {}
            synchronized(this) {
              lignesString[k]=ligne[k+page*lignes].substring(0,l+1);
              repaint();
            }
          }
          try {
            Thread.currentThread().sleep(delailigne);
          } catch(InterruptedException e) {}
        }
        System.gc();
        try {
          Thread.currentThread().sleep(delaipage);
        } catch(InterruptedException e) {}

        for(posy=0;posy<this.getSize().height;posy++) {
          try {
            Thread.currentThread().sleep(5);
          } catch(InterruptedException e) {}
          repaint();
        }
        posy=0;
      }
    }
  }
}

