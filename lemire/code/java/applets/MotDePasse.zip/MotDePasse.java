import java.applet.*;
import java.awt.*; // Classes pour le graphisme
import java.net.*; // Classes pour l'utilisation de liens internet (URL)
import java.io.*;

public class MotDePasse extends Applet
{
	String pageSecrete;
  	String motdepasse;
	TextField tx; // D�claration d'un object de type bo�te de saisie
	String str; //Deux objects de type String
	boolean saisie; /* Est-ce que l'utilisateur vient d'entrer un mot de passe
					invalide ? */
	boolean depart; // On redessine l'applet pour une derni�re fois ?
	boolean urlValable; // Est-ce que le lien � suivre est correct ?
	URL url; // Pour stocker l'adresse internet du lien � suivre
  	String[] message={"Applet inop�rante!","Lien URL invalide.","Entrez le mot de passe.","Mot de passe incorrect!","Au revoir!"};
  	int[] w=new int[message.length];


	public void init() // premi�re m�thode appel�e par l'applet
	{
    		// Initialisation de quelques variables
		urlValable=true;
		try { //On essaie de valider le lien
			URL urlconfig = new URL(getDocumentBase(),"secret.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(urlconfig.openStream() ));
			motdepasse = br.readLine().trim();
			pageSecrete = br.readLine().trim();
			br.close();
			url=new URL(getDocumentBase(),pageSecrete);			

		} catch(MalformedURLException erreur1) {
			urlValable=false;
			erreur1.printStackTrace();
		} catch(IOException ioe) {
			urlValable=false;
			ioe.printStackTrace();
		}
		if (url==null) {urlValable=false;}
		//System.out.println(url);

		//currentFont.size=Font.BOLD;
		this.setFont(new Font(getToolkit().getFontList()[0],Font.BOLD,12));
    		FontMetrics fm=getToolkit().getFontMetrics(this.getFont());
		//this.setFont(currentFont.deriveFont(Font.BOLD));
		saisie=false;
		depart=false;
		//Interface
		tx=new TextField(20);
		tx.setEchoCharacter('*'); // caract�re � retourner lorsque l'utilisateur
								// appuie sur une touche
		add(tx); // C'est ici que l'on ajoute la bo�te de saisie � l'interface
		add(new Button("Confirmation")); // On ajoute le bouton � l'interface
			/* Notons que je ne sp�cifie pas o� le bouton et la bo�te de saisie
			   seront plac�s ! Je laisse Java s'en occuper. */
   		for(int k=0;k<w.length;k++) {
         		w[k]=(int) Math.round((size().width-fm.stringWidth(message[k]))/2.0);
   		}

	}



	public boolean action(Event e, Object o) {
		if (urlValable==true) {
			str=tx.getText();
			if(str.equals(motdepasse)) { //Mot de passe correct.
					System.out.println("Mot de passe correct.");
					depart=true;	//on part !
			}
			else {   //Mot de passe incorrect.
				saisie=true;
			}
			repaint(); // On redessine l'applet

		}
		tx.setText(""); //remise � z�ro de la bo�te de saisie
		return true;
	}


	public void paint(Graphics g)
	{

		if(urlValable==false) {

			g.drawString(message[0],w[0],75);
			g.drawString(message[1],w[1],90);
		} else {
			g.drawString(message[2],w[2],90);//et cliquez.
			if (saisie==true) {
				g.drawString(message[3],w[3],75);
				saisie=false;
			}
			if(depart==true) {
				g.drawString(message[4],w[4],75);
				depart=false; // un peu de m�nage avant de repartir !
				getAppletContext().showDocument(url);
			}
		}
	}







	public String getAppletInfo()
	{
		return "Nom: MotDePasse\r\n" +
		       "Auteur: Daniel Lemire\r\n"+
				"vaguement inspir� d'un programme par M�urers et Baufeld";
	}

}
