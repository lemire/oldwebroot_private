#ifndef __WAVELET_H__
#define __WAVELET_H__

/**
 *  Cohen-Daubechies-Feauveau adapted to the interval with N=2 and Ntilde=4
 *   Free software - use at your risks (commercial usage allowed)
 *  
 * For support: Wavelet Forum http://www.ondelette.com/indexfr.html (French) or 
 * http://www.ondelette.com/indexen.html (English)
 *
 * Reference:
 * 
 * Gilles Deslauriers, Serge Dubuc and Daniel Lemire, Une famille
 * d'ondelettes biorthogonales sur l'intervalle obtenue par un
 * sch�ma d'interpolation it�rative, Ann. Sci. Math. Qu�bec 23 (1999), no. 1, 37-48. 
 * English title: "A family of biorthogonal wavelets on the interval derived
 * from an interpolatory subdivision scheme"
 *
 * URL (article) : 
 *  http://www.ondelette.com/lemire/abstracts/ANNQC1999.html
 *
 * This code was also used in the production of the following paper:
 * 
 * Daniel Lemire, Chantal Pharand, Jean-Claude Rajaonah, Bruno Dub�, A.-Robert LeBlanc,
 * Wavelet time entropy, T wave morphology and myocardial ischemia, IEEE Transactions in
 *  Biomedical Engineering, vol. 47, no. 7, July 2000.
 * 
 * http://www.ondelette.com/lemire/abstracts/IEEE2000.html
 *
 * C++ port from java Rybalko Oxana oribalko@hotmail.com
 *
 * @author Daniel Lemire
 */

//The structures look awkward compared to corresponding java code since in java 
//arrays with variable dimentions are permitted.

//1. scaleLeft1,scaleLeft2,scaleLeft3,scaleLeft4 are equivalent to scaleLeft in java code
//2. scaleRight1,scaleRight2,scaleRight3,scaleRight4 are equivalent to scaleRight 
//3. waveletPrimaryLeft1, waveletPrimaryLeft2 are equivalent to waveletPrimaryLeft
//4. waveletPrimaryRight1, waveletPrimaryRight2 are equivalent to waveletPrimaryRight

#include <iostream>


const int FilterType = 1;
#define DEPTH 15

#define SCALE_SIZE 9
static const float scale[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.17677669529663687f, 0.41984465132951254f, 0.9943689110435824f,
0.41984465132951254f, -0.17677669529663687f, -0.06629126073623882f,
0.03314563036811941f};

#define LEFT_SCALES_NUMBER 4
#define SCALE_LEFT1_SIZE 5
#define SCALE_LEFT2_SIZE 7
#define SCALE_LEFT3_SIZE 9
#define SCALE_LEFT4_SIZE 11

static const float scaleLeft1[] = {1.0275145414117017f, 0.7733980419227863f,
-0.22097086912079608f, -0.3314563036811941f, 0.16572815184059705f};
static const float scaleLeft2[] = {-0.22189158107546605f, 0.4437831621509321f,
0.902297715576584f, 0.5800485314420897f, -0.25687863535292543f,
-0.06629126073623882f, 0.03314563036811941f};
static const float scaleLeft3[] = 
{0.07549838028293866f, -0.15099676056587732f,
-0.0957540432856783f, 0.34250484713723395f, 1.0330388131397217f,
0.41984465132951254f, -0.17677669529663687f, -0.06629126073623882f,
0.03314563036811941f};
static const float scaleLeft4[] = 
{-0.013810679320049755f, 0.02762135864009951f,
0.011048543456039804f, -0.04971844555217912f, -0.18506310288866673f,
0.41984465132951254f, 0.9943689110435824f, 0.41984465132951254f,
-0.17677669529663687f, -0.06629126073623882f, 0.03314563036811941f};

#define RIGHT_SCALES_NUMBER 4
#define SCALE_RIGHT1_SIZE 11
#define SCALE_RIGHT2_SIZE 9
#define SCALE_RIGHT3_SIZE 7
#define SCALE_RIGHT4_SIZE 5
static const float scaleRight1[] = {0.03314563036811941f,
-0.06629126073623882f, -0.17677669529663687f, 0.41984465132951254f,
0.9943689110435824f, 0.41984465132951254f, -0.18506310288866673f,
-0.04971844555217912f, 0.011048543456039804f, 0.02762135864009951f,
-0.013810679320049755f};
static const float scaleRight2[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.17677669529663687f, 0.41984465132951254f, 1.0330388131397217f,
0.34250484713723395f, -0.0957540432856783f, -0.15099676056587732f,
0.07549838028293866f};
static const float scaleRight3[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.25687863535292543f, 0.5800485314420897f, 0.902297715576584f,
0.4437831621509321f, -0.22189158107546605f};
static const float scaleRight4[] = 
{0.16572815184059705f, -0.3314563036811941f,
-0.22097086912079608f, 0.7733980419227863f, 1.0275145414117017f};


#define SCALE_PRIMARY_SIZE 3
static const float scalePrimary[] = 
{0.35355339059327373f, 0.7071067811865475f, 0.35355339059327373f};

#define SCALES_PRIMARY_LEFT 1
#define SCALE_PRIMARY_LEFT_SIZE 2
static const float scalePrimaryLeft[] = {0.7071067811865475f, 0.35355339059327373f};

#define SCALES_PRIMARY_RIGHT 1
#define SCALE_PRIMARY_RIGHT_SIZE 2
static const float scalePrimaryRight[] = {0.35355339059327373f, 0.7071067811865475f};


#define WAVELET_SIZE 3
static const float wavelet[] = {-0.5f, 1.0f, -0.5f};


#define WAVELET_PRIMARY_SIZE 9
static const float waveletPrimary[] = {0.0234375f, 0.046875f, -0.125f,
-0.296875f, 0.703125f, -0.296875f, -0.125f, 0.046875f, 0.0234375f};


#define WAVELETES_PRIMARY_LEFT 2
#define WAVELET_PRIMARY_LEFT1 8
#define WAVELET_PRIMARY_LEFT2 8
static const float waveletPrimaryLeft1[] = 
{-0.546875f, 0.5696614583333334f
, -0.3138020833333333f, -0.103515625f, 0.10677083333333333f,
0.043619791666666664f, -0.01953125f, -0.009765625f};
static const float waveletPrimaryLeft2[] = 
{0.234375f, -0.087890625f, -0.41015625f, 0.673828125f,
-0.2421875f, -0.103515625f, 0.03515625f, 0.017578125f};

#define WAVELETES_PRIMARY_RIGHT 2
#define WAVELET_PRIMARY_RIGHT1 8
#define WAVELET_PRIMARY_RIGHT2 8
static const float waveletPrimaryRight1[] = 
{0.017578125f, 0.03515625f,
-0.103515625f, -0.2421875f, 0.673828125f, -0.41015625f, -0.087890625f,
0.234375f};
static const float waveletPrimaryRight2[] =
{-0.009765625f, -0.01953125f, 0.043619791666666664f,
0.10677083333333333f, -0.103515625f, -0.3138020833333333f,
0.5696614583333334f, -0.546875f};


class FastCDF2_4 
{
 
public:
 
 FastCDF2_4(){}
 
 class IllegalArgumentException{};
 
 void transform(int length, float *v, int last);
 void transform(int length, float *v);

 void invTransform(int length, float *v, int last);
 void invTransform(int length, float *v);
};


#endif //__WAVELET_H__

