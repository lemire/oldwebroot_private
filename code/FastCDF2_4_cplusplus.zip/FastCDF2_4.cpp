

#include "FastCDF2_4.h"

using namespace std;

void FastCDF2_4::transform(int length, float *v) 
{
 for (int last = length; last >= DEPTH; last = (last + FilterType) / 2) 
 transform(length, v, last);
}

void FastCDF2_4::transform(int length, float *v, int last) 
{
 int k, l;
 int ans_len = last;
 float *ans = new float[last];
 
 // initialize!
 for(int ii = 0; ii < last; ii++) 
 ans[ii] = 0.0;
 
 int half = (last + FilterType) / 2;

 if ((2 * half - FilterType) != last) {
 cout << "Illegal subband : " << last << " within array of length " << length << endl;
 throw IllegalArgumentException();
 }
 
 //lowpass
 for (l = 0; l < SCALE_LEFT1_SIZE; l++) {
 ans[0] += scaleLeft1[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT2_SIZE; l++) {
 ans[1] += scaleLeft2[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT3_SIZE; l++) {
 ans[2] += scaleLeft3[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT4_SIZE; l++) {
 ans[3] += scaleLeft4[l] * v[l];
 }
 
 for (k = LEFT_SCALES_NUMBER; k < half - RIGHT_SCALES_NUMBER; k++) {
 for (l = 0; l < SCALE_SIZE; l++) {
 ans[k] += scale[l] * v[2 * k + l - LEFT_SCALES_NUMBER];
 }
 }

 for (l = 0; l < SCALE_RIGHT1_SIZE; l++) {
 ans[0 + half - RIGHT_SCALES_NUMBER] += scaleRight1[l] * v[last - SCALE_RIGHT1_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT2_SIZE; l++) {
 ans[1 + half - RIGHT_SCALES_NUMBER] += scaleRight2[l] * v[last - SCALE_RIGHT2_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT3_SIZE; l++) {
 ans[2 + half - RIGHT_SCALES_NUMBER] += scaleRight3[l] * v[last - SCALE_RIGHT3_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT4_SIZE; l++) {
 ans[3 + half - RIGHT_SCALES_NUMBER] += scaleRight4[l] * v[last - SCALE_RIGHT4_SIZE + l];
 }

 //highpass
 for ( k = 0; k < half - FilterType; k++) {
 for (l = 0; l < WAVELET_SIZE; l++) {
 ans[k + half] += wavelet[l] * v[2 * k + l];
 }
 }
 
 for( k = 0; k < ans_len; k++) {
 v[k] = ans[k];
 }

 delete[] ans;

}

void FastCDF2_4::invTransform(int /*length*/, float *v, int last) 
{
 int k, l;
 int ans_len = 2*last - FilterType;
 float *ans = new float[ans_len];

 // initialize!
 for(int ii = 0; ii < ans_len; ii++) 
 ans[ii] = 0.0;

 //scale coefficients 
 for (l = 0; l < SCALE_PRIMARY_LEFT_SIZE; l++) {
 ans[l] += scalePrimaryLeft[l] * v[0];
 }

 
 for (k = SCALES_PRIMARY_LEFT; k < last - SCALES_PRIMARY_RIGHT; k++) {
 for (l = 0; l < SCALE_PRIMARY_SIZE; l++) {
 ans[2 * k - FilterType + l] += scalePrimary[l] * v[k];
 }
 }

 //for each of SCALES_PRIMARY_RIGHT
 int iSCALES_PRIMARY_RIGHT = SCALES_PRIMARY_RIGHT - 1;
 for (l = 0; l < SCALE_PRIMARY_RIGHT_SIZE; l++) {
 ans[l - SCALE_PRIMARY_RIGHT_SIZE + ans_len] +=
 scalePrimaryRight[l] * v[iSCALES_PRIMARY_RIGHT + last - SCALES_PRIMARY_RIGHT];
 
 }
 
 //for each of WAVELET_PRIMARY_RIGHT
 int iWAVELETES_PRIMARY_LEFT = WAVELETES_PRIMARY_LEFT - 2;
 for (l = 0; l < WAVELET_PRIMARY_LEFT1; l++) {
 ans[l] += waveletPrimaryLeft1[l] * v[iWAVELETES_PRIMARY_LEFT + last];
 }
 
 iWAVELETES_PRIMARY_LEFT += 1;
 for (l = 0; l < WAVELET_PRIMARY_LEFT2; l++) {
 ans[l] += waveletPrimaryLeft2[l] * v[iWAVELETES_PRIMARY_LEFT + last];
 }
 
 for ( k = WAVELETES_PRIMARY_LEFT; k < last - FilterType
 - WAVELETES_PRIMARY_LEFT; k++) {
 for (l = 0; l < WAVELET_PRIMARY_SIZE; l++) {
 ans[2 * (k - FilterType) - 1 + l] += waveletPrimary[l] * v[k + last];
 }
 }
 
 //for each of WAVELET_PRIMARY_RIGHT
 int iWAVELETES_PRIMARY_RIGHT = WAVELETES_PRIMARY_RIGHT - 2;
 for (l = 0; l < WAVELET_PRIMARY_RIGHT1; l++) {
 ans[l - WAVELET_PRIMARY_RIGHT1 + ans_len] +=
 waveletPrimaryRight1[l] * v[iWAVELETES_PRIMARY_RIGHT + 2 * last - FilterType -
 WAVELETES_PRIMARY_RIGHT];
 }
 
 iWAVELETES_PRIMARY_RIGHT = iWAVELETES_PRIMARY_RIGHT + 1;
 for (l = 0; l < WAVELET_PRIMARY_RIGHT2; l++) {
 ans[l - WAVELET_PRIMARY_RIGHT2 + ans_len] +=
 waveletPrimaryRight2[l] * v[iWAVELETES_PRIMARY_RIGHT + 2 * last - FilterType -
 WAVELETES_PRIMARY_RIGHT];
 }
 
 for( k = 0; k < ans_len; k++) {
 v[k] = ans[k];
 }
 
 delete[] ans;
}

void FastCDF2_4::invTransform(int length, float *v) 
{
 int last;
 for (last = length; last >= DEPTH; last = last / 2 + FilterType) {
 ;
 }
 for (; 2 * last - FilterType <= length; last = 2 * last - FilterType) {
 invTransform(length, v, last);
 }
}

