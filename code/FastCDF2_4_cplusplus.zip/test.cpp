 

#include "FastCDF2_4.h"
using namespace std;
int main(int /*argc*/, char* /*argv[]*/){
 const int LENGTH = 33; // choose your length to be a power of 2 + 1
  // this is a test, just for fun!
 float data[LENGTH];
 // initialize!
 {for(int k = 0; k < LENGTH; k++) data[k] = 1.0f;}
 
 // transform (one step only!)
 FastCDF2_4 cdf;
 
 cdf.transform(LENGTH, data);

 // print out transformed data (one data element per row!)
 cout << "--Transformed data--\n";
 {for(int k = 0; k < LENGTH; ++k) 
   cout << "data[ " << k << " ]= " << data[k] << endl;}


 cdf.invTransform(LENGTH, data);

 cout << "--Recovered data--\n"; 
 {for(int k = 0; k < LENGTH; ++k) 
   cout << "data[ " << k << " ]= " << data[k] << endl;}

 return 0;
}
