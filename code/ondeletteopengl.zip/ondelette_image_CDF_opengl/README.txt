
/**************************************************
* Fichiers : texture.h, ondelette_image_CDF.cpp
* Format : openGL (GLUT) avec C++
*
* (c) 2003-2004 Benjamin Jacquin 
* benjamin.jacquin@utt.fr
* benjamin.jacquin@voila.fr
* actuellement en th�se � l'UTT (Universit� de Technologie de Troyes), France
* laboratoire ISTIT - m2s
* (Institut des Sciences et Technologies de l�Information de Troyes - Mod�lisation et S�ret� des Syst�mes)
* th�se d�but�e en octobre 2003
* domaine : traitement du signal et des images
*
* Derni�re modification le 31 juillet 2004
*
* Programme de transformation d'une image par ondelettes Cohen-Daubechies-Feauveau.
*
* Ce programme peut �tre modifi� tr�s simplement pour utiliser d'autres ondelettes.
*
* compil� sous visual C++ 6.0
* le programme fonctionne tel quel sous toutes les versions de Windows.
*
* sous linux, v�rifiez si les biblioth�ques openGL sont d�j� install�es
* sinon il faut aller chercher le bon package sur internet (d�pend de votre distribution linux)
*
* la librairie graphique utilis�e est openGL (open Graphic Library), version GLUT.
* les biblioth�ques GLUT sont les biblioth�ques standards de openGL, elles fonctionnent sous tous les syst�mes
* d'exploitation, par cons�quent, les modifications � apporter dans le code pour recompiler (quel que soit
* votre syst�me d'exploitation et quel que soit votre compilateur) sont vraiment mineures.
* (sous Unix et Linux, les fichiers 'glut32.dll' et 'glut32.lib' deviennent alors inutiles).
*
* Attention ! les donnees exactes sont stock�es dans la structure 'donnees', 
* et des donn�es arrondies sont stock�es dans la structure 'image' pour l'affichage. 
*
***************************************************/
