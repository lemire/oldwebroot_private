Pour la distribution sous ondelette.com, un certain nombre de fichiers
compris dans le paquetage de Benjamin Jacquin furent retir�s.


J'ai retir� l'image 3.bmp qui faisait 512x512 pixels.

J'ai retir� le fichier Thumbs.db.

J'ai retir� les fichiers glut.h glut32.dll glut32.lib.

J'ai retir� l'ex�cutable ondelette_image_CDF.exe.



Daniel Lemire
