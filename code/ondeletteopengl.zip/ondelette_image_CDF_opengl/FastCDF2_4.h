/**
 *  Cohen-Daubechies-Feauveau adapted to the interval with N=2 and Ntilde=4
 *   Free software - use at your risks (commercial usage allowed)
 *  
 * For support: Wavelet Forum http://www.ondelette.com/indexfr.html (French) or 
 * http://www.ondelette.com/indexen.html (English)
 *
 * Reference:
 * 
 * Gilles Deslauriers, Serge Dubuc and Daniel Lemire, Une famille
 * d'ondelettes biorthogonales sur l'intervalle obtenue par un
 * sch�ma d'interpolation it�rative, Ann. Sci. Math. Qu�bec 23 (1999), no. 1, 37-48. 
 * English title: "A family of biorthogonal wavelets on the interval derived
 * from an interpolatory subdivision scheme"
 *
 * URL (article) : 
 *  http://www.ondelette.com/lemire/abstracts/ANNQC1999.html
 *
 * This code was also used in the production of the following paper:
 * 
 * Daniel Lemire, Chantal Pharand, Jean-Claude Rajaonah, Bruno Dub�, A.-Robert LeBlanc,
 * Wavelet time entropy, T wave morphology and myocardial ischemia, IEEE Transactions in
 *  Biomedical Engineering, vol. 47, no. 7, July 2000.
 * 
 * http://www.ondelette.com/lemire/abstracts/IEEE2000.html
 *
 * C++ port from java Rybalko Oxana oribalko@hotmail.com
 *
 * @author Daniel Lemire
 */

//The structures look awkward compared to corresponding java code since in java 
//arrays with variable dimentions are permitted.

//1. scaleLeft1,scaleLeft2,scaleLeft3,scaleLeft4 are equivalent to scaleLeft in java code
//2. scaleRight1,scaleRight2,scaleRight3,scaleRight4 are equivalent to scaleRight 
//3. waveletPrimaryLeft1, waveletPrimaryLeft2 are equivalent to waveletPrimaryLeft
//4. waveletPrimaryRight1, waveletPrimaryRight2 are equivalent to waveletPrimaryRight

#include <iostream>
#include "texture.h"

using namespace std;

const int FilterType = 1;

#define SCALE_SIZE 9
static const float scale[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.17677669529663687f, 0.41984465132951254f, 0.9943689110435824f,
0.41984465132951254f, -0.17677669529663687f, -0.06629126073623882f,
0.03314563036811941f};

#define LEFT_SCALES_NUMBER 4
#define SCALE_LEFT1_SIZE 5
#define SCALE_LEFT2_SIZE 7
#define SCALE_LEFT3_SIZE 9
#define SCALE_LEFT4_SIZE 11

static const float scaleLeft1[] = {1.0275145414117017f, 0.7733980419227863f,
-0.22097086912079608f, -0.3314563036811941f, 0.16572815184059705f};
static const float scaleLeft2[] = {-0.22189158107546605f, 0.4437831621509321f,
0.902297715576584f, 0.5800485314420897f, -0.25687863535292543f,
-0.06629126073623882f, 0.03314563036811941f};
static const float scaleLeft3[] = 
{0.07549838028293866f, -0.15099676056587732f,
-0.0957540432856783f, 0.34250484713723395f, 1.0330388131397217f,
0.41984465132951254f, -0.17677669529663687f, -0.06629126073623882f,
0.03314563036811941f};
static const float scaleLeft4[] = 
{-0.013810679320049755f, 0.02762135864009951f,
0.011048543456039804f, -0.04971844555217912f, -0.18506310288866673f,
0.41984465132951254f, 0.9943689110435824f, 0.41984465132951254f,
-0.17677669529663687f, -0.06629126073623882f, 0.03314563036811941f};

#define RIGHT_SCALES_NUMBER 4
#define SCALE_RIGHT1_SIZE 11
#define SCALE_RIGHT2_SIZE 9
#define SCALE_RIGHT3_SIZE 7
#define SCALE_RIGHT4_SIZE 5
static const float scaleRight1[] = {0.03314563036811941f,
-0.06629126073623882f, -0.17677669529663687f, 0.41984465132951254f,
0.9943689110435824f, 0.41984465132951254f, -0.18506310288866673f,
-0.04971844555217912f, 0.011048543456039804f, 0.02762135864009951f,
-0.013810679320049755f};
static const float scaleRight2[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.17677669529663687f, 0.41984465132951254f, 1.0330388131397217f,
0.34250484713723395f, -0.0957540432856783f, -0.15099676056587732f,
0.07549838028293866f};
static const float scaleRight3[] = 
{0.03314563036811941f, -0.06629126073623882f,
-0.25687863535292543f, 0.5800485314420897f, 0.902297715576584f,
0.4437831621509321f, -0.22189158107546605f};
static const float scaleRight4[] = 
{0.16572815184059705f, -0.3314563036811941f,
-0.22097086912079608f, 0.7733980419227863f, 1.0275145414117017f};


#define SCALE_PRIMARY_SIZE 3
static const float scalePrimary[] = 
{0.35355339059327373f, 0.7071067811865475f, 0.35355339059327373f};

#define SCALES_PRIMARY_LEFT 1
#define SCALE_PRIMARY_LEFT_SIZE 2
static const float scalePrimaryLeft[] = {0.7071067811865475f, 0.35355339059327373f};

#define SCALES_PRIMARY_RIGHT 1
#define SCALE_PRIMARY_RIGHT_SIZE 2
static const float scalePrimaryRight[] = {0.35355339059327373f, 0.7071067811865475f};


#define WAVELET_SIZE 3
static const float wavelet[] = {-0.5f, 1.0f, -0.5f};


#define WAVELET_PRIMARY_SIZE 9
static const float waveletPrimary[] = {0.0234375f, 0.046875f, -0.125f,
-0.296875f, 0.703125f, -0.296875f, -0.125f, 0.046875f, 0.0234375f};


#define WAVELETES_PRIMARY_LEFT 2
#define WAVELET_PRIMARY_LEFT1 8
#define WAVELET_PRIMARY_LEFT2 8
static const float waveletPrimaryLeft1[] = 
{-0.546875f, 0.5696614583333334f
, -0.3138020833333333f, -0.103515625f, 0.10677083333333333f,
0.043619791666666664f, -0.01953125f, -0.009765625f};
static const float waveletPrimaryLeft2[] = 
{0.234375f, -0.087890625f, -0.41015625f, 0.673828125f,
-0.2421875f, -0.103515625f, 0.03515625f, 0.017578125f};

#define WAVELETES_PRIMARY_RIGHT 2
#define WAVELET_PRIMARY_RIGHT1 8
#define WAVELET_PRIMARY_RIGHT2 8
static const float waveletPrimaryRight1[] = 
{0.017578125f, 0.03515625f,
-0.103515625f, -0.2421875f, 0.673828125f, -0.41015625f, -0.087890625f,
0.234375f};
static const float waveletPrimaryRight2[] =
{-0.009765625f, -0.01953125f, 0.043619791666666664f,
0.10677083333333333f, -0.103515625f, -0.3138020833333333f,
0.5696614583333334f, -0.546875f};

void transform(int length, float *v, int last) 
{
 int k, l;
 int ans_len = last;
 float *ans = new float[last];
 
 // initialize!
 for(int ii = 0; ii < last; ii++) 
 ans[ii] = 0.0;
 
 int half = (last + FilterType) / 2;

 if ((2 * half - FilterType) != last) {
 	printf("Illegal subband : %d within array of length %d\n",last,length);
 }
 
 //lowpass
 for (l = 0; l < SCALE_LEFT1_SIZE; l++) {
 ans[0] += scaleLeft1[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT2_SIZE; l++) {
 ans[1] += scaleLeft2[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT3_SIZE; l++) {
 ans[2] += scaleLeft3[l] * v[l];
 }
 for (l = 0; l < SCALE_LEFT4_SIZE; l++) {
 ans[3] += scaleLeft4[l] * v[l];
 }
 
 for (k = LEFT_SCALES_NUMBER; k < half - RIGHT_SCALES_NUMBER; k++) {
 for (l = 0; l < SCALE_SIZE; l++) {
 ans[k] += scale[l] * v[2 * k + l - LEFT_SCALES_NUMBER];
 }
 }

 for (l = 0; l < SCALE_RIGHT1_SIZE; l++) {
 ans[0 + half - RIGHT_SCALES_NUMBER] += scaleRight1[l] * v[last - SCALE_RIGHT1_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT2_SIZE; l++) {
 ans[1 + half - RIGHT_SCALES_NUMBER] += scaleRight2[l] * v[last - SCALE_RIGHT2_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT3_SIZE; l++) {
 ans[2 + half - RIGHT_SCALES_NUMBER] += scaleRight3[l] * v[last - SCALE_RIGHT3_SIZE + l];
 }
 for (l = 0; l < SCALE_RIGHT4_SIZE; l++) {
 ans[3 + half - RIGHT_SCALES_NUMBER] += scaleRight4[l] * v[last - SCALE_RIGHT4_SIZE + l];
 }

 //highpass
 for ( k = 0; k < half - FilterType; k++) {
 for (l = 0; l < WAVELET_SIZE; l++) {
 ans[k + half] += wavelet[l] * v[2 * k + l];
 }
 }
 
 for( k = 0; k < ans_len; k++) {
 v[k] = ans[k];
 }

 delete[] ans;

}

void transform(int length, float *v) 
{
 for (int last = length; last >= taille; last = (last + FilterType) / 2) 
 transform(length, v, last);
}

void invTransform(int length, float *v, int last) 
{
 int k, l;
 int ans_len = 2*last - FilterType;
 float *ans = new float[ans_len];

 // initialize!
 for(int ii = 0; ii < ans_len; ii++) 
 ans[ii] = 0.0;

 //scale coefficients 
 for (l = 0; l < SCALE_PRIMARY_LEFT_SIZE; l++) {
 ans[l] += scalePrimaryLeft[l] * v[0];
 }

 
 for (k = SCALES_PRIMARY_LEFT; k < last - SCALES_PRIMARY_RIGHT; k++) {
 for (l = 0; l < SCALE_PRIMARY_SIZE; l++) {
 ans[2 * k - FilterType + l] += scalePrimary[l] * v[k];
 }
 }

 //for each of SCALES_PRIMARY_RIGHT
 int iSCALES_PRIMARY_RIGHT = SCALES_PRIMARY_RIGHT - 1;
 for (l = 0; l < SCALE_PRIMARY_RIGHT_SIZE; l++) {
 ans[l - SCALE_PRIMARY_RIGHT_SIZE + ans_len] +=
 scalePrimaryRight[l] * v[iSCALES_PRIMARY_RIGHT + last - SCALES_PRIMARY_RIGHT];
 
 }
 
 //for each of WAVELET_PRIMARY_RIGHT
 int iWAVELETES_PRIMARY_LEFT = WAVELETES_PRIMARY_LEFT - 2;
 for (l = 0; l < WAVELET_PRIMARY_LEFT1; l++) {
 ans[l] += waveletPrimaryLeft1[l] * v[iWAVELETES_PRIMARY_LEFT + last];
 }
 
 iWAVELETES_PRIMARY_LEFT += 1;
 for (l = 0; l < WAVELET_PRIMARY_LEFT2; l++) {
 ans[l] += waveletPrimaryLeft2[l] * v[iWAVELETES_PRIMARY_LEFT + last];
 }
 
 for ( k = WAVELETES_PRIMARY_LEFT; k < last - FilterType
 - WAVELETES_PRIMARY_LEFT; k++) {
 for (l = 0; l < WAVELET_PRIMARY_SIZE; l++) {
 ans[2 * (k - FilterType) - 1 + l] += waveletPrimary[l] * v[k + last];
 }
 }
 
 //for each of WAVELET_PRIMARY_RIGHT
 int iWAVELETES_PRIMARY_RIGHT = WAVELETES_PRIMARY_RIGHT - 2;
 for (l = 0; l < WAVELET_PRIMARY_RIGHT1; l++) {
 ans[l - WAVELET_PRIMARY_RIGHT1 + ans_len] +=
 waveletPrimaryRight1[l] * v[iWAVELETES_PRIMARY_RIGHT + 2 * last - FilterType -
 WAVELETES_PRIMARY_RIGHT];
 }
 
 iWAVELETES_PRIMARY_RIGHT = iWAVELETES_PRIMARY_RIGHT + 1;
 for (l = 0; l < WAVELET_PRIMARY_RIGHT2; l++) {
 ans[l - WAVELET_PRIMARY_RIGHT2 + ans_len] +=
 waveletPrimaryRight2[l] * v[iWAVELETES_PRIMARY_RIGHT + 2 * last - FilterType -
 WAVELETES_PRIMARY_RIGHT];
 }
 
 for( k = 0; k < ans_len; k++) {
 v[k] = ans[k];
 }
 
 delete[] ans;
}

void invTransform(int length, float *v) 
{
 int last;
 for (last = length; last >= taille; last = last / 2 + FilterType) {
 ;
 }
 for (; 2 * last - FilterType <= length; last = 2 * last - FilterType) {
 invTransform(length, v, last);
 }
}



