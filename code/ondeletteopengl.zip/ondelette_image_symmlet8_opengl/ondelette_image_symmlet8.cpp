
/**************************************************
* Fichiers : texture.h, ondelette_image.cpp
* Format : openGL avec C++
*
* (c) 2003-2004 Benjamin Jacquin 
* benjamin.jacquin@utt.fr
*
* Last modified on July 31th 2004
* Derni�re modification le 31 juillet 2004
*
* Free for any use, but this copyright notice must remain.
* Provide as is. Use at your risks.
*
* Gratuit pour toute utilisation, mais pr�servez cette mention.
* Sans garantie aucune, utilisez � vos risques.
*
* Programme de transformation d'une image par ondelettes Symmlet8
*
* Ce programme peut etre modifie tres simplement pour utiliser d'autres ondelettes
*
* Attention ! les donnees exactes sont stockees dans la structure 'donnees', 
* et des donnees arrondies sont stockees dans la structure 'image' pour l'affichage 
*
* la librairie graphique utilisee est openGL (open Graphic Library), 
* ce programme peut fonctionner sous Unix et Linux en installant les bibliotheques openGL.
* (les fichiers 'glut32.dll' et 'glut32.lib' deviennent alors inutiles).
*
***************************************************/

#include "Symmlet8.h"

#define NAME "Transformee par ondelettes Symmlet8"   
#define FIMAGE "3.bmp" // nom de l'image qu'on charge, image BMP 24 bpp, 512x512

/* procedure appelee a chaque fois qu'on modifie la taille de la fenetre */
void myReshape(int largeur, int hauteur)
{
    	/* taille de la vue = taille de la fenetre */
        glViewport(0, 0, largeur, hauteur);
        /* Matrice de projection */
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        /* calcul de la nouvelle projection */
        if (largeur <= hauteur)
                glOrtho (-2.25, 2.25, -2.25*hauteur/largeur, 2.25*hauteur/largeur, -10.0, 10.0);
        else
                glOrtho (-2.25*largeur/hauteur, 2.25*largeur/hauteur, -2.25, 2.25, -10.0, 10.0);
        /* on utilise maintenant la matrice des objets */
        glMatrixMode(GL_MODELVIEW);	
}

/* lorsqu'on quitte le programme, on enregistre l'image en cours */
void sauve_image(void)
{
	unsigned char imagew[512*512*3];
	int i=0;
	int j=512-1;
	for(int k=0;k<512*512*3;k++)
	{
		imagew[k]=image[i][j].r;
		k++;
		imagew[k]=image[i][j].g;
		k++;
		imagew[k]=image[i][j].b;
		i++;
		if (i==512) { i=0; j--; }
	}
	write24BitBmpFile("sauve.bmp", 512, 512, imagew);
}

void Symmlet8_ligne(void)
{
	int i,j;

	for(i=0;i<taille;i++) // pour chaque colonne
	{
		for(j=0;j<taille;j++) // pour chaque ligne rouge
			t[j]=donnees[i][j].r; 

		transform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[i][j].r=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque ligne verte
			t[j]=donnees[i][j].g;

		transform(taille,t);

		for (j=0;j<taille;j++)
			donnees[i][j].g=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque ligne bleue
			t[j]=donnees[i][j].b;

		transform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[i][j].b=t[j];
	}

	copie_image(); // pour l'affichage
}

void inv_Symmlet8_ligne(void)
{
	int i,j;

	for(i=0;i<taille;i++) // pour chaque colonne
	{
		for(j=0;j<taille;j++) // pour chaque ligne rouge
			t[j]=donnees[i][j].r; 

		invTransform(taille,t);

		for (j=0;j<taille;j++)
			donnees[i][j].r=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque ligne verte
			t[j]=donnees[i][j].g;

		invTransform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[i][j].g=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque ligne bleue
			t[j]=donnees[i][j].b;

		invTransform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[i][j].b=t[j];
	}

	copie_image(); // pour l'affichage
}

void Symmlet8_colonne(void)
{
	int i,j;

	for(i=0;i<taille;i++) // pour chaque ligne
	{
		for(j=0;j<taille;j++) // pour chaque colonne rouge
			t[j]=donnees[j][i].r; 

		transform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[j][i].r=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque colonne verte
			t[j]=donnees[j][i].g;

		transform(taille,t);

		for (j=0;j<taille;j++)
			donnees[j][i].g=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque colonne bleue
			t[j]=donnees[j][i].b;

		transform(taille,t);

		for (j=0;j<taille;j++)
			donnees[j][i].b=t[j];
	}

	copie_image(); // pour l'affichagev
}

void inv_Symmlet8_colonne(void)
{
	int i,j;

	for(i=0;i<taille;i++) // pour chaque ligne
	{
		for(j=0;j<taille;j++) // pour chaque colonne rouge
			t[j]=donnees[j][i].r; 

		invTransform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[j][i].r=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque colonne verte
			t[j]=donnees[j][i].g;

		invTransform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[j][i].g=t[j];

		///////////////////////////////
		for(j=0;j<taille;j++) // pour chaque colonne bleue
			t[j]=donnees[j][i].b;

		invTransform(taille,t);
	
		for (j=0;j<taille;j++)
			donnees[j][i].b=t[j];
	}

	copie_image(); // pour l'affichage
}

void Clavier(unsigned char key, int x, int y)
{
	char Titre[70]; 	

	switch (key)
        {
               	case 27: //touche ESCAPE -> on quitte le programme
					sauve_image();
					exit(0);
				break;
				case '+': 
					if (taille>8) // taille minimale du vecteur
					{
						if (nb_transfo>0) taille=taille/2; // la transformee est dyadique

						Symmlet8_ligne();			
						Symmlet8_colonne();			

						nb_transfo++;					
						envoit_texture(Tex[0]); // pour l'affichage
						printf("Transformation niveau %d\n",nb_transfo);
						sprintf(Titre,"Transformation niveau %d",nb_transfo);
						glutSetWindowTitle(Titre);
					}
					else
					{
						printf("Niveau maximal atteint\n");
						sprintf(Titre,"Niveau maximal atteint");
						glutSetWindowTitle(Titre);
					}
				break;
				case '-':
					if (nb_transfo>0) // si nb_transfo<0, on a un agrandissement de l'image originale
					{
						inv_Symmlet8_ligne();
						inv_Symmlet8_colonne();

						nb_transfo--;
						if (nb_transfo>0) taille=taille*2;
						envoit_texture(Tex[0]); // pour l'affichage
						printf("Transformation niveau %d\n",nb_transfo);
						sprintf(Titre,"Transformation niveau %d",nb_transfo);
						glutSetWindowTitle(Titre);
					}
					else
					{
						printf("Niveau minimal atteint\n");
						sprintf(Titre,"Niveau minimal atteint");
						glutSetWindowTitle(Titre);
					}
				break;
        }	
	glutPostRedisplay();
}

void display(void)
{
	/* on efface la fenetre */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	/* on utilise la matrice de projection */
	glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    /* mode de projection */
	glOrtho(0.0, 512.0, 0.0, 512.0, 0.0, 1.0);
	/* on utilise la matrice des objets */
    glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();
	glClearColor(0.0, 0.0, 0.0, 1.0);           // noir

	glBindTexture(GL_TEXTURE_2D, Tex[0]);       // on fait appel a la texture Tex[0]	
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2i(0,0);glVertex3i(0,0,0);        // on affiche l'image
	glTexCoord2i(1,0);glVertex3i(512,0,0);
	glTexCoord2i(1,1);glVertex3i(512,512,0);
	glTexCoord2i(0,1);glVertex3i(0,512,0);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();	

	glutSwapBuffers();
}

void init (void)
//initialisations pour creer la fenetre graphique
{	
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowPosition (250, 250);    // position de la fenetre
    glutInitWindowSize(512, 512);         // taille de la fenetre
    glutCreateWindow(NAME);
	glutReshapeFunc (myReshape);          // pour rafraichir l'ecran

	glGenTextures(1,Tex);                 // generer des textures, ici, une seule texture
	LoadBMP(FIMAGE,Tex[0]);               // on lit l'image

	int i,j;

	for(i=0;i<taille;i++)                 // on copie le contenu de "image" dans "donnees"
		for(j=0;j<taille;j++)
		{
			donnees[i][j].r=image[i][j].r;
			donnees[i][j].g=image[i][j].g;
			donnees[i][j].b=image[i][j].b;
		}

	printf("Transformee par ondelettes Symmlet8\n\n");
	printf("'+' pour 'descendre' dans les niveaux\n");
	printf("'-' pour 'remonter' dans les niveaux\n");
	printf("'ESCAPE' pour quitter le programme\n");
	printf("le resultat est enregistre sous le nom 'sauve.bmp'\n\n");
} 

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
	init();							 // initialisations
	glutDisplayFunc(display);        // affichage contenu de la fenetre
	glutKeyboardFunc(Clavier);       // gerer clavier (chiffres + lettres)
	glutMainLoop();                  // tourner en boucle
    return 0;
}
