#include "glut.h"
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define EXIT { fclose(fichier); return -1; }
#define CTOI(C) (*(int*)&C)	/* recupere en entier un nombre pointe par un char* */
 
GLubyte	Texture[16] = { 0,0,0,0, 0xFF,0xFF,0xFF,0xFF, 0xFF,0xFF,0xFF,0xFF, 0,0,0,0 };
GLuint	Tex[1];  /* identifiants de texture, ici, une seule texture */
GLenum texFormat;

typedef struct 
{
	unsigned char r;
	unsigned char g;
	unsigned char b;
} CColor ;                        // structure pour stocker une image rgb

int taille;                       // taille de l'image carree qu'on va charger
CColor image[512][512];           // pour stocker l'image qu'on affiche

typedef struct 
{
	float r;
	float g;
	float b;
} CDonnees ;                      // structure pour stocker les donnees

CDonnees donnees[512][512];       // pour stocker l'image sur laquelle on travaille
int nb_transfo=0;
float t[512];                     // vecteur pour la transformee par ondelettes

/* image BMP 24bpp, taille carree puissance de 2, ex: 256x256 */
int LoadBMP(char *File,int tex)  // tex est l'identifiant
{
	unsigned char	*Data;
	FILE			*fichier;
	unsigned char	Header[0x36];
	GLuint			DataPos,DataSize;
	GLint			Components;
	GLsizei			Width,Height;
	GLenum			Format,Type;
	unsigned char t;
	int x;
	int i,j;
	
	/* lit le fichier et son entete */
	fichier = fopen(File,"rb");if (!fichier) return -1;
	if (fread(Header,1,0x36,fichier)!=0x36) EXIT;
	if (Header[0]!='B' || Header[1]!='M')	EXIT;
	if (CTOI(Header[0x1E])!=0)				EXIT;
	if (CTOI(Header[0x1C])!=24)				EXIT;

	/* recupere les infos du fichier */
	DataPos			= CTOI(Header[0x0A]);
	DataSize		= CTOI(Header[0x22]);

	/* recupere les infos de l'image */
	Width			= CTOI(Header[0x12]);
	Height			= CTOI(Header[0x16]);	
	Type = GL_UNSIGNED_BYTE;
	Format = GL_RGB;
	Components = 3;
	
	if (DataSize==0) DataSize=Width*Height*Components;
	if (DataPos==0)  DataPos=0x36;

	taille=Width;

	/* charge l'image */
	fseek(fichier,DataPos,0);
	Data = (unsigned char *)calloc(DataSize,sizeof(unsigned char));
	if (!Data) EXIT;
	if (fread(Data,1,DataSize,fichier)!=DataSize) 
	{
		free(Data);
		fclose(fichier);
		return -1;
	}
	fclose(fichier);

	i=0;j=0;
	for (x=0;x<Width*Height;x++) 
	{
		image[i][j].b=Data[x*3];
		image[i][j].g=Data[x*3+1];
		image[i][j].r=Data[x*3+2];

		i++;
		if (i==Width) { i=0; j++; }	
	}

	/* inverse R et B */
	for (x=0;x<Width*Height;x++) 
	{
		t=Data[x*3];
		Data[x*3]=Data[x*3+2];
		Data[x*3+2]=t;
	}

	/* envoie la texture � OpenGL */
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	glBindTexture(GL_TEXTURE_2D, tex);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	
	glTexImage2D
	( 	
		GL_TEXTURE_2D, 	// target
		0,				// mipmap level
		Components,		// nb couleurs
		Width,			// largeur
		Height,			// hauteur
		0,			 	// largeur du bord
		Format,			// type des couleurs
		Type,			// codage de chaque composante
		Data			// image
	); 

	return 0;
}

void copie_image(void) /* copie les donnees dans "image" pour l'affichage et controle les valeurs */
{
	int i,j;

	for(i=0;i<taille;i++)
		for(j=0;j<taille;j++)
		{
			if (donnees[i][j].r<0) image[i][j].r=0;
			else if (donnees[i][j].r>255) image[i][j].r=255;
			else image[i][j].r=donnees[i][j].r;

			if (donnees[i][j].g<0) image[i][j].g=0;
			else if (donnees[i][j].g>255) image[i][j].g=255;
			else image[i][j].g=donnees[i][j].g;

			if (donnees[i][j].b<0) image[i][j].b=0;
			else if (donnees[i][j].b>255) image[i][j].b=255;
			else image[i][j].b=donnees[i][j].b;
		}
}

/* recupere les donnees image en memoire et les envoit en tant que texture � openGL */
/* utile pour faire apparaitre les modifications qu'on a fait subir a l'image */
int envoit_texture(int tex) 
{	
	unsigned char *Data;
	int x;
	int i,j;
	
	Data = (unsigned char *)calloc(512*512*3,sizeof(unsigned char));
	i=0;j=0;
	for (x=0;x<512*512;x++) 
	{
		Data[x*3]=image[i][j].r;
		Data[x*3+1]=image[i][j].g;
		Data[x*3+2]=image[i][j].b;
	
		i++;
		if (i==512) { i=0; j++; }	
	}

	/* envoie la texture � OpenGL */
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	glBindTexture(GL_TEXTURE_2D, tex);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	
	glTexImage2D
	( 	
		GL_TEXTURE_2D,   	// target
		0,			    	// mipmap level
		3,	            	// nb couleurs
		512,		    	// largeur
		512,		    	// hauteur
		0,			    	// largeur du bord
		GL_RGB,		    	// type des couleurs
		GL_UNSIGNED_BYTE,	// codage de chaque composante
		Data		    	// image
	); 

	free(Data);
	return 0;
}

/* 
	This function writes out a 24-bit Windows bitmap file that is readable by Microsoft Paint.  
   The image data	is a 1D array of (r, g, b) triples, where individual (r, g, b) values can 
	each take on values between 0 and 255, inclusive.
  
   The input to the function is:
	   char *filename:						A string representing the filename that will be written
		unsigned int width:					The width, in pixels, of the bitmap
		unsigned int height:					The height, in pixels, of the bitmap
		unsigned char *image:				The image data, where each pixel is 3 unsigned chars (r, g, b)

   Written by Greg Slabaugh (slabaugh@ece.gatech.edu), 10/19/00
*/
int write24BitBmpFile(char *filename, unsigned int width, unsigned int height, unsigned char *image)
{
	BITMAPINFOHEADER bmpInfoHeader;
	BITMAPFILEHEADER bmpFileHeader;
	FILE *filep;
	unsigned int row, column;
	unsigned int extrabytes, bytesize;
	unsigned char *paddedImage = NULL, *paddedImagePtr, *imagePtr;

	/* The .bmp format requires that the image data is aligned on a 4 byte boundary.  For 24 - bit bitmaps,
	   this means that the width of the bitmap  * 3 must be a multiple of 4. This code determines
	   the extra padding needed to meet this requirement. */
   extrabytes = (4 - (width * 3) % 4) % 4;

	// This is the size of the padded bitmap
	bytesize = (width * 3 + extrabytes) * height;

	// Fill the bitmap file header structure
	bmpFileHeader.bfType = 'MB';   // Bitmap header
	bmpFileHeader.bfSize = 0;      // This can be 0 for BI_RGB bitmaps
	bmpFileHeader.bfReserved1 = 0;
	bmpFileHeader.bfReserved2 = 0;
	bmpFileHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	// Fill the bitmap info structure
	bmpInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpInfoHeader.biWidth = width;
	bmpInfoHeader.biHeight = height;
	bmpInfoHeader.biPlanes = 1;
	bmpInfoHeader.biBitCount = 24;            // 8 - bit bitmap
	bmpInfoHeader.biCompression = BI_RGB;
	bmpInfoHeader.biSizeImage = bytesize;     // includes padding for 4 byte alignment
	bmpInfoHeader.biXPelsPerMeter = 2952;
	bmpInfoHeader.biYPelsPerMeter = 2952;
	bmpInfoHeader.biClrUsed = 0;
	bmpInfoHeader.biClrImportant = 0;


	// Open file
	if ((filep = fopen(filename, "wb")) == NULL) {
		printf("Error opening file %s\n", filename);
		return FALSE;
	}

	// Write bmp file header
	if (fwrite(&bmpFileHeader, 1, sizeof(BITMAPFILEHEADER), filep) < sizeof(BITMAPFILEHEADER)) {
		printf("Error writing bitmap file header\n");
		fclose(filep);
		return FALSE;
	}

	// Write bmp info header
	if (fwrite(&bmpInfoHeader, 1, sizeof(BITMAPINFOHEADER), filep) < sizeof(BITMAPINFOHEADER)) {
		printf("Error writing bitmap info header\n");
		fclose(filep);
		return FALSE;
	}

	// Allocate memory for some temporary storage
	paddedImage = (unsigned char *)calloc(sizeof(unsigned char), bytesize);
	if (paddedImage == NULL) {
		printf("Error allocating memory \n");
		fclose(filep);
		return FALSE;
	}

	/* This code does three things.  First, it flips the image data upside down, as the .bmp
	   format requires an upside down image.  Second, it pads the image data with extrabytes 
		number of bytes so that the width in bytes of the image data that is written to the
		file is a multiple of 4.  Finally, it swaps (r, g, b) for (b, g, r).  This is another
		quirk of the .bmp file format. */
	for (row = 0; row < height; row++) {
		imagePtr = image + (height - 1 - row) * width * 3;
		paddedImagePtr = paddedImage + row * (width * 3 + extrabytes);
		for (column = 0; column < width; column++) {
			*paddedImagePtr = *(imagePtr + 2);
			*(paddedImagePtr + 1) = *(imagePtr + 1);
			*(paddedImagePtr + 2) = *imagePtr;
			imagePtr += 3;
			paddedImagePtr += 3;
		}
	}

	// Write bmp data
	if (fwrite(paddedImage, 1, bytesize, filep) < bytesize) {
		printf("Error writing bitmap data\n");
		free(paddedImage);
		fclose(filep);
		return FALSE;
	}

	// Close file
	fclose(filep);
	free(paddedImage);
	return TRUE;
}

