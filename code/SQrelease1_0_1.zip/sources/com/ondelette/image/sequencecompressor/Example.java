/*
* Projet Sequence Compressor
* (c) Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
*
* version 1.0.1 (alpha)
* 3 juillet 2000
*/

package com.ondelette.image.sequencecompressor;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
//import com.sun.jimi.core.util.*;
import com.sun.jimi.core.raster.*;
import com.sun.jimi.core.*;


/*
* Petit exemple ne faisant pas partie int�grante
* de l'API. Cet exemple n'est pas support� par
* Daniel Lemire et peut ne pas fonctionner dans
* votre contexte.
*/
public class Example extends Frame {
  Image mImage;

  public Example(Image im, int w, int h) {
    mImage = im;
    this.setSize(w+40,h+50);
    this.setVisible(true);
  }




  public static void main(String[] arg) throws IOException, JimiException  {
    String outputfilename = "c:/programmation/projets/SequenceCompressor/deleteme.bin";
    // compression
    SequenceCompressorOutputStream scos = new SequenceCompressorOutputStream(new FileOutputStream(outputfilename));
    for(int k = 1; k <= 40; k++) {
      System.out.println("Writing pic"+k+".gif to "+outputfilename);
      Image im = Jimi.getImage("pic"+k+".gif");
      scos.writeImage(im);
    }
    scos.close();
    // d�compression
    SequenceCompressorInputStream scis = new SequenceCompressorInputStream (
      new FileInputStream(outputfilename)
    );
    Image im2 = null;
    for(int k = 1; k <= 40; k++) {
      System.out.println("Reading image "+k+" from "+outputfilename);
      im2 = scis.readImage();
    }
    scis.close();
    // fin
    JimiRasterImage raster = Jimi.createRasterImage(im2.getSource(),Jimi.VIRTUAL_MEMORY & Jimi.SYNCHRONOUS);
    new Example(im2,raster.getWidth(),raster.getHeight());
    System.out.println("Displaying last image");
  }

  public void paint(Graphics g) {
    g.drawImage(mImage, 20, 30,this);
  }
}