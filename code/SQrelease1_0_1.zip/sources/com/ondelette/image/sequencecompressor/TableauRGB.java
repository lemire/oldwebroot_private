
/*
* Projet Sequence Compressor
* (c) Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
*
* For English documentation, see readme.txt.
*
* version 1.0.1 (alpha)
* 3 juillet 2000
*/

package com.ondelette.image.sequencecompressor;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import com.sun.jimi.core.*;

/*
* Cette classe permet l'arithm�tique sur les images.
* Elle sert essentiellement � stocker les valeurs des
* pixels.
*/
public class TableauRGB {

  private int mHeight;
  private int mWidth;
  private int[] mPixel;

  public TableauRGB() {
  }

  public TableauRGB(Image image) throws JimiException  {
    setImage(image);
  }

  public void setImage(Image image) throws JimiException   {
    ImageReader reader = new ImageReader(image);
    mPixel = reader.getIntegerArray();
    mWidth = reader.getWidth();
    mHeight = reader.getHeight();
    reader = null;

  }

  public int getWidth() {
    return(mWidth);
  }

  public int getHeight() {
    return(mHeight);
  }

  public MemoryImageSource getMemoryImageSource(Rectangle rect) {
    int[] mTempBuffer = new int[rect.width * rect.height];
    final int bottomborder = rect.height + rect.y;
    for(int y = rect.y; y < bottomborder; y++) {
      System.arraycopy(mPixel,y*mWidth+rect.x,mTempBuffer,(y - rect.y) * rect.width, rect.width);
    }
    return(new MemoryImageSource(rect.width, rect.height, mTempBuffer, 0, rect.width));
  }

  public MemoryImageSource getMemoryImageSource() {
    return(new MemoryImageSource(mWidth, mHeight, mPixel, 0, mWidth));
  }

  /*
  * Compare les deux images et donne le "rectangle" d�finissant la
  * r�gion o� les deux images sont diff�rentes.
  * Donnera "null" si les deux images sont identiques.
  */
  public Rectangle compareWith(TableauRGB tableau) {
    if((mWidth != tableau.mWidth) || (mHeight != tableau.mHeight))
      throw new IllegalArgumentException ("Images are not the same size.");
    //    du haut
    int above = 0;
    deathfromabove:
    for(above = 0; above < mHeight ; above ++) {
      for(int x = 0; x < mWidth ; x++) {
        if(mPixel[above * mWidth + x] != tableau.mPixel[above * mWidth + x]) {
          break deathfromabove;
        }
      }
    }
    if(above == mHeight)
      return(null);// les deux images sont identiques
    //    du bas
    int below = mHeight - 1;
    deathfrombelow:
    for(below = mHeight - 1; ; below--) {
      for(int x = 0; x < mWidth ; x++) {
        if(mPixel[below * mWidth + x] != tableau.mPixel[below * mWidth + x]) {
          break deathfrombelow;
        }
      }
    }
    //    de la gauche
    int left = 0;
    deathfromleft:
    for(left = 0; ; left++) {
      for(int y = 0; y < mHeight ; y++) {
        if(mPixel[y * mWidth + left] != tableau.mPixel[y * mWidth + left]) {
          break deathfromleft;
        }
      }
    }
    // de la droite
    int right = mWidth - 1;
    deathfromrigth:
    for(right = mWidth - 1; ; right--) {
      for(int y = 0; y < mHeight ; y++) {
        if(mPixel[y * mWidth + right] != tableau.mPixel[y * mWidth + right]) {
          break deathfromrigth;
        }
      }
    }
    // fin
    return(new Rectangle( left, above , right - left + 1 , below - above + 1 ));

  }

  public void insert(TableauRGB tableau, Rectangle rect) {
    if (( tableau.mWidth > mWidth ) || ( tableau.mHeight > mHeight )) {
      throw new IllegalArgumentException("You are trying to insert a big image inside a smaller one!");
    }
    for (int row = 0; row < rect.height; row++) {
      for (int col = 0; col < rect.width; col++) {
        final int rowimage = row + rect.y;
        final int colimage = col + rect.x;
        if( row * tableau.mWidth + col >= tableau.mPixel.length ) {
            System.out.println("Exceeding new tableau boundary");
            System.out.println(row);
            System.out.println(col);
            System.out.println( row * tableau.mWidth + col);
            System.out.println(tableau.mWidth);
            System.out.println(rect.width);
            System.out.println(tableau.mHeight);
            System.out.println(rect.height);
            System.out.println(tableau.mPixel.length);
        }
      //  System.out.println("row = "+row+" col = "+col);
        //System.out.println("this.Width = "+mWidth+" tableau.Width = "+tableau.mWidth);
        mPixel[rowimage * mWidth + colimage] = tableau.mPixel[row * tableau.mWidth + col];
      }
    }

  }
}
