
/*
* Projet Sequence Compressor
* (c) Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
*
* For English documentation, see readme.txt.
*
* version 1.0.1 (alpha)
* 3 juillet 2000
*/
package com.ondelette.image.sequencecompressor;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import com.sun.jimi.core.*;
import com.sun.jimi.core.options.*;


public class SequenceCompressorOutputStream extends FilterOutputStream {

  private TableauRGB mTableau = null;
  private  PNGOptions mOptions;
  private  JimiWriter mWriter;
  private DataOutputStream mDos;

  public SequenceCompressorOutputStream(OutputStream os) {
    super(os);
    mOptions = new PNGOptions();
    try {
      mOptions.setCompressionType(PNGOptions.COMPRESSION_MAX);
    } catch(OptionException oe) {oe.printStackTrace();}
    try {
      mWriter = Jimi.createJimiWriter("image/png",super.out);
      mWriter.setOptions(mOptions);
    } catch (JimiException je) {je.printStackTrace();}
    mDos = new DataOutputStream(super.out);
  }

  public void writeImage(Image im) throws JimiException, IOException {
    if(mTableau == null) {
      mTableau = new TableauRGB(im);
      writeTableau(mTableau, new Rectangle(0,0,mTableau.getWidth(),mTableau.getHeight()));
      return;
    }
    TableauRGB NewTableau = new TableauRGB(im);
    Rectangle rect = mTableau.compareWith(NewTableau);
    writeTableau(NewTableau,rect);
    mTableau = NewTableau;
  }

  private void writeTableau(TableauRGB tableau, Rectangle rect) throws IOException, JimiException {
    if(rect == null) {
      mDos.writeInt(0);
      mDos.writeInt(0);
      mDos.writeInt(0);
      mDos.writeInt(0);
      mDos.flush();
    } else {
      mDos.writeInt(rect.x);
      mDos.writeInt(rect.y);
      mDos.writeInt(rect.width);
      mDos.writeInt(rect.height);
      mDos.flush();
      mWriter.setSource(tableau.getMemoryImageSource(rect));

      mWriter.putImage(super.out);
    }
  }
}


