
/*
* Projet Sequence Compressor
* (c) Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
*
* For English documentation, see readme.txt.
*
* version 1.0.1 (alpha)
* 3 juillet 2000
*/
package com.ondelette.image.sequencecompressor;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import com.sun.jimi.core.*;

public class SequenceCompressorInputStream extends FilterInputStream  {

  private TableauRGB mTableau = null;
  private DataInputStream mDis;
  private Toolkit mToolkit = Toolkit.getDefaultToolkit();

  public SequenceCompressorInputStream(InputStream is) {
    super(is);
    mDis = new DataInputStream (super.in);
  }

  public Image readImage() throws IOException, JimiException  {
    TableauRGB tableau = new TableauRGB();
    Rectangle rect = readTableau(tableau);
//    System.out.println(tableau.getWidth());
  //      System.out.println(tableau.getHeight());

    if(tableau == null) {
      if(mTableau == null)
        return(null);
      else
        return(mToolkit.createImage(mTableau.getMemoryImageSource()));
    }
    if(mTableau == null) {
      mTableau = tableau;
    } else {
      mTableau.insert(tableau, rect);
    }
    return(mToolkit.createImage(mTableau.getMemoryImageSource()));
  }

  private Rectangle readTableau(TableauRGB tableau) throws IOException, JimiException {
    final int x = mDis.readInt();
    final int y = mDis.readInt();
    final int width = mDis.readInt();
    final int height = mDis.readInt();
    Rectangle rect = new Rectangle(x,y,width,height);
    if((x == 0) && (y == 0) && (width == 0) && (height == 0)) {
 //   System.out.println("null image detected!");
      tableau = null;
      return(rect);
    }
    //System.out.println("reading image, size: "+width+" , "+height);
    tableau.setImage(Jimi.getImage(super.in,"image/png"));
    return(rect);
  }

}
