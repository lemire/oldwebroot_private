/*
* Projet Sequence Compressor
* (c) Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
*
* For English documentation, see readme.txt.
*
* version 1.0.1 (alpha)
* 3 juillet 2000
*/
package com.ondelette.image.sequencecompressor;

import java.awt.*;
import java.awt.image.*;
import com.sun.jimi.core.util.*;
import com.sun.jimi.core.raster.*;
import com.sun.jimi.core.*;

/*
* Permet de lire une image et d'en extraire l'information
* n�cessaire.
*/
public final class ImageReader  extends Component {
  private int width, height;
  int[] ImageArray;
  private static final boolean DEBUG = false;

  public ImageReader(Image image)  throws JimiException {
    super();
    ImageArray = readImage(image);
  }

  public int getWidth() {
    return(width);
  }

  public int getHeight() {
    return(height);
  }

  public int[] getIntegerArray() {
    return(ImageArray);
  }


  private int[] readImage(Image image) throws JimiException {
    GraphicsUtils.waitForImage(image);
    JimiRasterImage raster = Jimi.createRasterImage(image.getSource(),Jimi.VIRTUAL_MEMORY & Jimi.SYNCHRONOUS);
     height = raster.getHeight();
     width = raster.getWidth();
     int[] pixel = new int[width*height];
     int offset = 0;
     int scansize = width;
     PixelGrabber pg = new PixelGrabber(image,0,0,width,height,pixel,offset,scansize);
     try {
       pg.grabPixels();
     } catch(InterruptedException e) {
                         System.out.println(e);
     }
     return(pixel);
  }
}
