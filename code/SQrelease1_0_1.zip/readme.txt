/*
* Sequence Compressor Project 
* Daniel Lemire, Ph.D.
* Daniel.Lemire@Videotron.ca
* http://www.ondelette.com
* 
* version 1.0.1 (alpha)
* July 3rd 2000 (documentation updated on July 27th 2000)
*
* Thanks to :
*
* Marie-France Gagn� <gagne@pcigeomatics.com>
* Fred Colombero <colomber@worldnet.fr>
*/

DESCRIPTION
===========

This small API allow you to compress efficiently a sequence of images
of type "screen snapshot". All images must have the same size and 
look similar (overlapping areas).

NEEDED
======

You need the JIMI library available from Sun
Microsystems (see www.java.sun.com).

COMPATIBILITY
=============

This should be compatible JDK1.1.6.

COMPRESSSION (EXAMPLE)
======================

If you have n images named "pic1.gif", "pic2.gif", etc. Compression can be 
achieved like so:

    String outputfilename = "c:/SequenceCompressor/deleteme.bin";
    SequenceCompressorOutputStream scos = new SequenceCompressorOutputStream(new FileOutputStream(outputfilename));
    for(int k = 1; k <= 40; k++) {
      Image im = Jimi.getImage("pic"+k+".gif");
      scos.writeImage(im);      
    }
    scos.close();

The filename designated by outputfilename ("c:/SequenceCompressor/deleteme.bin") will
contain the compressed images. Please note that this file can have any name you choose.
In practice, you don't even have to use a file at all! You could send the information
through a network (for example). Obviously, one could replace FileOutputStream above
by any "stream" (see java.io).

DECOMPRESSION (EXAMPLE)
=======================

We recover images like so:

    SequenceCompressorInputStream scis = new SequenceCompressorInputStream ( new FileInputStream(outputfilename) );
    for(int k = 1; k <= 40; k++) {
      Image im = scis.readImage();
      // do something here with im
    }
    scis.close();

It is really as simple as that...

IMPORT
======

Here's some "import" you might need

import com.ondelette.image.sequencecompressor.*;
import java.awt.image.*;
import java.io.*;
import com.sun.jimi.core.*;

EXEMPLE
=======

The class com.ondelette.image.sequencecompressor.Example provide a concrete example
as to how you can use this API.

RESULTS
========

From a sequence of compressed images adding up to 507 KBytes provided by Fred Colombero,
a file taking up 91 KBytes was produced with the same information content.

FAQ
===

1) Where should I put the GIF files? 

Anywhere. Let's take the following example where your files are "c:\images\tata.gif" et
"c:\images\toto.gif", vous pourrez alors remplacer l'exemple plus haut par

    String outputfilename = "c:/SequenceCompressor/deleteme.bin";
    SequenceCompressorOutputStream scos = new SequenceCompressorOutputStream(new FileOutputStream(outputfilename));
    Image im = Jimi.getImage("c:\images\tata.gif");
    scos.writeImage(im);      
    im = Jimi.getImage("c:\images\toto.gif");
    scos.close();

Note that you don't have to use GIF files, many formats are supported (including PNG)!

2) I don't understand the deleteme.bin file in your example. Does it contain the compressed
images or the images to be compressed?

It will contain, in a coded format, the compressed images all linked together using a
special encoding. To read the file, you must use this library (see the uncompress
example above).

Notice that it isn't necessary to create a file at all. You could send everything
through a network like so

    Socket socket = new Socket("123.321.312.121", 1000);
    SequenceCompressorOutputStream scos = new SequenceCompressorOutputStream(socket.getOutputStream());
    for(int k = 1; k <= 40; k++) {
      Image im = Jimi.getImage("pic"+k+".gif");
      scos.writeImage(im);      
    }
    scos.close();
