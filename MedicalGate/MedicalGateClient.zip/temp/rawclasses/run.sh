#socksify /usr/java/jdk1.3.0_02/bin/java -cp MedicalGate.jar com.emedicalgate.client.BasicApplet
socksify java -cp MedicalGate.jar com.emedicalgate.client.BasicApplet
