package com.ondelette.installer;

import java.util.*;
import java.util.jar.*;
import java.io.*;
import java.text.*;

public class ExtensionRequirement {
  private String mJarName;
  private String mRequiredImplementationVersion;

  public ExtensionRequirement(String jarname, String RequiredImplementationVersion) {
    mJarName = jarname;
    mRequiredImplementationVersion = RequiredImplementationVersion;
  }

  public String getJarName() {
    return(mJarName);
  }

  public String toString() {
    if(mRequiredImplementationVersion != null)
      return (mJarName + "(" + mRequiredImplementationVersion + ")");
    return (mJarName);
  }

  public String getRequiredImplementationVersion() {
    if (mRequiredImplementationVersion == null)
      return("");
    return mRequiredImplementationVersion;
  }

  public boolean checkVersion(File jarfile) {
    if(!jarfile.canRead())
      return(false);
    if(mRequiredImplementationVersion == null)
      return(true);
    String implementationversion = null;
    try {
      JarFile jar = new JarFile(jarfile);
      try {
        implementationversion = jar.getManifest().getMainAttributes().getValue(Attributes.Name.IMPLEMENTATION_VERSION );
      } finally {
        jar.close();
      }
    } catch (Exception ioe) {
      ioe.printStackTrace();
      return(false);
    }
    if(implementationversion == null)
      return false;
    double currentversion = Double.parseDouble(implementationversion.substring(0,3));//
    double wantedversion = Double.parseDouble(mRequiredImplementationVersion.substring(0,3));//
    return(currentversion >= wantedversion);

  }
}