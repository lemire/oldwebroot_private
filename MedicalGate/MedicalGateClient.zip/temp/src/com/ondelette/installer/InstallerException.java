package com.ondelette.installer;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

public class InstallerException extends Exception {

  public InstallerException() {
  }
  public InstallerException(String s) {
    super(s);
  }
}