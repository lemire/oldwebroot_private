package com.ondelette.installer;

import java.io.*;
import java.awt.*;
import java.util.*;
import java.net.*;
import javax.swing.*;

public class Installer {

  static String mName = "Installation des librairies";




  private Installer() {
  }

  private static File[] getDirs(String dirs) {
    Vector v = new Vector();
    int pos = 0;
    while (pos < dirs.length()) {
      StringBuffer b = new StringBuffer();
      char c;
      while((c = dirs.charAt(pos))!=File.pathSeparatorChar) {
        b.append(c);
        pos++;
        if(pos == dirs.length())
          break;
      }
      v.add(new File(b.toString()));
    }
    File[] sarray = new File[v.size()];
    v.toArray(sarray);
    return(sarray);

  }

  public static boolean check(ExtensionRequirement er) {
    System.out.println("Checking "+er.getJarName());
    File[] dirs = getDirs( System.getProperty("java.ext.dirs"));
    for(int k = 0; k < dirs.length; ++k) {
      if(check(er,dirs[k]))
        return(true);
    }
    return(false);
  }

  private static boolean check(ExtensionRequirement er, File dir) {
    System.out.println("Checking "+er.getJarName()+" dans "+dir.getAbsolutePath());
    return(er.checkVersion(new File(dir,er.getJarName())));
  }

  public static void warn (Exception e) {
    warn(e,"Une erreur inattendue est survenue avec l'installation.");
  }

  public static void warn (Exception e, String s) {
    StringWriter sos = new StringWriter();
    PrintWriter pw = new PrintWriter(sos);
    e.printStackTrace(pw);
    BufferedReader br = new BufferedReader(new StringReader(sos.toString()));
    StringBuffer sb = new StringBuffer();
    sb.append("<html><b>");
    sb.append(s);
    sb.append("</b>");
    String line = null;
    try {
      while ( ( line = br.readLine() ) != null) {
        sb.append("<br>");
        sb.append(line.trim());

      }
    } catch (IOException ioe) {}
    sb.append("</html>");
    JEditorPane pane = new JEditorPane();
    pane.setContentType("text/html");
    pane.setEditable(false);
    pane.setText(sb.toString());
    JScrollPane scrollpane = new JScrollPane(pane);
    scrollpane.setMinimumSize(new Dimension(384,200));
    scrollpane.setPreferredSize(scrollpane.getMinimumSize());
    JOptionPane.showMessageDialog(null,scrollpane ,mName,JOptionPane.ERROR_MESSAGE);

  }

  public static boolean install(ExtensionRequirement er, URL baseurl, File targetdir) {
    targetdir.mkdirs();
    File jarfile = new File(targetdir,er.getJarName());

    try {
      jarfile.createNewFile();
    } catch (IOException ioe) {
      warn(ioe,"Impossible de cr�er le fichier "+jarfile.getAbsolutePath()+".");
      ioe.printStackTrace();
      return(false);
    }
    if(!jarfile.canWrite()) {
      JOptionPane.showMessageDialog(null,"Impossible d'�crire dans "+jarfile.getAbsolutePath()+".\nCommuniquez avec le support technique." ,"Erreur lors de l'installation",JOptionPane.ERROR_MESSAGE);
      return(false);
    }
    System.out.println("�criture dans "+jarfile.getAbsolutePath());
    URL fileurl = null;
    try {
      fileurl = new URL(baseurl,er.getJarName());
    } catch (MalformedURLException mue) {
      warn(mue,baseurl.toString()+" / "+er.getJarName());
      System.out.println(baseurl.toString()+" / "+er.getJarName());
      mue.printStackTrace();

      return(false);
    }
    try {
      InputStream bis = fileurl.openStream();
      ProgressMonitor pm = new ProgressMonitor(null,fileurl.toString()+"->"+jarfile.getAbsolutePath(),er.getJarName()+" ("+er.getRequiredImplementationVersion()+")",0,bis.available()/1024);
      int pos = 0;
      pm.setProgress(pos);
      pm.setMillisToDecideToPopup(1000);
      try {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(jarfile));
        int r = 0;
        try {
          while( (r = bis.read()) != -1) {
            bos.write(r);
            if(pos % 1024 == 0)
              pm.setProgress(++pos);
          }
        } finally {
          bos.close();
        }
      } finally {
        pm.close();
        bis.close();
      }

    } catch (IOException ioe) {
      warn(ioe);
      ioe.printStackTrace();
      return (false);
    }

    return(true);

  }

  public static boolean install(ExtensionRequirement er, URL baseurl) {
    if(er.getJarName() == null)
      System.out.println("missing jar name");
    if (baseurl == null)
      System.out.println("no url!");
    System.out.println("Installing "+er.getJarName()+" from "+baseurl.toExternalForm());
    File[] dirs = getDirs( System.getProperty("java.ext.dirs"));
    return(install(er,baseurl,dirs[0]));
  }


  public static boolean checkInstall(final URL downloadurl) {
    System.out.println("Installation...");
    if(downloadurl == null)
      System.out.println("CRITICAL ERROR: missing URL!");
    String dirs = System.getProperty("java.ext.dirs");
    if(dirs == null) {
        JOptionPane.showMessageDialog(null,"Erreur critique: Property java.ext.dirs not supported!" ,mName,JOptionPane.ERROR_MESSAGE);
        return false;
    }
    final Vector resulttable = new Vector();
    Runnable activationrunnable = new Runnable() {
      public void run() {
        System.out.println("Activation requirement...");
        ExtensionRequirement activationrequirement = new ExtensionRequirement("activation.jar",null);
        resulttable.add(activationrequirement);

        System.out.println("Activation requirement...ok");
        if(Installer.check(activationrequirement )) {
          System.out.println("Activation ok!");
          resulttable.remove(activationrequirement);
        } else {
          System.out.println("Activation not ok!");
          if( Installer.install(activationrequirement ,downloadurl) ) {
            System.out.println("activation.jar installed!");
            resulttable.remove(activationrequirement);
          } else {
            System.out.println("activation.jar not installed!");

            //return(false);
          }
        }
      }
    };
    Runnable mailrunnable = new Runnable() {
      public void run() {
        ExtensionRequirement mailrequirement = new ExtensionRequirement("mail.jar","1.2");
        resulttable.add(mailrequirement);
        if(Installer.check(mailrequirement)) {
          System.out.println("mail.jar 1.2 ok!");
          resulttable.remove(mailrequirement);
        } else {
          System.out.println("mail.jar 1.2 not ok!");
          if( Installer.install(mailrequirement,downloadurl) ) {
            System.out.println("mail.jar installed!");
            resulttable.remove(mailrequirement);
          } else {
            System.out.println("mail.jar not installed!");

          }
        }
      }
    };
    Runnable jaxprunnable = new Runnable() {
      public void run() {
        ExtensionRequirement jaxprequirement = new ExtensionRequirement("jaxp.jar",null);
        resulttable.add(jaxprequirement);
        if(Installer.check(jaxprequirement)) {
          System.out.println("jaxp.jar 1.2 ok!");
          resulttable.remove(jaxprequirement);
        } else {
          System.out.println("jaxp.jar 1.2 not ok!");
          if( Installer.install(jaxprequirement,downloadurl) ) {
            System.out.println("jaxp.jar installed!");
            resulttable.remove(jaxprequirement);
          } else {
            System.out.println("jaxp.jar not installed!");

          }
        }
      }
    };
    Runnable crimsonrunnable = new Runnable() {
      public void run() {
        ExtensionRequirement crimsonrequirement = new ExtensionRequirement("crimson.jar",null);
        resulttable.add(crimsonrequirement);
        if(Installer.check(crimsonrequirement)) {
          System.out.println("crimson.jar 1.2 ok!");
          resulttable.remove(crimsonrequirement);
        } else {
          System.out.println("crimson.jar 1.2 not ok!");
          if( Installer.install(crimsonrequirement,downloadurl) ) {
            System.out.println("crimson.jar installed!");
            resulttable.remove(crimsonrequirement);
          } else {

          }
        }
      }
    };
    Runnable xalanrunnable = new Runnable() {
      public void run() {
        ExtensionRequirement xalanrequirement = new ExtensionRequirement("xalan.jar",null);
        resulttable.add(xalanrequirement);
        if(Installer.check(xalanrequirement)) {
          System.out.println("xalan.jar ok!");
          resulttable.remove(xalanrequirement);
        } else {
          System.out.println("xalan.jar not ok!");
          if( Installer.install(xalanrequirement,downloadurl) ) {
            System.out.println("xalan.jar installed!");
            resulttable.remove(xalanrequirement);
          } else {
            System.out.println("xalan.jar not installed!");

          }
        }
      }
    };
    Runnable hsqlrunnable = new Runnable() {
      public void run() {
        ExtensionRequirement hsqlrequirement = new ExtensionRequirement("hsql.jar",null);
        resulttable.add(hsqlrequirement);
        if(Installer.check(hsqlrequirement)) {
          System.out.println("hsql.jar ok!");
          resulttable.remove(hsqlrequirement);
        } else {
          System.out.println("hsql.jar not ok!");
          if( Installer.install(hsqlrequirement,downloadurl) ) {
            System.out.println("hsql.jar installed!");
            resulttable.remove(hsqlrequirement);
          } else {
            System.out.println("hsql.jar not installed!");

          }
        }
      }
    };
    Runnable skinlfrunnable = new Runnable() {
      public void run() {
        ExtensionRequirement skinlfrequirement = new ExtensionRequirement("skinlf.jar",null);
        resulttable.add(skinlfrequirement);
        if(Installer.check(skinlfrequirement)) {
          System.out.println("skinlf.jar ok!");
          resulttable.remove(skinlfrequirement);
        } else {
          System.out.println("skinlf.jar not ok!");
          if( Installer.install(skinlfrequirement,downloadurl) ) {
            System.out.println("skinlf.jar installed!");
            resulttable.remove(skinlfrequirement);
          } else {
            System.out.println("skinlf.jar not installed!");
          }
        }
      }
    };
    Runnable aquarunnable = new Runnable() {
      public void run() {
        ExtensionRequirement aquarequirement = new ExtensionRequirement("aquathemepack.zip",null);
        resulttable.add(aquarequirement);
        if(Installer.check(aquarequirement)) {
          System.out.println("aquathemepack.zip ok!");
          resulttable.remove(aquarequirement);
        } else {
          System.out.println("aquathemepack.zip not ok!");
          if( Installer.install(aquarequirement,downloadurl) ) {
            System.out.println("aquathemepack.zip installed!");
            resulttable.remove(aquarequirement);
          } else {
            System.out.println("aquathemepack.zip not installed!");
          }
        }
      }
    };

    //
    Thread activationthread = new Thread(activationrunnable);
    activationthread.setPriority(Thread.MIN_PRIORITY);
    activationthread.start();
    //
    Thread mailthread = new Thread(mailrunnable);
    mailthread.setPriority(Thread.MIN_PRIORITY);
    mailthread.start();
    //
    Thread jaxpthread = new Thread(jaxprunnable);
    jaxpthread.setPriority(Thread.MIN_PRIORITY);
    jaxpthread.start();
    //
    Thread crimsonthread = new Thread(crimsonrunnable);
    crimsonthread.setPriority(Thread.MIN_PRIORITY);
    crimsonthread.start();
    //
    Thread xalanthread = new Thread(xalanrunnable);
    xalanthread.setPriority(Thread.MIN_PRIORITY);
    xalanthread.start();
    //
    Thread hsqlthread = new Thread(hsqlrunnable);
    hsqlthread.setPriority(Thread.MIN_PRIORITY);
    hsqlthread.start();
    //
    Thread skinlfthread = new Thread(skinlfrunnable);
    skinlfthread.setPriority(Thread.MIN_PRIORITY);
    skinlfthread.start();
    //
    Thread aquathread = new Thread(aquarunnable);
    aquathread.setPriority(Thread.MIN_PRIORITY);
    aquathread.start();
    try {
      activationthread.join();
    } catch (InterruptedException ie) {}
    try {
      mailthread.join();
    } catch (InterruptedException ie) {}
    try {
      jaxpthread.join();
    } catch (InterruptedException ie) {}
    try {
      crimsonthread.join();
    } catch (InterruptedException ie) {}
    try {
      xalanthread.join();
    } catch (InterruptedException ie) {}
    try {
      hsqlthread.join();
    } catch (InterruptedException ie) {}
    try {
      skinlfthread.join();
    } catch (InterruptedException ie) {}
    try {
      aquathread.join();
    } catch (InterruptedException ie) {}

    //
    if(resulttable.size() != 0) {
      StringBuffer sb = new StringBuffer("<html><p>Toutes les librairies n'ont pu �tre install�es!</p>");
      Enumeration enum = resulttable.elements();
      sb.append("<ul>");
      while (enum.hasMoreElements()) {
        sb.append("<li>");
        sb.append(enum.nextElement().toString());
        sb.append("</li>");
      }
      sb.append("</ul>");
      sb.append("</html>");
      JEditorPane pane = new JEditorPane();
      pane.setContentType("text/html");
      pane.setEditable(false);
      pane.setText(sb.toString());
      JScrollPane scrollpane = new JScrollPane(pane);
      scrollpane.setMinimumSize(new Dimension(384,200));
      scrollpane.setPreferredSize(scrollpane.getMinimumSize());
      JOptionPane.showMessageDialog(null,scrollpane ,mName,JOptionPane.ERROR_MESSAGE);
      return false;
    }
    //
    System.out.println("Installation...ok");
    return true;
  }

}