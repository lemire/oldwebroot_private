package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import com.emedicalgate.mmf.*;
import javax.mail.*;

public class HPRIMFile {

    private byte[] mContent, mEntete;
    private String mNomMedEmet, mNomCabDest, mNomMedDest;
    private int mVersion = -1;
    public static final String mEncoding = "ISO-8859-1";//"Cp1252";//
    private transient HPRIMPasswordManager mHPRIMPasswordManager = HPRIMPasswordManager.getInstance();
    private HPRIMPasswordProvider mHPRIMPasswordProvider;
    private Vector mDossiers;
    private java.util.Date mDate;
    private int mSize = -1;
    private Vector mMMFDescriptors = null;

    public HPRIMFile(HPRIMPasswordProvider PasswordProvider) {
      if(PasswordProvider == null)
        throw new NullPointerException("Vous essayez de passer un PasswordProvider null!");
      mHPRIMPasswordProvider = PasswordProvider;
    }

    public void read(InputStream is) throws IOException {
      System.out.println("Reading a HPRIM...");
      mSize = is.available();
      readHeader(is);
      readContent(is);
      if (mHPRIMPasswordManager.getPassword() == null)
        mHPRIMPasswordManager.setPassword(mHPRIMPasswordProvider.askHPRIMPassword());
      try {
          System.out.println("First parse des dossiers...");
          parseDossiers();
          System.out.println("First parse des dossiers...ok");
      } catch (Exception e) {
        e.printStackTrace();
        while (mHPRIMPasswordProvider.wantToReenterHPRIMPassword(this)) {
          mHPRIMPasswordManager.setPassword(mHPRIMPasswordProvider.askHPRIMPassword());
          try {
            System.out.println("Second parse des dossiers...");
            parseDossiers();
            System.out.println("Second parse des dossiers...ok");
            break;
          } catch (Exception e2) {e2.printStackTrace(); }
        }
      }
      System.out.println("Reading a HPRIM...ok");
    }

    public String getNomMedEmet() {
      return mNomMedEmet;
    }

    public String getNomCabDest() {
      return mNomCabDest;
    }

    public String getNomMedDest() {
      return mNomMedDest;
    }

    public Vector getDossiers() {
      return mDossiers;
    }

    public int getVersion() {
      return mVersion;
    }

    private void readHeader(InputStream is) throws IOException {
      mEntete = new byte[256];
      is.read(mEntete);
      int position = 0;
      final int HeaderFieldLength = 40;
      mNomMedEmet = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      mNomCabDest = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      mNomMedDest = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      String ascii = new String(mEntete ,position, 2,mEncoding);
      position += 2;
      System.out.println(ascii + " "+ascii.length());
      byte [] b = new byte[2];
      String version = new String (mEntete, position,2,mEncoding);
      position += 2;
      System.out.println("'"+version+"'"+version.length());
      mVersion = Integer.parseInt(version);
      System.out.println(mVersion);
    }

    private void readContent(InputStream is) throws IOException {
      System.out.println("MMFHPRIMTextViewer->readContent");
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      byte data[] = new byte[1024];
      int bytes_read = 0;
      while((bytes_read = is.read(data)) > 0)
	baos.write(data, 0, bytes_read);
      mContent = unlock(baos.toByteArray());
    }

    public String getHMTLHeader() {
      StringBuffer hd = new StringBuffer();
      hd.append("<b>M�decin �metteur:</b> ");
      hd.append(mNomMedEmet.trim());
      hd.append("<br><b>Cabinet destinataire:</b> ");
      hd.append(mNomCabDest.trim());
      hd.append("<br><b>M�decin destinataire:</b> ");
      hd.append(mNomMedDest.trim());
      hd.append("<br><small><em>HPRIM version");
      hd.append(mVersion);
      hd.append("</em></small>");
      return hd.toString();
    }
    public String getTextHeader() {
      StringBuffer hd = new StringBuffer();
      hd.append("M�decin �metteur: ");
      hd.append(mNomMedEmet.trim());
      hd.append("\n");
      hd.append("Cabinet destinataire: ");
      hd.append(mNomCabDest.trim());
      hd.append("\n");
      hd.append("M�decin destinataire: ");
      hd.append(mNomMedDest.trim());
      hd.append("\n");
      hd.append("HPRIM version");
      hd.append(mVersion);
      hd.append("\n");
      return hd.toString();
    }

    private void parseDossiers() throws Exception {
        BufferedReader br = null;
        try {
          br = new BufferedReader(new StringReader(HPRIMTextUtil.removeUnknownISO(new String(mContent,mEncoding))));
        } catch (UnsupportedEncodingException uee) {
          uee.printStackTrace();
          br = new BufferedReader(new StringReader(HPRIMTextUtil.removeUnknownISO(new String(mContent))));
        }
        mDossiers = new Vector();
        try {
          while(true) {
            System.out.println("reading a dossier...");
            mDossiers.add(new DossierHPRIM(br));
            System.out.println("reading a dossier...ok");
          }
        } catch (Exception e) {
          e.printStackTrace();
          if(mDossiers.size() == 0) {
            System.out.println("On n'a m�me pas pu trouver un seul dossier! Throwing an exception!");
            throw e;
          }
          System.out.println("Il y a eu un probl�me, mais comme on a pu trouver un dossier, on suppose que c'est bon.");
        }
    }

    private byte[] unlock(byte[] data) {
      System.out.println("d�cryptage");
      if (mHPRIMPasswordManager.getPassword() == null)
          mHPRIMPasswordManager.setPassword(mHPRIMPasswordProvider.askHPRIMPassword());

       byte[] password = mHPRIMPasswordManager.getPassword();
       if(password == null)
        return data;
       if(password.length == 0)
        return data;
       for(int counter = 0; counter < data.length; ++counter) {
          data[counter] ^= password[ counter % password.length];
        }
        System.out.println("d�compression");
        //On d�compresse maintenant sachant que le code ascii $02 indique une repetition,le caractere suivant
        // un $02 repr�sente le caract�re repet� et le 3eme caract�re represente le nombre d'occurence du caract�re.
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        for (int i = 0 ; i < data.length; ++i) {
          switch(data[i]) {
		case 0x0d://\r
                  baos.write(data[i]);
                  baos.write(0x0A);//\n
                  break;
                case 0x02:
                  if(i+2 < data.length) {
                    for (int k = 0; k < data[ i + 2]; k++ ) {
                      baos.write(data[i+1]);
	            }
                    i += 2;
                  } else {
                    System.err.println("Le flot est corrompu?");
                  }
                  break;
                default:
                  baos.write(data[i]);
                  break;
          }
        }
        return baos.toByteArray();
    }


  public String getDoctor() throws MessagingException {
    return mNomMedEmet.trim();
  }

  public String getSpeciality() throws MessagingException {
    return "biologie";
  }

  public String getPatientFirstName(final int k)  throws MessagingException {
    if(mDossiers.size() <= k)
      throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
    DossierHPRIM dh = (DossierHPRIM) mDossiers.get(k);
    return dh.getZoneDIndentificationDuPatient().getPatientFirstName().trim();

  }

  public String getPatientLastName(final int k)  throws MessagingException {
    if(mDossiers.size() <= k)
      throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
    DossierHPRIM dh = (DossierHPRIM) mDossiers.get(k);
    return dh.getZoneDIndentificationDuPatient().getPatientLastName().trim();
  }

  public java.util.Date getPatientBirthDate(final int k)  throws MessagingException {
    if(mDossiers.size() <= k)
      throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
    DossierHPRIM dh = (DossierHPRIM) mDossiers.get(k);
    Date birthdate = dh.getZoneDIndentificationDuPatient().getPatientBirthDate();
    if(birthdate == null)
      throw new NullPointerException("La date de naissance ne devrait pas �tre nulle!");
    return birthdate;
  }
  public String getSubject(final int k) throws MessagingException {
    if(mDossiers.size() <= k)
      throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
    DossierHPRIM dh = (DossierHPRIM) mDossiers.get(k);
    if(dh.getResultatCodifie() != null)
      return dh.getResultatCodifie().getSubject().trim();
    else
      return "biologie";
  }
 // public String getSentDateString() throws MessagingException;
  public java.util.Date getSentDate(final int k) throws MessagingException {
    if(mDossiers.size() <= k)
      throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
    DossierHPRIM dh = (DossierHPRIM) mDossiers.get(k);
    Date sentdate = dh.getZoneDIndentificationDuPatient().getDate();
    if(sentdate == null)
      throw new NullPointerException("La date d'exp�dition ne devrait pas �tre nulle!");
    return sentdate;
  }

  public int getSize() throws MessagingException {
    return mSize;
  }

  class HPRIMMMFDescriptor implements MMF {
    private final int mIndice;

    public HPRIMMMFDescriptor(final int Indice) {
      mIndice = Indice;
    }

    public String getDoctor() throws MessagingException {
      return HPRIMFile.this.getDoctor();
    }

    public String getSpeciality() throws MessagingException {
      return HPRIMFile.this.getSpeciality();
    }

    public String getPatientFirstName()  throws MessagingException {
      return HPRIMFile.this.getPatientFirstName(mIndice);
    }

    public String getPatientLastName()  throws MessagingException {
      return HPRIMFile.this.getPatientLastName(mIndice);
    }

    public java.util.Date getPatientBirthDate()  throws MessagingException {
      return HPRIMFile.this.getPatientBirthDate(mIndice);
    }

    public String getSubject() throws MessagingException {
      return HPRIMFile.this.getSubject(mIndice);
    }
 // public String getSentDateString() throws MessagingException;
    public java.util.Date getSentDate() throws MessagingException {
      return HPRIMFile.this.getSentDate(mIndice);
    }

    public int getSize() throws MessagingException {
      return HPRIMFile.this.getSize();
    }

  }

  public List getMMFDescriptors() {
    if(mMMFDescriptors != null)
      return mMMFDescriptors;
    mMMFDescriptors = new Vector();
    final int N = mDossiers.size();
    for(int k = 0; k < N; ++k) {
      mMMFDescriptors.add(new HPRIMMMFDescriptor(k));
    }
    return mMMFDescriptors;
  }
}