package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import java.util.*;
import java.io.*;

public class ResultatsCodifies  {
  final static int RESSeparator = 252;
  protected Vector mChamps = new Vector();
//  String[] mChamps = decoupeRES(s);


  public ResultatsCodifies(BufferedReader r) throws IOException{
    String s = null;

    while ((s = r.readLine()) != null) {
      if (s.startsWith("****LAB****") || s.startsWith("****FIN****") || s.startsWith("*****FIN*****") || s.startsWith ("****FINFICHIER****") || s.startsWith ("*****FINFICHIER*****")) {
        break;
      }
      if (s.startsWith("TEX")) {
        if(s.length() > 4) {
          mChamps.add( s.substring(4,s.length()) );
//          sb.append();
        }
        //sb.append("<br>");
      } else if (s.startsWith("RES")) {
        mChamps.add( decoupeRES(s) );
        //sb.append(transformRES(s));
      }
    }
    //sb.append("</html>");
//    this.setContentType("text/html");
  //  setText(sb.toString());
    //setEditable(false);

  }

  public String getSubject() {
    Enumeration enum = mChamps.elements();
    while (enum.hasMoreElements()) {
      Object current = enum.nextElement();
      if(current instanceof String[]) {
        String subject = ((String[])current)[0];
        if( HPRIMTextUtil.isDisplayable(subject) ) {
          return subject.trim();
        }
      }
    }
    return "Analyse";
  }

  public String getHTML() {
    StringBuffer sb = new StringBuffer();

    Enumeration enum = mChamps.elements();
    while (enum.hasMoreElements()) {
      Object o = enum.nextElement();
      if(o instanceof String) {
        sb.append((String) o);
        sb.append("<br>");
      } else if (o instanceof String[]) {
        sb.append(getHTML((String[])o));
      }
    }

    return sb.toString();
  }

  public String getText() {
    StringBuffer sb = new StringBuffer();
    Enumeration enum = mChamps.elements();
    while (enum.hasMoreElements()) {
      Object o = enum.nextElement();
      if(o instanceof String) {
        sb.append((String) o);
        sb.append("\n");
      } else if (o instanceof String[]) {
        sb.append(getText((String[])o));
      }
    }

    return sb.toString();
  }

  private static String getHTML(String[] champs) {
    StringBuffer sb = new StringBuffer("");
    if( HPRIMTextUtil.isDisplayable(champs[0])) {
      sb.append("<b>Libell� de l'analyse:</b> ");
      sb.append(champs[0].trim());
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[1])) {
      sb.append("<b>Code de l'analyse:</b> ");
      sb.append(champs[1].trim());
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[2])) {
      sb.append("<b>Type de r�sultat:</b> ");
      if(champs[2].equalsIgnoreCase("A"))
        sb.append("analogique");
      else if (champs[2].equalsIgnoreCase("N"))
        sb.append("num�rique");
      else if (champs[2].equalsIgnoreCase("C"))
        sb.append("code");
      else
        sb.append("inconnu");
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[3])) {
      sb.append("<b>R�sultat:</b> ");
      sb.append(champs[3].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[5])) {
      sb.append("<b>Valeur normale inf�rieure:</b> ");
      sb.append(champs[5].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[6])) {
      sb.append("<b>Valeur normale sup�rieure:</b> ");
      sb.append(champs[6].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[7])) {
      sb.append("<b>Indicateur d'anormalit�:</b> ");
      if(champs[7].equalsIgnoreCase("L"))
        sb.append("inf�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("H"))
        sb.append("sup�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("LL"))
        sb.append("inf�rieur � la valeur panique basse");
      else if (champs[7].equalsIgnoreCase("HH"))
        sb.append("inf�rieur � la valeur panique haute");
      else if (champs[7].equalsIgnoreCase("N"))
        sb.append("normal");
      else
        sb.append("indicateur d'anormalit� inconnu");
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[8])) {
      sb.append("<b>Statut du r�sultat:</b> ");
      if (champs[8].equalsIgnoreCase("F"))
        sb.append("valide");
      else if (champs[8].equalsIgnoreCase("R"))
        sb.append("non valid�");
      else if (champs[8].equalsIgnoreCase("C"))
        sb.append("modifi�, corrig�");
      else
        sb.append("inconnu");
      sb.append("<br>");
    }

    if( HPRIMTextUtil.isDisplayable(champs[9])) {
      sb.append("<b>R�sultat (deuxi�me unit�):</b> ");
      sb.append(champs[9].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[11])) {
      sb.append("<b>Valeur normale inf�rieure (deuxi�me unit�):</b> ");
      sb.append(champs[11].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    if( HPRIMTextUtil.isDisplayable(champs[12])) {
      sb.append("<b>Valeur normale sup�rieure (deuxi�me unit�):</b> ");
      sb.append(champs[12].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    return(sb.toString());
  }

  private static String getText(String[] champs) {
    StringBuffer sb = new StringBuffer("");
    if( HPRIMTextUtil.isDisplayable(champs[0])) {
      sb.append("Libell� de l'analyse: ");
      sb.append(champs[0].trim());
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[1])) {
      sb.append("Code de l'analyse: ");
      sb.append(champs[1].trim());
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[2])) {
      sb.append("Type de r�sultat: ");
      if(champs[2].equalsIgnoreCase("A"))
        sb.append("analogique");
      else if (champs[2].equalsIgnoreCase("N"))
        sb.append("num�rique");
      else if (champs[2].equalsIgnoreCase("C"))
        sb.append("code");
      else
        sb.append("inconnu");
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[3])) {
      sb.append("R�sultat: ");
      sb.append(champs[3].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[5])) {
      sb.append("Valeur normale inf�rieure: ");
      sb.append(champs[5].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[6])) {
      sb.append("Valeur normale sup�rieure: ");
      sb.append(champs[6].trim());
      if( HPRIMTextUtil.isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[7])) {
      sb.append("Indicateur d'anormalit�: ");
      if(champs[7].equalsIgnoreCase("L"))
        sb.append("inf�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("H"))
        sb.append("sup�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("LL"))
        sb.append("inf�rieur � la valeur panique basse");
      else if (champs[7].equalsIgnoreCase("HH"))
        sb.append("inf�rieur � la valeur panique haute");
      else if (champs[7].equalsIgnoreCase("N"))
        sb.append("normal");
      else
        sb.append("indicateur d'anormalit� inconnu");
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[8])) {
      sb.append("Statut du r�sultat: ");
      if (champs[8].equalsIgnoreCase("F"))
        sb.append("valide");
      else if (champs[8].equalsIgnoreCase("R"))
        sb.append("non valid�");
      else if (champs[8].equalsIgnoreCase("C"))
        sb.append("modifi�, corrig�");
      else
        sb.append("inconnu");
      sb.append("\n");
    }

    if( HPRIMTextUtil.isDisplayable(champs[9])) {
      sb.append("R�sultat (deuxi�me unit�): ");
      sb.append(champs[9].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[11])) {
      sb.append("Valeur normale inf�rieure (deuxi�me unit�): ");
      sb.append(champs[11].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("\n");
    }
    if( HPRIMTextUtil.isDisplayable(champs[12])) {
      sb.append("Valeur normale sup�rieure (deuxi�me unit�): ");
      sb.append(champs[12].trim());
      if( HPRIMTextUtil.isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("\n");
    }
    return(sb.toString());
  }

  private static String[] decoupeRES(String s) {
    String[] answer = new String[13];
    int separateur = -1;
    int suivant = s.indexOf(RESSeparator);
    if( suivant == -1)
      return answer;
    for (int k = 0; k < answer.length; ++k) {
      separateur =  suivant;
      if (separateur == s.length())
        break;
      suivant = s.indexOf(RESSeparator, separateur + 1);
      if (suivant == -1) {
        answer[k] = s.substring(separateur + 1, s.length());
        break;
      }
      answer[k] = s.substring(separateur + 1, suivant);
    }
    return answer;
  }


}