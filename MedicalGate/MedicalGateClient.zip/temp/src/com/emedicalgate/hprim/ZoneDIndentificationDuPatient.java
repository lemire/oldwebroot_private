package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.io.*;
import java.text.*;
import java.util.*;

public class ZoneDIndentificationDuPatient  {

  protected String mCode, mNom, mPrenom, mAdresse1, mAdresse2, mCodePostal, mVille,
     mNaissance, mSecuriteSociale, mSecuriteSocialeExt, mDossier, mDateDossier,
     mCodeCorrespondant, mNomDuCorrespondant, mCodePrescripteur, mNomDuPrescripteur;

  protected java.util.Date mDateNaissance;
  protected java.util.Date mSentDate;
  protected static Locale mCurrentLocale = new Locale("fr","FR","");
  protected static DateFormat mDateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,mCurrentLocale);

  protected static SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ("dd/MM/yy");
  public ZoneDIndentificationDuPatient(BufferedReader r) throws IOException {
    parse(r);
  }

  public String getHTML() {
    StringBuffer sb = new StringBuffer();

    if(HPRIMTextUtil.isDisplayable(mCode)) {
      sb.append("<b>Code patient:</b> ");
      sb.append(mCode.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mNom)) {
      sb.append("<b>Nom:</b> ");
      sb.append(mNom.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mPrenom)) {
      sb.append("<b>Pr�nom:</b> ");
      sb.append(mPrenom.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mAdresse1)) {
      sb.append("<b>Adresse:</b> ");
      sb.append(mAdresse1.trim());
      sb.append("<br>");
      if(HPRIMTextUtil.isDisplayable(mAdresse2)) {
        sb.append(mAdresse2.trim());
        sb.append("<br>");
      }
    }
    if(HPRIMTextUtil.isDisplayable(mCodePostal)) {
      sb.append("<b>Code postal:</b> ");
      sb.append(mCodePostal.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mVille)) {
      sb.append("<b>Ville:</b> ");
      sb.append(mVille.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mNaissance)) {
      sb.append("<b>Date de naissance:</b> ");
      sb.append(mNaissance.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mSecuriteSociale)) {
      sb.append("<b>Code de s�curit� sociale du patient:</b> ");
      sb.append(mSecuriteSociale.trim());
      if(HPRIMTextUtil.isDisplayable(mSecuriteSocialeExt)) {
        sb.append(" <b>extension:</b> ");
        sb.append(mSecuriteSocialeExt.trim());
      }
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mDossier)) {
      sb.append("<b>Num�ro de dossier:</b> ");
      sb.append(mDossier.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mDateDossier)) {
      sb.append("<b>Date du dossier:</b> ");
      sb.append(mDateDossier.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mCodeCorrespondant)) {
      sb.append("<b>Code correspondant:</b> ");
      sb.append(mCodeCorrespondant.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mNomDuCorrespondant)) {
      sb.append("<b>Nom du correspondant:</b> ");
      sb.append(mNomDuCorrespondant.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mCodePrescripteur)) {
      sb.append("<b>Code prescripteur:</b> ");
      sb.append(mCodePrescripteur.trim());
      sb.append("<br>");
    }
    if(HPRIMTextUtil.isDisplayable(mNomDuPrescripteur)) {
      sb.append("<b>Nom du prescripteur:</b> ");
      sb.append(mNomDuPrescripteur.trim());
      sb.append("<br>");
    }

    return(sb.toString());
  }
  public String getText() {
    StringBuffer sb = new StringBuffer();

    if(HPRIMTextUtil.isDisplayable(mCode)) {
      sb.append("Code patient: ");
      sb.append(mCode.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mNom)) {
      sb.append("Nom: ");
      sb.append(mNom.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mPrenom)) {
      sb.append("Pr�nom: ");
      sb.append(mPrenom.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mAdresse1)) {
      sb.append("Adresse: ");
      sb.append(mAdresse1.trim());
      sb.append("\n");
      if(HPRIMTextUtil.isDisplayable(mAdresse2)) {
        sb.append(mAdresse2.trim());
        sb.append("\n");
      }
    }
    if(HPRIMTextUtil.isDisplayable(mCodePostal)) {
      sb.append("Code postal: ");
      sb.append(mCodePostal.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mVille)) {
      sb.append("Ville: ");
      sb.append(mVille.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mNaissance)) {
      sb.append("Date de naissance: ");
      sb.append(mNaissance.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mSecuriteSociale)) {
      sb.append("Code de s�curit� sociale du patient: ");
      sb.append(mSecuriteSociale.trim());
      if(HPRIMTextUtil.isDisplayable(mSecuriteSocialeExt)) {
        sb.append(" extension: ");
        sb.append(mSecuriteSocialeExt.trim());
      }
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mDossier)) {
      sb.append("Num�ro de dossier: ");
      sb.append(mDossier.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mDateDossier)) {
      sb.append("Date du dossier: ");
      sb.append(mDateDossier.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mCodeCorrespondant)) {
      sb.append("Code correspondant: ");
      sb.append(mCodeCorrespondant.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mNomDuCorrespondant)) {
      sb.append("Nom du correspondant: ");
      sb.append(mNomDuCorrespondant.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mCodePrescripteur)) {
      sb.append("Code prescripteur: ");
      sb.append(mCodePrescripteur.trim());
      sb.append("\n");
    }
    if(HPRIMTextUtil.isDisplayable(mNomDuPrescripteur)) {
      sb.append("Nom du prescripteur: ");
      sb.append(mNomDuPrescripteur.trim());
      sb.append("\n");
    }

    return(sb.toString());
  }


  private void parse(BufferedReader r) throws IOException {
    mCode =  r.readLine();
    if(mCode == null)
      throw new IOException("End of content!");
    mNom = r.readLine();
    mPrenom = r.readLine();
    // il arrive qu'une ligne vide s�pare le pr�nom et le nom
    if (! HPRIMTextUtil.isDisplayable(mPrenom))
      mPrenom = r.readLine();
    // fin du hack!
    mAdresse1 = r.readLine();
    mAdresse2 = r.readLine();
    String CodePostalEtVille = r.readLine();
    if ((CodePostalEtVille != null) && (CodePostalEtVille.length() > 6)) {
      mCodePostal = CodePostalEtVille.substring(0,5);
      mVille = CodePostalEtVille.substring(6,CodePostalEtVille.length());
    }
    mNaissance = r.readLine();
    String Secu =  r.readLine();
    if (Secu != null) {
      int PositionDeLEspace = -1;
      if ( (PositionDeLEspace = Secu.indexOf(" ") ) != -1) {
        mSecuriteSociale = Secu.substring(0,PositionDeLEspace);
        mSecuriteSocialeExt = Secu.substring(PositionDeLEspace + 1, Secu.length());
      } else {
        mSecuriteSociale = Secu;
      }
    }
    mDossier  = r.readLine();
    mDateDossier  = r.readLine();
    String Correspondant = r.readLine();
    if ( Correspondant != null ) {
      if ( Correspondant.length() > 11 ) {
        mCodeCorrespondant = Correspondant.substring(0,11);
        mNomDuCorrespondant = Correspondant.substring(12,Correspondant.length());
      }
    }
    String Prescripteur = r.readLine();
    if ( Prescripteur != null ) {
      if ( Prescripteur.length() > 11 ) {
        mCodePrescripteur = Prescripteur.substring(0,11);
        mNomDuPrescripteur = Prescripteur.substring(12,Prescripteur.length());
      }
    }
  }

  public String getPatientFirstName()   {
    return mPrenom;
  }

  public String getPatientLastName()  {
    return mNom;
  }

  public java.util.Date getPatientBirthDate()  {
    if(mDateNaissance == null) {
      try {
        mDateNaissance = mSimpleDateFormat.parse(mNaissance);
  //      System.out.println("date should be "+mSimpleDateFormat.format(mDateNaissance));
      } catch (java.text.ParseException pe) {
        pe.printStackTrace();
      }
      if( mDateNaissance == null)
        mDateNaissance = new Date();
    }
    return mDateNaissance;
  }

  public java.util.Date getDate() {
    if(mSentDate == null) {
      try {
        mSentDate = mSimpleDateFormat.parse(mDateDossier);
//        System.out.println("date should be "+mSimpleDateFormat.format(mDateNaissance));
      } catch (java.text.ParseException pe) {
        pe.printStackTrace();
      }
      if( mSentDate == null)
        mSentDate = new Date();
    }
    return mSentDate;
  }

}



