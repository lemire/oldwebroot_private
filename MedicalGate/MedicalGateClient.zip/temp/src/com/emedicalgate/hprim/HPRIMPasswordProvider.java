package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

public interface HPRIMPasswordProvider {

  public byte[] askHPRIMPassword();
  public boolean wantToReenterHPRIMPassword(HPRIMFile file);
}