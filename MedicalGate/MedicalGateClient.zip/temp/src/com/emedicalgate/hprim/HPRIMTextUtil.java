package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

public final class HPRIMTextUtil {

  private HPRIMTextUtil() {
  }

  public static boolean isDisplayable(String s) {
    if (s == null)
      return (false);
    if (s.trim().length() == 0)
      return (false);
    return (true);
  }
  public static String removeUnknownISO(String s) {
    if(s == null)
      return null;
    StringBuffer sb = new StringBuffer();
    char c;
    for (int k = 0; k < s.length(); ++k) {
      if (!Character.isISOControl(c = s.charAt(k))) {
        sb.append(c);
       // System.out.print(c);
      } else if (c == '\t') {
        sb.append(c);
       // System.out.print("\\t");
      } else if (c == '\n') {
        sb.append(c);
       // System.out.println("\\n");
      } else if (c == '\r') {
        sb.append(c);
       // System.out.println("\\r");
      } else {
       // System.out.print("[unknown char = "+(int) c+"]");
        sb.append("\t");
      }
    }
    return(sb.toString());
  }
  public static String removeAllISO(String s) {
    if(s == null)
      return null;
    StringBuffer sb = new StringBuffer();
    char c;
    for (int k = 0; k < s.length(); ++k) {
      if (!Character.isISOControl(c = s.charAt(k))) {
        sb.append(c);
      } /*else if ((c == '\t') || (c == '\n') || (c == '\r')) {// on autorise certains caract�res
        sb.append(c);
      }*/
    }
    return(sb.toString());
  }
}