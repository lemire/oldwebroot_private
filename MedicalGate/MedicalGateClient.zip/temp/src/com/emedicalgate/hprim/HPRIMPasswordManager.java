package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class HPRIMPasswordManager {
  private byte[] mPassword;
  static HPRIMPasswordManager mHPRIMPasswordManager;

  private HPRIMPasswordManager() {
    loadPassword();
  }

  public static HPRIMPasswordManager getInstance() {
    if(mHPRIMPasswordManager == null)
      mHPRIMPasswordManager = new HPRIMPasswordManager();
    return mHPRIMPasswordManager;
  }

  public void setPassword(byte[] password) {
    mPassword = password;
    savePassword();
  }

  public byte[] getPassword() {
    return mPassword;
  }

  private void savePassword() {
    if(mPassword == null)
      mPassword = new byte[0];
    File medicalGateDir = new File(System.getProperty("user.home"),"MedicalGate");
    File config = new File(medicalGateDir,"hprim.txt");
    try {
      Properties p = new Properties();
      p.setProperty("password",new String(mPassword,HPRIMFile.mEncoding));
      FileOutputStream fos = new FileOutputStream(config);
      try {
        p.store(fos,"HPRIM Password");
      } finally {
        fos.close();
      }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  private void loadPassword() {
    File medicalGateDir = new File(System.getProperty("user.home"),"MedicalGate");
    File config = new File(medicalGateDir,"hprim.txt");
    try {
    if(config.exists()) {
      Properties p = new Properties();
      FileInputStream fis = new FileInputStream(config);
      try {
        p.load(fis);
      } finally {
        fis.close();
      }
      if(p.get("password") != null)
        mPassword = ((String) p.get("password")).getBytes(HPRIMFile.mEncoding);

    }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }
}