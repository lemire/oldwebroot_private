package com.emedicalgate.hprim;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.io.*;

public class DossierHPRIM  {

  ZoneDIndentificationDuPatient mZoneID;
  ResultatsCodifies mResultatCodifie;
  String mCompteRendu;

  public DossierHPRIM(BufferedReader r) throws IOException {

    mZoneID = new  ZoneDIndentificationDuPatient(r);
    String s = readCompteRendu(r);
    if (s == null)
      throw new IOException("Le fichier HPRIM n'est pas reconnu. Pas de ****FIN**** d�tect� au bon endroit!");
    if(s.startsWith("****LAB****") ) {
        mResultatCodifie = new ResultatsCodifies(r);
    }
   // setupComponents();
    System.out.println("Dossier HPRIM termin�!");
  }

  public ZoneDIndentificationDuPatient getZoneDIndentificationDuPatient() {
    return mZoneID;
  }

  public ResultatsCodifies getResultatCodifie() {
    return mResultatCodifie;
  }

  public String getCompteRendu() {
    return mCompteRendu;
  }
  public String getCompteRenduHTML() {
    BufferedReader br = new BufferedReader(new StringReader(mCompteRendu));
    StringBuffer sb = new StringBuffer();
    String s;
    try {
      while((s = br.readLine())!=null) {
        sb.append(s);
        sb.append("<br>");
      }
    } catch (IOException ioe) {}
    return sb.toString();
  }
/*
  private void setupComponents() {
    setLayout(new GridLayout(0,1,0,0));
    JTabbedPane pane = new JTabbedPane();
    pane.add("identification",new JScrollPane(mZoneID));
    pane.add("compte-rendu",new JScrollPane(mTextArea));
    if( mResultatCodifie != null ) {
      pane.add("r�sultats codifi�s",new JScrollPane(mResultatCodifie));
    }
    add(pane);
  }
*/
/*  public static String removeISO(String s) {
    if(s == null)
      return null;
    StringBuffer sb = new StringBuffer();
    char c;
    for (int k = 0; k < s.length(); ++k) {
      if (!Character.isISOControl(c = s.charAt(k)))
        sb.append(c);
    }
    return(sb.toString());
  }
*/
  private String readCompteRendu(BufferedReader r) throws IOException  {
    StringBuffer sb = new StringBuffer();
    String s = null;
    while((s = r.readLine()) != null) {
      String allISORemoved = HPRIMTextUtil.removeAllISO(s);
      if (allISORemoved.startsWith("****LAB****") || allISORemoved.startsWith("****FIN****") || allISORemoved.startsWith("*****FIN*****") || allISORemoved.startsWith ("****FINFICHIER****") || allISORemoved.startsWith ("*****FINFICHIER*****")) {
        System.out.println("fin du compte rendu d�tect�!");
        break;
      } else {
        sb.append(s);
        sb.append('\n');
      }
    }
    mCompteRendu = sb.toString();
    return (s);
  }

}

