package com.emedicalgate.client;

import javax.swing.*;
import javax.swing.table.*;
import javax.mail.*;
import javax.mail.internet.*;
import com.emedicalgate.mmf.*;
import com.emedicalgate.mmf.database.*;
import java.io.*;
import com.emedicalgate.hprim.*;

class MedicalTableModel extends AbstractTableModel implements MMFMessageProvider {

    private final static String mMMFError = "Erreur dans le dossier MMF: ";
    private transient Folder mFolder;
    private MMFLocalFolder.MMFQuickFolder mQuickFolder;
    private String[] mColumnNames = {"pr�nom du patient","nom du patient", "date de naissance","sujet","m�decin","sp�cialit�","date de l'envoi"};
    private Class[] mColumnTypes = { String.class, String.class, java.util.Date.class ,String.class, String.class, String.class,String.class,java.util.Date.class };
    private MedicalTable mOwner;
    private HPRIMPasswordProvider mPasswordProvider = DefaultHPRIMPasswordProvider.getInstance();

    public MedicalTableModel ( MedicalTable owner) {
      mOwner = owner;
    }

    public void setQuickFolder(MMFLocalFolder.MMFQuickFolder quickfolder) {
      mQuickFolder = quickfolder;
      fireTableDataChanged();
    }

    public void setFolder(Folder folder ) throws MessagingException {
	if (folder != null) {
	    if (!folder.isOpen()) {
		folder.open(Folder.READ_WRITE);
	    }
            int TotalNumberOfNewMessages = folder.getMessageCount();
            if (TotalNumberOfNewMessages == 0) {
              JOptionPane.showMessageDialog(mOwner, "Aucun nouveau dossier MMF n'a �t� trouv� sur le serveur.",BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
            } else {
              JOptionPane.showMessageDialog(mOwner, "Vous avez "+TotalNumberOfNewMessages+" nouveaux dossiers MMF sur le serveur.",BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
             // pm.setMillisToPopup(0);
              ProgressMonitor pm = new ProgressMonitor(mOwner,"T�l�chargement des dossiers MMF",getNote(0,TotalNumberOfNewMessages),0,TotalNumberOfNewMessages);
              pm.setProgress(0);
              pm.setMillisToDecideToPopup(1000);
              MMFMessage[] NewMessages = new MMFMessage[TotalNumberOfNewMessages];
              for(int k = 0; k < TotalNumberOfNewMessages ; k++) {
                try {
                  NewMessages[k] = new MMFMessage((MimeMessage) folder.getMessage(k + 1), mPasswordProvider);
                } catch (MessagingException me) {
                  BasicApplet.warn(me,"Un dossier n'a pu �tre r�cup�r� � cause d'une erreur de formattage.");
                }
                if(MedicalTableModel.this.mOwner.mOwner.deleteOnServer()) {
                    System.out.println("deleting message "+k);
                    folder.getMessage(k + 1).setFlag(Flags.Flag.DELETED ,true);
                 }
                 System.out.println("MMFmessage = "+k);
                 if(pm.isCanceled() && (TotalNumberOfNewMessages - k - 1 > 0)) {
                      JOptionPane.showMessageDialog(mOwner, "Vous avez annul� le transfert de dossiers.\n"+(TotalNumberOfNewMessages - k - 1)+" dossier(s) n'ont pas �t� r�cup�r�(s).\nLes dossiers resteront disponibles sur le serveur.",BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
                      TotalNumberOfNewMessages = k + 1;
                      MMFMessage[] TempMessages = new MMFMessage[TotalNumberOfNewMessages];
                      System.arraycopy(NewMessages,0,TempMessages,0,TotalNumberOfNewMessages);
                      NewMessages = TempMessages;
                 } else {
                    pm.setNote(getNote(k,TotalNumberOfNewMessages));
                    pm.setProgress(k);
                 }
              }
              pm.setNote("Archivage des dossiers...");
              // on v�rifie d'abord si tous les messages ont pu �tre r�cup�r�s
              int RealNumberOfMessages = 0;
              for(int k = 0; k < NewMessages.length; ++k)
                if(NewMessages[k] != null)
                  ++RealNumberOfMessages;
              if(  RealNumberOfMessages != NewMessages.length ) {
                  MMFMessage[] TempMessages = new MMFMessage[RealNumberOfMessages];
                  int pointeur = 0;
                  for(int k = 0; k < NewMessages.length; ++k) {
                    if(NewMessages[k] != null)
                      TempMessages[pointeur++] = NewMessages[k];
                  }
                  NewMessages = TempMessages;
              }
              // ok, maintenant NewMessages ne contient que ce qu'il faut...
              System.out.println("On fait un QuickFolder 'append'...");
              mQuickFolder.getMMFLocalFolder().appendMessages(NewMessages);
              System.out.println("On fait un QuickFolder 'append'...ok");
              pm.close();
            }
	} else {
	    // rien � faire
	}
	if (mFolder != null) {
          try {
	    mFolder.close(true);
          } catch (Exception e) {
          }
        }
	mFolder = folder;
        try {
          mFolder.close(true);
        } catch (Exception e) {
        }
        fireTableDataChanged();
    }

    private String getNote(final int progress, final int max) {
        if(progress > 1) {
          System.out.println(progress+" dossiers sur un total de "+max);
          return(progress+" dossiers sur un total de "+max);
        }
        return(progress+" dossier sur un total de "+max);
    }

    public Message getMessage(int index) throws MessagingException {
	return mQuickFolder.getMessage(index);
    }
    public Message getMessage(MMFDescriptor mmfdesc) throws MessagingException {
	return mQuickFolder.getMessage(mmfdesc);
    }
    public MMFDescriptor getMMFDescriptor(int index) throws MessagingException {
	return mQuickFolder.getMMFDescriptor(index);
    }

    public int getMessageCount() throws javax.mail.MessagingException {
      return mQuickFolder.getMessageCount();
    }

    public String getColumnName(int column) {
	return mColumnNames[column];
    }

    public Class getColumnClass(int column) {
	return mColumnTypes[column];
    }

    public int getColumnCount() {
        return mColumnNames.length;
    }

    public int getRowCount() {
      if(mQuickFolder != null)
        try {
          return mQuickFolder.getMessageCount();
        } catch (javax.mail.MessagingException e) {
          BasicApplet.warn(e);
          return 0;
        }
      return 0;
    }

    public void delete(int[] indexes) throws IOException {
      java.util.Arrays.sort(indexes);
      for(int k = indexes.length - 1; k >= 0 ; --k) {
        System.out.println("removing... "+indexes[k]);
//        mQuickFolder.dump();
        try {mQuickFolder.removeIndexNumber(indexes[k],false);} catch (IOException ioe) {ioe.printStackTrace();}
        this.fireTableRowsDeleted(indexes[k],indexes[k]);
  //      mQuickFolder.dump();
      }
      mQuickFolder.write();
    }

    public void transfertToDabase(int[] indexes, MMFDatabasePanel db) throws IOException {
      java.util.Arrays.sort(indexes);
      MMFDescriptor[] descriptors = new MMFDescriptor[indexes.length];
      for(int k = 0; k < descriptors.length; ++k) {
        try {
          descriptors[k] = mQuickFolder.getMMFDescriptor(indexes[k]);
          System.out.println("Transfert de :"+descriptors[k].toString());
        } catch (javax.mail.MessagingException me) {
          me.printStackTrace();
        }
      }
      System.out.println("On essaie de faire le transfert...");
      if(db.addMMFDescriptors(descriptors)) {
        descriptors = null;//free memory early
        for(int k = indexes.length - 1; k >= 0 ; --k) {
          try {mQuickFolder.removeIndexNumber(indexes[k],false);} catch (IOException ioe) {ioe.printStackTrace();}
          this.fireTableRowsDeleted(indexes[k],indexes[k]);
        }
        mQuickFolder.write();
      } else {
        JOptionPane.showMessageDialog(null,"Incapable d'effectuer le transfert." ,BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
      }
    }

    public Object getValueAt(int aRow, int aColumn) {
        try {
            MMF mmf = mQuickFolder.getMMFDescriptor(aRow);
	    switch(aColumn) {
	    case 0:	// patient
              return(mmf.getPatientFirstName());
            case 1:
              return(mmf.getPatientLastName());
            case 2:
              return(mmf.getPatientBirthDate());
	    case 3: // sujet		String[] what = getCachedData(aRow);
              return(mmf.getSubject());
	    case 4: // m�decin
              return(mmf.getDoctor());
            case 5: // sp�cialit�
              return(mmf.getSpeciality());
            case 6: // date
              return(mmf.getSentDate());
            default:
              return("");
            }

        } catch (MessagingException e) {
          return( mMMFError+e.toString() );
        }
    }


}
