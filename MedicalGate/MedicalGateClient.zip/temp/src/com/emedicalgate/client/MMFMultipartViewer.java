
package com.emedicalgate.client;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;
import javax.mail.*;
import javax.swing.*;


public class MMFMultipartViewer extends SaveAsPanel implements CommandObject {


    private  String verb = null;

    public MMFMultipartViewer() {
	super(new BorderLayout());

    }


    public void setCommandContext(String verb, DataHandler Dh) throws IOException {
        System.out.println("MMFMultipartViewer! 21:47");
	verb = verb;
	dh = Dh;

	// get the content, and hope it is a Multipart Object
        System.out.println("getting content");
	Object content = dh.getContent();
        System.out.println("have content");
	if (content instanceof Multipart) {
            System.out.println("setting up display");
	    setupDisplay((Multipart)content);
            System.out.println("setting up display ok ");

	} else {
            System.out.println("setting up error display");
	    setupErrorDisplay(content);
            System.out.println("setting up error display ok");
	}
    }

    protected void setupDisplay(Multipart mp) {
        System.out.println("setting up display for multipart");
	// we display the first body part in a main frame on the left, and then
	// on the right we display the rest of the parts as attachments
        /*
	GridBagConstraints gc = new GridBagConstraints();
	gc.gridheight = GridBagConstraints.REMAINDER;
	gc.fill = GridBagConstraints.BOTH;
	gc.weightx = 1.0;
	gc.weighty = 1.0;*/
        this.setLayout(new BorderLayout());

	// get the first part
	try {
	    BodyPart bp = mp.getBodyPart(0);
            System.out.println("First component has mime type : "+bp.getContentType());
	    Component comp = getComponent(bp);

	    add(comp, BorderLayout.CENTER);

	} catch (MessagingException me) {
            me.printStackTrace();
	    add(new JLabel(me.toString()), BorderLayout.CENTER);
	}

	// see if there are more than one parts
	try {
	    int count = mp.getCount();
            System.out.println("Nous avons "+count+" composantes...");
	    // setup how to display them
	    /*gc.gridwidth = GridBagConstraints.REMAINDER;
	    gc.gridheight = 1;
	    gc.fill = GridBagConstraints.NONE;
	    gc.anchor = GridBagConstraints.NORTH;
	    gc.weightx = 0.0;
	    gc.weighty = 0.0;
	    gc.insets = new Insets(4,4,4,4);*/
            JPanel below = new JPanel();
            below.setLayout(new GridLayout(0,1));

	    // for each one we create a button with the content type
	    for(int i = 1; i < count; i++) { // we skip the first one
            System.out.println("composante..."+(i+1));
		BodyPart curr = mp.getBodyPart(i);
		StringBuffer label = new StringBuffer();
                label.append("<html>");
                boolean labelempty = true;
                if(curr.getFileName() != null) {
                  label.append("<b>Nom du fichier</b>: ");
                  label.append(curr.getFileName());
                  labelempty = false;
                }
                boolean tipempty = true;
                StringBuffer tip = new StringBuffer();
                tip.append("<html>");
                if(curr.getDescription() != null) {
                  if(labelempty) {
                    label.append("<b>Description</b>: ");
                    label.append(curr.getDescription());
                    labelempty = false;
                  } else {
                    tip.append("<b>Description</b>: ");
                    tip.append(curr.getDescription());
                    tipempty = false;
                  }

                }
                if(curr.getContentType() != null) {
                  if(labelempty) {
                      label.append("<b>Mime</b>: ");
                      try {
                        MimeType mime = new MimeType( curr.getContentType() );
                        label.append(mime.getBaseType());
                        labelempty = false;
                      } catch (MimeTypeParseException mtpe) {
                        mtpe.printStackTrace();
                      }
                  } else {
                      try {
                        if(!tipempty)
                          tip.append("<br>");
                        tip.append("<b>Mime</b>: ");
                        MimeType mime = new MimeType( curr.getContentType() );
                        tip.append(mime.getBaseType());
                      } catch (MimeTypeParseException mtpe) {
                        mtpe.printStackTrace();
                      }

                  }
                }
                tip.append("</html>");
                label.append("</html>");
		JButton but = null;
                if(curr.getContentType() != null)
                 but =  new JButton(new AttachmentAction(curr,label.toString(),new IconProvider(curr.getContentType())));
                else
                  but = new JButton(new AttachmentAction(curr,label.toString()));
                but.setToolTipText(tip.toString());

		below.add(but/*, gc*/);
	    }
            if(count > 0)
              this.add(below,BorderLayout.SOUTH);
	} catch(MessagingException me2) {
            BasicApplet.warn(me2);
	    //me2.printStackTrace();
	}

    }




    protected Component getComponent(BodyPart bp) {

	try {
	    DataHandler dh = bp.getDataHandler();
	    CommandInfo ci = dh.getCommand("view");
	    if (ci == null) {
		throw new MessagingException(
		    "view command failed on: " +
		    bp.getContentType());
	    }

            Object bean = null;
            try {
              bean = ci.getCommandObject(dh,BasicApplet.class.getClassLoader());
              System.out.println("No fail-safe needed!");
            } catch(ClassNotFoundException cnfe) {
              cnfe.printStackTrace();
              System.out.println("Fail-safe, class not found!");
              MMFTextViewer mmfviewer= new MMFTextViewer();
              mmfviewer.setCommandContext("view", dh);
              bean = mmfviewer;
            } catch (Exception e) {
              e.printStackTrace();
              System.out.println("Fail-safe, critical error!");
              MMFTextViewer mmfviewer= new MMFTextViewer();
              mmfviewer.setCommandContext("view", dh);
              bean = mmfviewer;
            }

	    if (bean instanceof Component) {
		return (Component)bean;
	    } else {
		if (bean == null)
		    throw new MessagingException(
			"bean is null, class " + ci.getCommandClass() +
			" , command " + ci.getCommandName());
		else
		    throw new MessagingException(
			"bean is not a awt.Component" +
			bean.getClass().toString());
	    }
	}
	catch (Exception me) {
	    return new JLabel(me.toString());
	}

    }



    protected void setupErrorDisplay(Object content) {
	String error;

	if (content == null)
	    error = "Content is null";
	else
	    error = "Object not of type Multipart, content class = " +
	    content.getClass().toString();

	System.out.println(error);
	JLabel lab = new JLabel(error);
	add(lab);
    }

    class AttachmentAction extends AbstractAction {

	BodyPart bp = null;

	public AttachmentAction(BodyPart part) {
            super();
	    bp = part;
	}
	public AttachmentAction(BodyPart part,String text) {
            super(text);
	    bp = part;
	}
	public AttachmentAction(BodyPart part,String text,Icon icon) {
            super(text,icon);
	    bp = part;
	}

	public void actionPerformed(ActionEvent e) {
          try {
            this.setEnabled(false);
            System.out.println("Click!");
            Component component = getComponent(bp);
            System.out.println("component ok!");
            FrameComponentWrapper f = null;
            System.out.println("tool tip!");
            try {
              if((component instanceof JComponent) && (bp.getDescription() != null)) {
                System.out.println("Setting tool tip!");
                ((JComponent) component).setToolTipText(bp.getDescription());
              }
            } catch (MessagingException me) {
              me.printStackTrace();
            }
            System.out.println("tool tip! ok.");
            System.out.println("Building frame...");
            try {
              if(bp.getFileName() != null) {
                f = new FrameComponentWrapper(component,bp.getFileName());
                System.out.println("Building frame...ok");
              }
            } catch (MessagingException me) {
              me.printStackTrace();
            }

            if(f == null) {
              f = new FrameComponentWrapper(component,BasicApplet.mNameOfApplication);
              System.out.println("Building frame...ok (2)");
            }
            /*try {
              if(bp.getContentType() != null) {
                System.out.println("Setting icon image...");
                f.setIconImage((IconProvider.getImageIcon(bp.getContentType()).getImage()));
                System.out.println("Setting icon image...ok");
              }
            } catch (MessagingException me) {
              me.printStackTrace();
            }*/
            System.out.println("Frame created!");
	    f.pack();
	    f.show();
           } finally {
            this.setEnabled(true);
           }
	}
    }
  public String whoAmI() {
    return("MMFMultipartViewer");
  }

}
