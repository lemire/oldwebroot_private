

package com.emedicalgate.client;

import java.awt.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;
import javax.swing.*;




public class MMFTextViewer extends SaveAsPanel implements CommandObject, VistaPrintable {

    private JTextArea text_area = null;
    private String	verb = null;

    /**
     * Constructor
     */
    public MMFTextViewer() {
	super(new GridLayout(1,1));

	// create the text area
	text_area = new JTextArea();
        text_area.setWrapStyleWord(true);
	text_area.setEditable(false);
	text_area.setLineWrap(true);

	// create a scroll pane for the JTextArea
	JScrollPane sp = new JScrollPane();
	sp.setPreferredSize(new Dimension(300, 200));
	sp.getViewport().add(text_area);
	add(sp);
    }
    public JComponent getPrintingComponent() {
      return text_area;
    }

    public void setCommandContext(String verb, DataHandler Dh)
	throws IOException {
         System.out.println("MMFTextViewer!");

	this.verb = verb;
	this.dh = Dh;

	this.setInputStream( dh.getInputStream() );
    }


  /**
   * set the data stream, component to assume it is ready to
   * be read.
   */
  public void setInputStream(InputStream ins) {

      int bytes_read = 0;
      // check that we can actually read
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      byte data[] = new byte[1024];

      try {
	  while((bytes_read = ins.read(data)) >0)
		  baos.write(data, 0, bytes_read);
	  ins.close();
      } catch(Exception e) {
          BasicApplet.warn(e);
	  e.printStackTrace();
      }

      // convert the buffer into a string
      // place in the text area
      text_area.setText(baos.toString());
      setSavesAsPopup(text_area, dh.getName());

    }

    public void save(File file) {
      try {
        BufferedWriter bos = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
        try {
          if(text_area.getText() != null)
            bos.write(text_area.getText());
        } finally {
          bos.close();
        }
      } catch (IOException ioe) {
        BasicApplet.warn(ioe);
      }

    }
  public String whoAmI() {
    return("MMFTextViewer");
  }

}