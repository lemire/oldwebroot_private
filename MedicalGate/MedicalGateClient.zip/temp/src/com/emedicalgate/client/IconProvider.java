package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import javax.mail.*;
import javax.activation.*;
import java.beans.*;
import javax.swing.*;
import java.net.*;

public class IconProvider extends ImageIcon implements CommandObject {

        private static Hashtable mImageCache = new Hashtable();

        public IconProvider() {
          super();
        }

        public IconProvider (String contentType) {
          setIconImage( contentType );
        }

        public void paintIcon(Component c, Graphics g, int x, int y) {
          if((c!=null) && (g != null) && (getImage() != null)) {
            super.paintIcon(c, g, x, y);
          } else {
            if( c == null)
              System.err.println("IconProvide::paintIcon::Null Component");
            if (g == null)
              System.err.println("IconProvide::paintIcon::Null Graphics");
            if (getImage() == null)
              System.err.println("IconProvide::paintIcon::Null getImage()");
          }
        }


        private static String getImageName( MimeType mime ) {
                StringBuffer buf = new StringBuffer();
                buf.append( mime.getPrimaryType() );
                buf.append( "." );
                buf.append( mime.getSubType() );
                buf.append( ".gif" );
                return buf.toString();
        }
        private static String getFallBackImageName( MimeType mime ) {
                StringBuffer buf = new StringBuffer();
                buf.append( mime.getPrimaryType() );
                buf.append( ".gif" );
                return buf.toString();
        }

        private static Image locateIconImage( String iconName ) {
                Image result = null;
                StringBuffer buf = new StringBuffer();
                buf.append( "/images/mime/" );
                buf.append( iconName );

                System.out.println("locating image : "+buf.toString());
                URL imageURL = BasicApplet.class.getResource( buf.toString() );

                if ( imageURL != null )  {
                  System.out.println("ressource exist!");
                  try {
                        System.out.println("calling toolkit...");
                        result = Toolkit.getDefaultToolkit().createImage ( (ImageProducer) imageURL.getContent() );
                        System.out.println("calling toolkit...ok");
                  } catch (IOException ioe) {
                    ioe.printStackTrace();
                  }
                }
                System.out.println("Returning image...");
                return result;
        }

        public void setIconImage( String contentType )  {
          Image iconImg = getImage(contentType);
          if(iconImg != null)
            setImage(iconImg);
         }
        public static ImageIcon getImageIcon(String contentType) {
          return(new ImageIcon(getImage(contentType)));
        }
        public static Image getImage(String contentType) {
         Image iconImg = null;
          if (contentType == null)
            return null;
          try {
            MimeType mime = new MimeType( contentType );
            if((iconImg = (Image) mImageCache.get(mime.getBaseType())) != null) {
              return(iconImg);
            }
            iconImg =  locateIconImage (getImageName(mime));
            if ( iconImg != null )
              mImageCache.put( mime.getPrimaryType(), iconImg );
            else {
              iconImg =  locateIconImage (getFallBackImageName(mime));
              if ( iconImg != null )
                mImageCache.put( mime.getPrimaryType(), iconImg );
            }

          } catch (MimeTypeParseException mtpe) {
            mtpe.printStackTrace();
          }
          if ( iconImg == null)
            iconImg = locateIconImage ("unknown.unknown.gif");
          return(iconImg);
         }

        /**
         * the CommandObject method to accept our DataHandler
         * @param dh    the datahandler used to get the content
         */
        public void  setCommandContext( String verb, DataHandler Dh )  throws IOException {
                setIconImage( Dh.getContentType() );
        }



}