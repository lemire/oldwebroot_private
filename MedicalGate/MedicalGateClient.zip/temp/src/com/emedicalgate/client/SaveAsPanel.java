package com.emedicalgate.client;

import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import javax.activation.*;
import java.awt.print.*;

public abstract class SaveAsPanel extends JPanel {
  protected DataHandler dh = null;

  protected String mFileName = null;

  public SaveAsPanel() {
    super();
  }

  public SaveAsPanel(LayoutManager lm) {
    super(lm);
  }


  public void setSavesAsPopup(JComponent c, String filename) {
    mFileName = filename;
    JPopupMenu menu = new JPopupMenu();
    JMenuItem displaymenu = new JMenuItem("Menu");
    displaymenu.setEnabled(false);
    JMenuItem saveasmenu = new JMenuItem("Enregistrer sous...",BasicApplet.getIcon("/images/SaveAs24.gif"));
    JMenuItem printmenu = new JMenuItem("Imprimer...");
    menu.add(displaymenu);
    menu.add(saveasmenu);
    menu.add(printmenu);
    if(this instanceof VistaPrintable) {
      printmenu.setEnabled(true);
      printmenu.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        PrinterJob pj = PrinterJob.getPrinterJob();
        JComponent comp = ((VistaPrintable)SaveAsPanel.this).getPrintingComponent();
        JComponentVista jv = new JComponentVista(comp, new PageFormat());
//        jv.scaleToFitX();
        pj.setPageable(jv);
        try {
          if (pj.printDialog()) {
            pj.print();
          }
        } catch (PrinterException e) {
          System.out.println(e);
        }

      }
    });
    } else {
      printmenu.setEnabled(false);
      printmenu.setToolTipText("Cette composante ne peut �tre imprim�e.");
    }
    saveasmenu.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        SaveAsPanel.this.saveAs();
      }
    });
    PopupHelper.setPopup(c, menu);
  }

  protected void saveAs() {
    if(!areYouSure(new JLabel("<html>Un fichier sera enregistr� sur votre disque.<br>Un tel fichier peut contenir des virus<br>pouvant endommager votre ordinateur,<br>�tes-vous s�r de vouloir proc�der?</html>")))
      return;
    JFileChooser chooser = new JFileChooser();
    File DefaultDir = new File("c:\\Mes Documents");
    if(!DefaultDir.exists())
      DefaultDir = new File(System.getProperty("user.dir"));
    chooser.setSelectedFile(DefaultDir);
    if(mFileName != null)
      chooser.setSelectedFile(new File(DefaultDir,mFileName));
    else
      if(dh != null)
        if(dh.getName() != null)
          chooser.setSelectedFile(new File(DefaultDir,dh.getName()));
    int state = chooser.showSaveDialog(this);
    File file = chooser.getSelectedFile();
    if( (file != null) && (state == JFileChooser.APPROVE_OPTION)) {
        if(file.exists())
          if(JOptionPane.showConfirmDialog(this,"Un fichier avec ce nom existe, voulez-vous l'�craser?", BasicApplet.mNameOfApplication,JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
            return;
        try {
          save(file);
        } catch (IOException ioe) {
          StringBuffer sb = new StringBuffer();
          sb.append("<html>Le fichier <i>");
          sb.append(file.getAbsolutePath());
          sb.append("</i><br> n'a pu �tre enregistr�<br>� cause de l'erreur suivante<br>");
          StringWriter sos = new StringWriter();
          PrintWriter pw = new PrintWriter(sos);
          ioe.printStackTrace(pw);
          BufferedReader br = new BufferedReader(new StringReader(sos.toString()));
          String line = null;
          try {
            while ( ( line = br.readLine() ) != null) {
              sb.append("<br>");
              sb.append(line.trim());
            }
          } catch (IOException ioe2) {}
          sb.append("</html>");
          JOptionPane.showMessageDialog(this,new JLabel(sb.toString()) ,"Erreur dans l'enregistrement d'un fichier",JOptionPane.ERROR_MESSAGE);
          return;
        }
        StringBuffer sb = new StringBuffer();
        sb.append("<html>Le fichier <i>");
        sb.append(file.getAbsolutePath());
        sb.append("</i><br> a �t� enregistr�.</html>");
        JOptionPane.showMessageDialog(this,new JLabel(sb.toString()) ,"Enregistrement d'un fichier avec succ�s",JOptionPane.INFORMATION_MESSAGE);

    }
  }

    public void save(File file) throws IOException {
      if(dh == null) {
        throw new IOException("dh est nul!!! "+whoAmI());
      }
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        try {
          BufferedInputStream is = new BufferedInputStream(dh.getInputStream());
          try {
            int r = 0;
            while((r = is.read()) != -1)
              bos.write(r);
          } finally {
            is.close();
          }
        } finally {
          bos.close();
        }

    }

  protected boolean areYouSure(JComponent message) {
    if(System.getProperties().get("WarnForViruses") != null) {
      if(System.getProperties().get("WarnForViruses").equals("false"))
        return(true);
    }
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(message,BorderLayout.CENTER);

    JCheckBox Checkbox = new JCheckBox("Ne plus m'avertir durant cette session",false);
    Checkbox.addItemListener(new ItemListener() {
                public void itemStateChanged(ItemEvent e) {
                    if (e.getStateChange() == ItemEvent.DESELECTED) {

                      System.getProperties().put("WarnForViruses","true");
                    } else {
                      System.getProperties().put("WarnForViruses","false");

                    }
                }
            });


    panel.add(Checkbox,BorderLayout.SOUTH);
    return(JOptionPane.showConfirmDialog(this,panel, BasicApplet.mNameOfApplication,JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION);
  }

  public abstract String whoAmI();

}


