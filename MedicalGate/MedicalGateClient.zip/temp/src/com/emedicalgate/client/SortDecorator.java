
package com.emedicalgate.client;

import javax.swing.table.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

public class SortDecorator implements TableModel, TableModelListener {
  private TableModel realModel;
  private Integer indexes[];

  private  class DownComparator implements Comparator {
    int column;
    public DownComparator (final int column) {
      this.column = column;
    }
    public int compare(Object o1, Object o2) {
      return SortDecorator.this.compare(((Integer) o1).intValue(), ((Integer) o2).intValue(), column);
    }
/*    boolean equals(Object obj) {

    }*/
  };

  private class UpComparator implements Comparator  {
    int column;
    public UpComparator (final int column) {
      this.column = column;
    }
    public int compare(Object o1, Object o2) {
      return SortDecorator.this.compare(((Integer) o2).intValue(), ((Integer) o1).intValue(), column);
    }
/*    boolean equals(Object obj) {

    }*/
  };
  public SortDecorator(TableModel model) {
    if(model == null)
      throw new IllegalArgumentException("null model not allowed");
    this.realModel = model;
    realModel.addTableModelListener(this);
    allocate();
  }

  public int getRealRow(int row) {
    return((indexes[row]).intValue());
  }

  public Object getValueAt(int row, int column) {
    return realModel.getValueAt((indexes[row]).intValue(),column);
  }

  public void setValueAt(Object aValue, int row, int column) {
    realModel.setValueAt(aValue,(indexes[row]).intValue(),column);
  }

  public void tableChanged(TableModelEvent e) {
    allocate();
  }

  public void sort(final int column) {
    Arrays.sort(indexes,new DownComparator(column));
/*    System.out.println("sorting forward column "+column+" rows : "+getRowCount());
    boolean sortNeeded = false;
    int rowCount = getRowCount();
    for(int i = 0 ; i < rowCount ; ++i) {
      for(int j = i+1; j < rowCount; ++j) {
        if(compare(indexes[i], indexes[j], column) < 0) {
          swap(i,j);
          sortNeeded = true;
        }
      }
    }
    System.out.println("sorting forward column "+column+" ok");
    return(sortNeeded);*/
  }

  public void sortBackward(final int column) {
    Arrays.sort(indexes,new UpComparator(column));
  /*    System.out.println("sorting backward column "+column+" rows : "+getRowCount());
    boolean sortNeeded = false;
    int rowCount = getRowCount();
    for(int i = 0 ; i < rowCount ; ++i) {
      for(int j = i+1; j < rowCount; ++j) {
        if(compare(indexes[i], indexes[j], column) > 0) {
          swap(i,j);
          sortNeeded = true;
        }
      }
    }
    System.out.println("sorting backward column "+column+" ok");
    return(sortNeeded);*/
  }

/*  public void swap(int i, int j) {
    int tmp = indexes[i];
    indexes[i] = indexes[j];
    indexes[j] = tmp;
  }*/

  public int compare(final int i, final int j, final int column) {
    Object io = realModel.getValueAt(i, column);
    Object jo = realModel.getValueAt(j, column);
    return( jo.toString().compareTo(io.toString()) );
  }

  private void allocate() {
    if(indexes != null)
      if(realModel.getRowCount() == indexes.length)
        return;//rien de nouveau
    indexes = new Integer[realModel.getRowCount()];
    for(int i = 0 ; i < indexes.length; ++i) {
      indexes[i] = new Integer(i);
    }
  }

  public int getRowCount() {
    if(indexes == null)
      allocate();
    if(realModel.getRowCount() != indexes.length)
      allocate();
    return realModel.getRowCount();
  }

  public int getColumnCount() {
    if(indexes == null)
      allocate();
    return realModel.getColumnCount();
  }

  public String getColumnName(int columnIndex) {
    return realModel.getColumnName(columnIndex);
  }

  public Class getColumnClass(int columnIndex) {
    return realModel.getColumnClass(columnIndex);
  }

  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return realModel.isCellEditable(rowIndex,columnIndex);
  }

  public void addTableModelListener(TableModelListener l) {
    realModel.addTableModelListener(l);
  }

  public void removeTableModelListener(TableModelListener l) {
    realModel.removeTableModelListener(l);
  }


}
