package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import javax.swing.*;
import com.emedicalgate.hprim.*;
import java.awt.*;

public class DefaultHPRIMPasswordProvider  implements HPRIMPasswordProvider {

  static DefaultHPRIMPasswordProvider mDefaultHPRIMPasswordProvider;
  private JPanel mPasswordPanel;
  private JPasswordField mPF = new JPasswordField();

  private DefaultHPRIMPasswordProvider() {
  }

  public static DefaultHPRIMPasswordProvider getInstance() {
    if (mDefaultHPRIMPasswordProvider == null)
      mDefaultHPRIMPasswordProvider = new DefaultHPRIMPasswordProvider();
    return mDefaultHPRIMPasswordProvider;
  }

  public byte[] askHPRIMPassword() {
      if(mPasswordPanel == null) {
        mPasswordPanel = new JPanel(new GridLayout(0,1));
        JLabel Lb2 = new JLabel("Mot de passe HPRIM: ");
        mPasswordPanel.add(Lb2);
        mPasswordPanel.add(mPF);
        mPF.setToolTipText("Saisissez ici votre mot de passe HPRIM.");
      }
      if (JOptionPane.showConfirmDialog(null,mPasswordPanel,"HPRIM",
       JOptionPane.OK_CANCEL_OPTION , JOptionPane.QUESTION_MESSAGE) == JOptionPane.OK_OPTION) {
        try {
          return (new String(mPF.getPassword())).getBytes(HPRIMFile.mEncoding);
        } catch (java.io.UnsupportedEncodingException uee) {
          uee.printStackTrace();
          return (new String(mPF.getPassword())).getBytes();
        }
      }
      return null;
  }

  public boolean wantToReenterHPRIMPassword(HPRIMFile file) {
    System.out.println("wantToReenterHPRIMPassword...");
    StringBuffer sb = new StringBuffer();
    sb.append("Impossible d'ouvrir un dossier HPRIM de ");
    try {
      sb.append(file.getNomMedEmet().trim());
    } catch (Exception e) {
      sb.append(e.toString());
    }
    sb.append(" envoy� � ");
    try {
      sb.append(file.getNomCabDest().trim());
    } catch (Exception e) {
      sb.append(e.toString());
    }
    sb.append(".\n");
    sb.append("Voulez-vous entrer � nouveau votre mot de passe?\n");
    sb.append("(Cette option est utile si votre mot de passe HPRIM\n");
    sb.append("a �t� mal saisi ou doit �tre modifi�.\n");
    sb.append("Si cette bo�te de dialogue revient trop souvent\n");
    sb.append("vous devriez contacter le support technique.)");
    System.out.println("wantToReenterHPRIMPassword...ok");
    return (JOptionPane.showConfirmDialog(null,sb.toString(),"HPRIM (version "+file.getVersion()+")",
       JOptionPane.YES_NO_OPTION , JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION);
  }
}