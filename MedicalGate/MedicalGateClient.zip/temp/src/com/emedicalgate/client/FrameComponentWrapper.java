
package com.emedicalgate.client;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.mail.*;
import java.awt.print.*;

public class FrameComponentWrapper extends JFrame {

  private Component mComponent = null;

    public FrameComponentWrapper(Component what) {
	this(what, BasicApplet.mNameOfApplication);
        System.out.println("FrameComponentWrapper(Component what)");
    }

    public FrameComponentWrapper(Component what, String name) {
	super(name == null ? BasicApplet.mNameOfApplication : name);
        System.out.println("FrameComponentWrapper(Component what, String name)");
        mComponent = what;
        getContentPane().setLayout(new BorderLayout());
        JPanel contenant = new JPanel(new BorderLayout());
        contenant.setBorder(BorderFactory.createEtchedBorder());
        getContentPane().add(contenant,BorderLayout.CENTER);
	setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	if (what != null) {
	    contenant.add(what,BorderLayout.CENTER);
	}
        if(mComponent instanceof SaveAsPanel) {
          setupMenu();
        } else {
//          System.out.println("Ce n'est pas un SaveAsPanel! :"+mComponent.toString());
        }
        this.pack();
    }


    private void setupMenu() {
      JMenuBar bar = new JMenuBar();
      JMenu menufichier = new JMenu("Fichier");
      JMenuItem saveas = new JMenuItem("Enregistrer sous...",BasicApplet.getIcon("/images/SaveAs24.gif"));
      JMenuItem quit = new JMenuItem("Fermer cette fen�tre");
      JMenuItem printmenu = new JMenuItem("Imprimer...");
      menufichier.add(saveas);
      menufichier.add(printmenu);
      menufichier.addSeparator();
      menufichier.add(quit);
      if(mComponent instanceof VistaPrintable) {
        printmenu.setEnabled(true);
        printmenu.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent event) {
          PrinterJob pj = PrinterJob.getPrinterJob();
          JComponent comp = ((VistaPrintable)mComponent).getPrintingComponent();
          JComponentVista jv = new JComponentVista(comp, new PageFormat());
         // jv.scaleToFitX();
          pj.setPageable(jv);
          try {
            if (pj.printDialog()) {
              pj.print();
            }
          } catch (PrinterException e) {
            System.out.println(e);
          }

        }
      });
      } else {
        printmenu.setEnabled(false);
        printmenu.setToolTipText("Cette composante ne peut �tre imprim�e.");
      }
      bar.add(menufichier);
      this.setJMenuBar(bar);
      saveas.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent event) {
          ((SaveAsPanel)mComponent).saveAs();
        }
      });
      quit.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent event) {
          FrameComponentWrapper.this.setVisible(false);
          FrameComponentWrapper.this.dispose();
        }
      });
  }
}
