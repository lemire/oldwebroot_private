package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */


import java.awt.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;
import javax.swing.*;
import java.util.*;

import com.emedicalgate.io.*;

/*
* Cette classes est obselete!!!!!!!

*//*
public class MMFHPRIMTextViewer extends SaveAsPanel implements CommandObject {

    protected byte[] mContent, mEntete ;
    private String	verb = null;
    private String mNomMedEmet, mNomCabDest, mNomMedDest;
    protected int mVersion;
    private JPanel mPanel = new JPanel();
    private JLabel mHeaderLabel = new JLabel();
    public static final String mEncoding = "ISO-8859-1";//"Cp1252";//

    public MMFHPRIMTextViewer() {
        System.out.println("MMFHPRIMTextViewer!");
        setLayout(new BorderLayout());
        add(mHeaderLabel,BorderLayout.NORTH);
        mPanel.setPreferredSize(new Dimension(300,400));
        add(mPanel,BorderLayout.CENTER);
    }


    public void setCommandContext(String verb, DataHandler Dh) throws IOException {
	this.verb = verb;
	this.dh = Dh;
        InputStream is = dh.getInputStream();
	try {
          this.setInputStream( new BufferedInputStream( is ));
        } finally {
          is.close();
        }
    }


    private void readHeader(InputStream is) throws IOException {
      mEntete = new byte[256];
      is.read(mEntete);
      int position = 0;
      final int HeaderFieldLength = 40;
      mNomMedEmet = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      mNomCabDest = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      mNomMedDest = new String(mEntete,position,HeaderFieldLength,mEncoding);
      position += HeaderFieldLength;
      String ascii = new String(mEntete ,position, 2,mEncoding);
      position += 2;
      System.out.println(ascii + " "+ascii.length());
      byte [] b = new byte[2];
      String version = new String (mEntete, position,2,mEncoding);
      position += 2;
      System.out.println("'"+version+"'"+version.length());
      mVersion = Integer.parseInt(version);
      System.out.println(mVersion);
      System.out.println("string buffer");
      StringBuffer hd = new StringBuffer();
      hd.append("<html><b>M�decin �metteur:</b> ");
      hd.append(mNomMedEmet);
      hd.append("<br><b>Cabinet destinataire:</b> ");
      hd.append(mNomCabDest);
      hd.append("<br><b>M�decin destinataire:</b> ");
      hd.append(mNomMedDest);
      hd.append("<br><small><em>HPRIM version");
      hd.append(mVersion);
      hd.append("</em></small></html>");

      System.out.println("updating header label");
      mHeaderLabel.setText(hd.toString());
    }

     protected void readContent(InputStream is) throws IOException {
      System.out.println("MMFHPRIMTextViewer->readContent");
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      byte data[] = new byte[1024];
      int bytes_read = 0;
      while((bytes_read = is.read(data)) > 0)
	baos.write(data, 0, bytes_read);
      mContent = baos.toByteArray();
      System.out.println("displaying content...");
      displayContent();
      System.out.println("displaying content...ok");
    }

    protected void displayContent() {
      try {
        System.out.println("MMFHPRIMTextViewer->displayContent...");
        BufferedReader br = new BufferedReader(new StringReader(new String(mContent,mEncoding)));
        Vector v = new Vector();

        mPanel.setLayout(new GridLayout(1,0,0,0));
        try {
          while(true) {
            System.out.println("reading a dossier...");
            v.add(new DossierHPRIM(br));
            System.out.println("reading a dossier...ok");
          }
        } catch (Exception e) {
          if(v.size() == 0) {
            e.printStackTrace();
            System.out.println("On n'a m�me pas pu trouver un seul dossier!");
          }
        }
        System.out.println("J'ai trouv� "+v.size()+" dossiers...");
        if(v.size() > 1) {
          JTabbedPane pane = new JTabbedPane();
          Enumeration enum = v.elements();
          int k = 0;
          while (enum.hasMoreElements()) {
            pane.add(Integer.toString(++k),(Component)enum.nextElement());
          }
          mPanel.add(pane);

        } else {
          mPanel.add((Component)v.elementAt(0));
        }
        mPanel.invalidate();
        mPanel.validate();
      //  mPanel.repaint();

//        mPanel
  //      while (true) {
    //    }
      } catch (UnsupportedEncodingException uee) {
        uee.printStackTrace();
      }

    }

    public void setInputStream (InputStream is) throws IOException {
      System.out.println("reading header...");
      readHeader(is);
      System.out.println("reading content...");
      readContent(is);
      System.out.println("OK");
      if(dh != null) {
        setSavesAsPopup(mHeaderLabel, dh.getName()+".dec");
      } else {
        setSavesAsPopup(mHeaderLabel, "resutext.dec");
      }
      System.out.println("MMFHPRIMTextViewer->setInputStream...ok!");
    }

    public static void main(String[] arg) throws IOException {
      MMFHPRIMTextViewer viewer = new MMFHPRIMTextViewer();
      JFrame frame = new JFrame("HPRIM");
      frame.getContentPane().add(viewer);
      frame.pack();
      frame.setVisible(true);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      JFileChooser chooser = new JFileChooser("Fichier HPRIM");;
      int state = chooser.showOpenDialog(frame);
      File file = chooser.getSelectedFile();
      if( (file != null) && (state == JFileChooser.APPROVE_OPTION)) {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
        try {
          viewer.setInputStream(bis);
        } finally {
          bis.close();
        }
      } else {
        System.exit(0);
      }

    }

    public void save(File file) throws IOException {
        if((mEntete == null) || (mContent == null)) {
          throw new IOException("Un des contenus est nul!");
        }
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
        try {
            bos.write(mEntete);
            bos.write(mContent);
        } finally {
          bos.close();
        }
    }
  public String whoAmI() {
    return("MMFHPRIMTextViewer");
  }


}


class ZoneDIndentificationDuPatient extends JEditorPane  {
  String mCode, mNom, mPrenom, mAdresse1, mAdresse2, mCodePostal, mVille,
     mNaissance, mSecuriteSociale, mSecuriteSocialeExt, mDossier, mDateDossier,
     mCodeCorrespondant, mNomDuCorrespondant, mCodePrescripteur, mNomDuPrescripteur;

  public ZoneDIndentificationDuPatient(BufferedReader r) throws IOException {
    parse(r);
    setEditable(false);
    this.setContentType("text/html");
    setText(getHTML());
  }

  public String getHTML() {
    StringBuffer sb = new StringBuffer();
    sb.append("<html>");
    if(isDisplayable(mCode)) {
      sb.append("<b>Code patient:</b> ");
      sb.append(mCode.trim());
      sb.append("<br>");
    }
    if(isDisplayable(mNom)) {
      sb.append("<b>Nom:</b> ");
      sb.append(mNom.trim());
      sb.append("<br>");
    }
    if(isDisplayable(mPrenom)) {
      sb.append("<b>Pr�nom:</b> ");
      sb.append(mPrenom.trim());
      sb.append("<br>");
    }
    if(isDisplayable(mAdresse1)) {
      sb.append("<b>Adresse:</b> ");
      sb.append(mAdresse1.trim());
      sb.append("<br>");
      if(isDisplayable(mAdresse2)) {
        sb.append(mAdresse2.trim());
        sb.append("<br>");
      }
    }
    if(isDisplayable(mCodePostal)) {
      sb.append("<b>Code postal:</b> ");
      sb.append(mCodePostal);
      sb.append("<br>");
    }
    if(isDisplayable(mVille)) {
      sb.append("<b>Ville:</b> ");
      sb.append(mVille);
      sb.append("<br>");
    }
    if(isDisplayable(mNaissance)) {
      sb.append("<b>Date de naissance:</b> ");
      sb.append(mNaissance);
      sb.append("<br>");
    }
    if(isDisplayable(mSecuriteSociale)) {
      sb.append("<b>Code de s�curit� sociale du patient:</b> ");
      sb.append(mSecuriteSociale);
      if(isDisplayable(mSecuriteSocialeExt)) {
        sb.append(" <b>extension:</b> ");
        sb.append(mSecuriteSocialeExt);
      }
      sb.append("<br>");
    }
    if(isDisplayable(mDossier)) {
      sb.append("<b>Num�ro de dossier:</b> ");
      sb.append(mDossier);
      sb.append("<br>");
    }
    if(isDisplayable(mDateDossier)) {
      sb.append("<b>Date du dossier:</b> ");
      sb.append(mDateDossier);
      sb.append("<br>");
    }
    if(isDisplayable(mCodeCorrespondant)) {
      sb.append("<b>Code correspondant:</b> ");
      sb.append(mCodeCorrespondant);
      sb.append("<br>");
    }
    if(isDisplayable(mNomDuCorrespondant)) {
      sb.append("<b>Nom du correspondant:</b> ");
      sb.append(mNomDuCorrespondant);
      sb.append("<br>");
    }
    if(isDisplayable(mCodePrescripteur)) {
      sb.append("<b>Code prescripteur:</b> ");
      sb.append(mCodePrescripteur);
      sb.append("<br>");
    }
    if(isDisplayable(mNomDuPrescripteur)) {
      sb.append("<b>Nom du prescripteur:</b> ");
      sb.append(mNomDuPrescripteur);
      sb.append("<br>");
    }
    sb.append("</html>");
    return(sb.toString());
  }

  private static boolean isDisplayable(String s) {
    if (s == null)
      return (false);
    if (s.trim().length() == 0)
      return (false);
    return (true);
  }

  private void parse(BufferedReader r) throws IOException {
    mCode =  DossierHPRIM.removeISO(r.readLine());
    if(mCode == null)
      throw new IOException("End of content!");
    mNom = DossierHPRIM.removeISO(r.readLine());
    mPrenom = DossierHPRIM.removeISO(r.readLine());
    // il arrive qu'une ligne vide s�pare le pr�nom et le nom
    if (! isDisplayable(mPrenom))
      mPrenom = DossierHPRIM.removeISO(r.readLine());
    // fin du hack!
    mAdresse1 = DossierHPRIM.removeISO(r.readLine());
    mAdresse2 = DossierHPRIM.removeISO(r.readLine());
    String CodePostalEtVille = DossierHPRIM.removeISO(r.readLine());
    if ((CodePostalEtVille != null) && (CodePostalEtVille.length() > 6)) {
      mCodePostal = CodePostalEtVille.substring(0,5);
      mVille = CodePostalEtVille.substring(6,CodePostalEtVille.length());
    }
    mNaissance = DossierHPRIM.removeISO(r.readLine());
    String Secu =  DossierHPRIM.removeISO(r.readLine());
    if (Secu != null) {
      int PositionDeLEspace = -1;
      if ( (PositionDeLEspace = Secu.indexOf(" ") ) != -1) {
        mSecuriteSociale = Secu.substring(0,PositionDeLEspace);
        mSecuriteSocialeExt = Secu.substring(PositionDeLEspace + 1, Secu.length());
      } else {
        mSecuriteSociale = Secu;
      }
    }
    mDossier  = DossierHPRIM.removeISO(r.readLine());
    mDateDossier  = DossierHPRIM.removeISO(r.readLine());
    String Correspondant = r.readLine();
    if ( Correspondant != null ) {
      if ( Correspondant.length() > 10 ) {
        mCodeCorrespondant = Correspondant.substring(0,10);
        mNomDuCorrespondant = Correspondant.substring(11,Correspondant.length());
      }
    }
    String Prescripteur = DossierHPRIM.removeISO(r.readLine());
    if ( Prescripteur != null ) {
      if ( Prescripteur.length() > 10 ) {
        mCodePrescripteur = Prescripteur.substring(0,10);
        mNomDuPrescripteur = Prescripteur.substring(11,Prescripteur.length());
      }
    }
  }
}



class DossierHPRIM extends JComponent {

  ZoneDIndentificationDuPatient mZoneID;
  JTextArea mTextArea = new JTextArea();
  ResultatCodifie mResultatCodifie;

  public DossierHPRIM(BufferedReader r) throws IOException {
    mZoneID = new  ZoneDIndentificationDuPatient(r);
    String s = readCompteRendu(r);
    if (s == null)
      throw new IOException("Le fichier HPRIM n'est pas reconnu. Pas de ****FIN**** d�tect� au bon endroit!");
    if(s.startsWith("****LAB****") ) {
        mResultatCodifie = new ResultatCodifie(r);
    }
    setupComponents();
    System.out.println("Dossier HPRIM termin�!");
  }

  private void setupComponents() {
    setLayout(new GridLayout(0,1,0,0));
    JTabbedPane pane = new JTabbedPane();
    pane.add("identification",new JScrollPane(mZoneID));
    pane.add("compte-rendu",new JScrollPane(mTextArea));
    if( mResultatCodifie != null ) {
      pane.add("r�sultats codifi�s",new JScrollPane(mResultatCodifie));
    }
    add(pane);
  }

  public static String removeISO(String s) {
    if(s == null)
      return null;
    StringBuffer sb = new StringBuffer();
    char c;
    for (int k = 0; k < s.length(); ++k) {
      if (!Character.isISOControl(c = s.charAt(k)))
        sb.append(c);
    }
    return(sb.toString());
  }

  private String readCompteRendu(BufferedReader r) throws IOException  {
    StringBuffer sb = new StringBuffer();
    String s = null;
    JTextArea textarea = new JTextArea();

    mTextArea.setEditable(false);
    while((s = removeISO(r.readLine())) != null) {
      if (s.startsWith("****LAB****") || s.startsWith("****FIN****") || s.startsWith("*****FIN*****") || s.startsWith ("****FINFICHIER****") || s.startsWith ("*****FINFICHIER*****")) {
        System.out.println("fin du compte rendu d�tect�!");
        break;
      }
      mTextArea.append(s);
      mTextArea.append("\n");
    }
    return (s);
  }

}

class ResultatCodifie extends JEditorPane {
  final static int RESSeparator = 252;

  public ResultatCodifie(BufferedReader r) throws IOException{
    StringBuffer sb = new StringBuffer();
    sb.append("<html>");
    String s = null;
    while ((s = DossierHPRIM.removeISO(r.readLine())) != null) {
      if (s.startsWith("****LAB****") || s.startsWith("****FIN****") || s.startsWith("*****FIN*****") || s.startsWith ("****FINFICHIER****") || s.startsWith ("*****FINFICHIER*****")) {
        break;
      }
      if (s.startsWith("TEX")) {
        if(s.length() > 4) {
          sb.append(s.substring(4,s.length()));
        }
        sb.append("<br>");
      } else if (s.startsWith("RES")) {
        sb.append(transformRES(s));
      }
    }
    sb.append("</html>");
    this.setContentType("text/html");
    setText(sb.toString());
    setEditable(false);

  }

  private String transformRES(String s) {
    StringBuffer sb = new StringBuffer("");
    String[] champs = decoupeRES(s);
    if( isDisplayable(champs[0])) {
      sb.append("<b>Libell� de l'analyse:</b> ");
      sb.append(champs[0].trim());
      sb.append("<br>");
    }
    if( isDisplayable(champs[1])) {
      sb.append("<b>Code de l'analyse:</b> ");
      sb.append(champs[1].trim());
      sb.append("<br>");
    }
    if( isDisplayable(champs[2])) {
      sb.append("<b>Type de r�sultat:</b> ");
      if(champs[2].equalsIgnoreCase("A"))
        sb.append("analogique");
      else if (champs[2].equalsIgnoreCase("N"))
        sb.append("num�rique");
      else if (champs[2].equalsIgnoreCase("C"))
        sb.append("code");
      else
        sb.append("inconnu");
      sb.append("<br>");
    }
    if( isDisplayable(champs[3])) {
      sb.append("<b>R�sultat:</b> ");
      sb.append(champs[3].trim());
      if( isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( isDisplayable(champs[5])) {
      sb.append("<b>Valeur normale inf�rieure:</b> ");
      sb.append(champs[5].trim());
      if( isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( isDisplayable(champs[6])) {
      sb.append("<b>Valeur normale sup�rieure:</b> ");
      sb.append(champs[6].trim());
      if( isDisplayable(champs[4])) {
        sb.append(" ");
        sb.append(champs[4].trim());
      }
      sb.append("<br>");
    }
    if( isDisplayable(champs[7])) {
      sb.append("<b>Indicateur d'anormalit�:</b> ");
      if(champs[7].equalsIgnoreCase("L"))
        sb.append("inf�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("H"))
        sb.append("sup�rieur � la normale");
      else if (champs[7].equalsIgnoreCase("LL"))
        sb.append("inf�rieur � la valeur panique basse");
      else if (champs[7].equalsIgnoreCase("HH"))
        sb.append("inf�rieur � la valeur panique haute");
      else if (champs[7].equalsIgnoreCase("N"))
        sb.append("normal");
      else
        sb.append("indicateur d'anormalit� inconnu");
      sb.append("<br>");
    }
    if( isDisplayable(champs[8])) {
      sb.append("<b>Statut du r�sultat:</b> ");
      if (champs[8].equalsIgnoreCase("F"))
        sb.append("valide");
      else if (champs[8].equalsIgnoreCase("R"))
        sb.append("non valid�");
      else if (champs[8].equalsIgnoreCase("C"))
        sb.append("modifi�, corrig�");
      else
        sb.append("inconnu");
      sb.append("<br>");
    }

    if( isDisplayable(champs[9])) {
      sb.append("<b>R�sultat (deuxi�me unit�):</b> ");
      sb.append(champs[9].trim());
      if( isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    if( isDisplayable(champs[11])) {
      sb.append("<b>Valeur normale inf�rieure (deuxi�me unit�):</b> ");
      sb.append(champs[11].trim());
      if( isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    if( isDisplayable(champs[12])) {
      sb.append("<b>Valeur normale sup�rieure (deuxi�me unit�):</b> ");
      sb.append(champs[12].trim());
      if( isDisplayable(champs[10])) {
        sb.append(" ");
        sb.append(champs[10].trim());
      }
      sb.append("<br>");
    }
    return(sb.toString());
  }

  private static String[] decoupeRES(String s) {
    String[] answer = new String[13];
    int separateur = -1;
    int suivant = s.indexOf(RESSeparator);
    if( suivant == -1)
      return answer;
    for (int k = 0; k < answer.length; ++k) {
      separateur =  suivant;
      if (separateur == s.length())
        break;
      suivant = s.indexOf(RESSeparator, separateur + 1);
      if (suivant == -1) {
        answer[k] = s.substring(separateur + 1, s.length());
        break;
      }
      answer[k] = s.substring(separateur + 1, suivant);
    }
    return answer;
  }

  private static boolean isDisplayable(String s) {
    if (s == null)
      return (false);
    if (s.trim().length() == 0)
      return (false);
    return (true);
  }
}*/