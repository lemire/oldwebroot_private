package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import javax.swing.*;
import javax.activation.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

public class MMFNotAvailableViewer extends SaveAsPanel implements CommandObject {
  private JButton mSaveAs = new JButton("Enregistrer sous...",BasicApplet.getIcon("/images/SaveAs24.gif"));
  private JButton mLaunch = new JButton("Ex�cuter...",BasicApplet.getIcon("/images/Play24.gif"));

  private String	verb = null;
  private JTextField mNameLabel = new JTextField("?");
  private JTextField mMimeLabel = new JTextField("?");


  public MMFNotAvailableViewer() {
    	super(new GridLayout(0,1,5,5));
         this.add(new JLabel("<html>Ce type MIME ne peut pas<br>�tre pris en charge par le Pimmms.</html>"));
         this.add(mNameLabel);
         mNameLabel.setEditable(false);
         mNameLabel.setBorder(BorderFactory.createTitledBorder("Nom"));
         this.add(mMimeLabel);
         mMimeLabel.setEditable(false);
         mMimeLabel.setBorder(BorderFactory.createTitledBorder("D�claration de contenu"));
         this.add(mSaveAs);
         this.add(mLaunch);
         if(isUnix()) {
          mLaunch.setEnabled(false);
          mLaunch.setToolTipText("Cette option n'est disponible que sous l'environnement Windows.");
         }
         mSaveAs.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent event) {
              MMFNotAvailableViewer.this.mSaveAs.setEnabled(false);
              MMFNotAvailableViewer.this.saveAs();
              MMFNotAvailableViewer.this.mSaveAs.setEnabled(true);

          }
         });

         mLaunch.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent event) {
              if(areYouSure(new JLabel("<html>Le fichier que vous d�sirez lancer<br>peut contenir des virus<br>pouvant endommager votre ordinateur,<br> �tes-vous s�r de vouloir proc�der?</html>"))) {
                final File temp;
                try {
                  if( dh.getName() != null)
                    temp = File.createTempFile("Pimmms",dh.getName());
                  else
                    temp = File.createTempFile("Pimmms","txt");
                  System.out.println("cr�ation du fichier "+temp.getAbsolutePath());

                  temp.deleteOnExit();
                  Runnable run = new Runnable() {
                  public void run() {
                    try {
                      save(temp);
                      Process p = Runtime.getRuntime().exec("start "+temp);
                      p.waitFor();
                      BufferedReader br = new BufferedReader (new InputStreamReader(p.getInputStream()));
                      String line = null;
                      while (((line = br.readLine())!= null)) {
                        System.out.println(line);
                      }
                      br = new BufferedReader (new InputStreamReader(p.getErrorStream()));
                      line = null;
                      while (((line = br.readLine())!= null)) {
                        System.out.println(line);
                      }
                      temp.delete();
                    } catch (Exception e) {
                      e.printStackTrace();
                      BasicApplet.warn(e);
                    }
                  }};
                  Thread runthread = new Thread(run);
                  runthread.setPriority(Thread.MIN_PRIORITY);
                  runthread.start();
                } catch (IOException ioe) {
                  BasicApplet.warn(ioe);
                }
              }
          }
         });
  }

  private boolean isUnix() {
        return System.getProperty("file.separator").equals("/");
  }


/*
  private void saveAs() {

    JFileChooser chooser = chooser = new JFileChooser();;
    if(dh.getName() != null)
      chooser.setSelectedFile(new File(dh.getName()));
    int state = chooser.showSaveDialog(this);
    File file = chooser.getSelectedFile();
    if( (file != null) && (state == JFileChooser.APPROVE_OPTION)) {
        save(file);
    }
  }*/

/*  protected void save(File file) throws IOException {
      InputStream content = this.dh.getInputStream();
      BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
      int b = 0;
      try {
      while ((b = content.read())>= 0) {
        bos.write(b);
      }
      } catch (IOException ioe) {
        BasicApplet.warn(ioe);
      } finally {
        bos.close();
        content.close();
      }
  }
*/
    public void setCommandContext(String verb, DataHandler Dh)	throws IOException {
        System.out.println("MMFNotAvailableViewer!");
	this.verb = verb;
	this.dh = Dh;
        String s = dh.getName();
        if(s != null)
          mNameLabel.setText(s);
        s = dh.getContentType();
        if(s != null) {
          try {
            MimeType mime = new MimeType( s );
            mMimeLabel.setText(mime.getBaseType());
          } catch (MimeTypeParseException mtpe) {
            mtpe.printStackTrace();
          }
        }
    }

  public String whoAmI() {
    return("MMFNotAvailableViewer");
  }


}