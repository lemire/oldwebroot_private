

package com.emedicalgate.client;

import java.io.*;
import javax.activation.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.*;
import java.text.*;
import javax.mail.*;
import java.security.*;
import com.emedicalgate.mmf.*;
import java.lang.reflect.*;
import com.emedicalgate.mmf.database.*;

public class MedicalTable extends JTable  {

  private MedicalTableModel mTableModel;
  protected BasicApplet mOwner;
  private DefaultTableCellRenderer mDefaultTableCellRenderer = new DefaultTableCellRenderer();
  private DefaultTableCellRenderer mDownRenderer = new DefaultTableCellRenderer();
  private DefaultTableCellRenderer mUpRenderer = new DefaultTableCellRenderer();
  private SortDecorator mDecorator;


  public MedicalTable(BasicApplet owner) {
    super();
    mTableModel = new MedicalTableModel(this);
    mOwner = owner;
    readMailCap();
    try {
      this.setDefaultRenderer(Class.forName("java.lang.Object"),new MedicalTableRenderer());
    } catch(ClassNotFoundException cnfe) {BasicApplet.warn(cnfe);}
    linkEvents();
    setupHeaderRenderers();
  }

  private void linkEvents() {
    mDecorator = new SortDecorator(mTableModel);
    setModel(mDecorator);
    JTableHeader hdr = (JTableHeader) getTableHeader();
    hdr.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        TableColumnModel tcm = getColumnModel();
        int vc = tcm.getColumnIndexAtX(e.getX());
        int mc = convertColumnIndexToModel(vc);
        System.out.println("Sorting column "+mc);
        MedicalTable.this.sortColumn(mc);
      }
    });
    addMouseListener( new MouseAdapter() {
      int row = -1;
      final javax.swing.Timer timer = new javax.swing.Timer( 275, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          timer.stop();
        }
      });
      public void mouseClicked ( MouseEvent e ){
        if( timer.isRunning() && row == getSelectedRow() ){
          timer.stop();
          doubleClick(row);
        } else {
          timer.restart();
          row = getSelectedRow();
        }
      }
    });

    this.addKeyListener(new KeyAdapter() {
      public void keyTyped(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_DELETE) {
          delete(getSelectedRows());
        }
      }
    });
    JPopupMenu menu = new JPopupMenu();
    JMenuItem displaymenu = new JMenuItem("Menu");
    displaymenu.setEnabled(false);
    JMenuItem deletemenu = new JMenuItem(new DeleteAction());
    JMenuItem affichemenu = new JMenuItem(new LaunchAction());
    JMenuItem transfertmenu = new JMenuItem(new TransfertToDatabaseAction());
    menu.add(displaymenu);
    menu.add(deletemenu);
    menu.add(transfertmenu);
    menu.add(affichemenu);
    PopupHelper.setPopup(this, menu);
  }

  protected void sortColumn(final int mc) {
    TableCellRenderer MyHeaderRenderer = getHeaderRenderer(mc);
    if (MyHeaderRenderer ==  mDownRenderer) {
      mDecorator.sort(mc);
      setIcon(mc, mUpRenderer);
      this.repaint();
    } else {
      mDecorator.sortBackward(mc);
      setIcon(mc, mDownRenderer);
      this.repaint();
    }
  }

  private void setupHeaderRenderers() {
	mDefaultTableCellRenderer = new DefaultTableCellRenderer() {
	    public Component getTableCellRendererComponent(JTable table, Object value,
                         boolean isSelected, boolean hasFocus, int row, int column) {
	        if (table != null) {
	            JTableHeader header = table.getTableHeader();
	            if (header != null) {
	                setForeground(header.getForeground());
	                setBackground(header.getBackground());
	                setFont(header.getFont());
	            }
                }

                setText((value == null) ? "" : value.toString());
                setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	        return this;
            }
	};
	mDefaultTableCellRenderer.setHorizontalAlignment(JLabel.CENTER);
	mDownRenderer = new DefaultTableCellRenderer() {
	    public Component getTableCellRendererComponent(JTable table, Object value,
                         boolean isSelected, boolean hasFocus, int row, int column) {
	        if (table != null) {
	            JTableHeader header = table.getTableHeader();
	            if (header != null) {
	                setForeground(header.getForeground());
	                setBackground(header.getBackground());
	                setFont(header.getFont());
	            }
                }
                setText((value == null) ? "" : value.toString());
                setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
	        return this;
            }
	};
        mDownRenderer.setIcon(BasicApplet.getIcon("/images/Down16.gif"));
        mDownRenderer.setHorizontalTextPosition(JLabel.LEFT);
        mDownRenderer.setHorizontalAlignment(JLabel.CENTER);
	mUpRenderer = new DefaultTableCellRenderer() {
	    public Component getTableCellRendererComponent(JTable table, Object value,
                         boolean isSelected, boolean hasFocus, int row, int column) {
	        if (table != null) {
	            JTableHeader header = table.getTableHeader();
	            if (header != null) {
	                setForeground(header.getForeground());
	                setBackground(header.getBackground());
	                setFont(header.getFont());
	            }
                }
                setText((value == null) ? "" : value.toString());
                setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
	        return this;
            }
	};
        mUpRenderer.setIcon(BasicApplet.getIcon("/images/Up16.gif"));
        mUpRenderer.setHorizontalTextPosition(JLabel.LEFT);
        mUpRenderer.setHorizontalAlignment(JLabel.CENTER);
        TableColumnModel tcm = getColumnModel();
        int length = tcm.getColumnCount();
        for (int col = 0; col < length; ++col) {
          TableColumn tc = tcm.getColumn(col);
          tc.setHeaderRenderer(mDefaultTableCellRenderer);
        }
  }

  private TableCellRenderer getHeaderRenderer(final int column) {
    TableColumnModel tcm = getColumnModel();
    TableColumn tc = tcm.getColumn(column);
    return tc.getHeaderRenderer();
  }

  private void setIcon(int columnindex, DefaultTableCellRenderer renderer) {
    TableColumnModel tcm = getColumnModel();
    int length = tcm.getColumnCount();
    for (int col = 0; col < length; ++col) {
      TableColumn tc = tcm.getColumn(col);
      DefaultTableCellRenderer HeaderRenderer = (DefaultTableCellRenderer) tc.getHeaderRenderer();
      if(col == columnindex) {
        tc.setHeaderRenderer(renderer);
      } else {
        tc.setHeaderRenderer(mDefaultTableCellRenderer);
      }
    }
  }


  private void readMailCap() {
    try {
      BufferedInputStream is = new BufferedInputStream(BasicApplet.class.getResource(mOwner.mCapfile).openStream());
      CommandMap.setDefaultCommandMap( new MailcapCommandMap(is));
      is.close();
    } catch (IOException ioe2) {
      JOptionPane.showMessageDialog(this, ioe2.toString(),mOwner.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
      ioe2.printStackTrace();

    }
  }

  // should I try again?
  public boolean load(BasicApplet.MedicalAuthentificator auth) {
      final Session session;
      try {
        /*
        * le code qui suit est atrocement complexe, par expr�s...
        * mais c'est une longue histoire...
        */
        Class SessionClass = this.getClass().getClassLoader().loadClass("javax.mail.Session");
        Class[] c = {Class.forName("java.util.Properties"),Class.forName("javax.mail.Authenticator")};
        Method m = SessionClass.getDeclaredMethod("getInstance",c);
        Object[] o = {System.getProperties(), auth};
        session = (javax.mail.Session) m.invoke(null,o);
      } catch (Exception cnfe) {
        BasicApplet.warn(cnfe);
        cnfe.printStackTrace();
        return(false);
      }
      try {
        final URLName name = auth.getURLName();
        Store store = null;
        /*
        * Encore une fois, c'est atrocement complexe... longue histoire...
        */
        try {
        store = (Store) AccessController.doPrivileged(
        new PrivilegedExceptionAction()  {
             public Object run() throws javax.mail.NoSuchProviderException {
                  return session.getStore(name);
             }
           }
        );
        } catch (PrivilegedActionException e) {
          throw (javax.mail.NoSuchProviderException) e.getException();
        }
        MMFLocalStore localstore = new MMFLocalStore(session,name);
        // on s'assure d'afficher quelque chose!
        try {
          MMFLocalFolder mmflf = (MMFLocalFolder)localstore.getFolder("INBOX");
          mOwner.getDatabasePanel().setMMFMessageProvider(mmflf);
          mTableModel.setQuickFolder(mmflf.getMMFQuickFolderInstance());
        } catch (Exception me) {
          me.printStackTrace();
          BasicApplet.warn(me,"Nous ne pouvons r�cup�rer les messages de la bo�te de r�ception.");
        }

        mOwner.getDatabasePanel().loadDatabase(localstore.getStoreDirectory(),"MMFDB");
        try {
          while (!store.isConnected()) {
	    try {
              store.connect();
            } catch (AuthenticationFailedException afe) {
              JOptionPane.showMessageDialog(this, "L'identification a �chou�e.\nLe serveur de dossiers MMF ne reconna�t pas votre mot de passe\nou votre nom d'usager.",mOwner.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
              if(mOwner.showLoginDialog() == false) {//l'usager a annul� la transaction
                JOptionPane.showMessageDialog(this, "Vous n'avez pas obtenu l'autorisation n�cessaire\npour consulter des dossiers MMF sur le serveur.",mOwner.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
                return (false);
              } else {
                return(true);
              }
            } catch (Exception e) {
               BasicApplet.warn(e);
               return (false);
            }
	  }
          mTableModel.setFolder(store.getFolder("INBOX"));
        } catch (MessagingException me) {
          me.printStackTrace();
          JOptionPane.showMessageDialog(this, "Une erreur s'est produite pendant la recherche de dossiers sur le serveur.\nIl n'est pas possible de continuer normalement pour l'instant.\nVeuillez contacter le support technique."+"\n"+me.toString(),mOwner.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
          return (false);
        }
      } catch( javax.mail.NoSuchProviderException nspe) {
        nspe.printStackTrace();
        JOptionPane.showMessageDialog(this, "Le protocole \""+auth.getURLName().getProtocol()+"\" n'est pas reconnu par cette application.\nIl n'est pas possible de continuer normalement pour l'instant.\n Veuillez contacter le support technique."+"\n"+nspe.toString(),mOwner.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
        return (false);
      }
      return(false);
  //  }

  }

  private void delete(int[] rows) {
    if(rows.length == 0)
      return;
    StringBuffer text = new StringBuffer("Voulez-vous effacer ");
    if(rows.length == 1)
      text.append("le message s�lectionn�?");
    else {
      text.append("les ");
      text.append(rows.length);
      text.append(" messages s�lectionn�s?");
    }
    if ( JOptionPane.showConfirmDialog(this,text.toString(), BasicApplet.mNameOfApplication,JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION ) {
      try {
        for(int k = 0; k < rows.length ; ++k) {
          System.out.println(rows[k]+" -> "+mDecorator.getRealRow(rows[k]));
          rows[k] = mDecorator.getRealRow(rows[k]);
        }
        this.mTableModel.delete(rows);
      } catch (IOException ioe) {
        BasicApplet.warn(ioe);
      }
    }
  }

  private void transfertToDatabase(int[] rows) {
    if(rows.length == 0)
      return;
    StringBuffer text = new StringBuffer("Voulez-vous mettre ");
    if(rows.length == 1)
      text.append("le message s�lectionn�");
    else {
      text.append("les ");
      text.append(rows.length);
      text.append(" messages s�lectionn�s");
    }
    text.append(" dans la base de donn�es?");
    if ( JOptionPane.showConfirmDialog(this,text.toString(), BasicApplet.mNameOfApplication,JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION ) {
      try {
        for(int k = 0; k < rows.length ; ++k) {
          System.out.println(rows[k]+" -> "+mDecorator.getRealRow(rows[k]));
          rows[k] = mDecorator.getRealRow(rows[k]);
        }
        this.mTableModel.transfertToDabase(rows, MedicalTable.this.mOwner.getDatabasePanel());
      } catch (IOException ioe) {
        BasicApplet.warn(ioe);
      }
    }
  }

  private void doubleClick(final int row) {
       //JOptionPane.showMessageDialog(this, "Devrait afficher le d�tail de la ("+row+" + 1) i�me rang�e. Cette option n'est pas op�rationnelle.",BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);

       Thread run = new Thread(new Runnable() {
       public void run() {
        try {
          mOwner.setStatus("Chargement du dossier...",0);
          System.out.println("Getting message...");
          MMFMessage m = (MMFMessage) mTableModel.getMessage(mDecorator.getRealRow(row));
          System.out.println("Creating viewer...");
          mOwner.setStatus("Chargement du dossier... ok... Traitement du dossier...",20);
          MMFMessageViewer Viewer = new MMFMessageViewer(m);
          mOwner.setStatus("Chargement du dossier... ok... Traitement du dossier...ok",90);
          System.out.println("Creating frame...");
          try {
            FrameComponentWrapper fcw;
            if (m.getSubject() != null)
              fcw = new FrameComponentWrapper(Viewer,m.getSubject());
            else
              fcw = new FrameComponentWrapper(Viewer,"Sujet inconnu");
            fcw.setVisible(true);
          } catch (MessagingException me) {
            FrameComponentWrapper fcw = new FrameComponentWrapper(Viewer,me.toString());
            fcw.setVisible(true);
          } catch(Exception e) {
            BasicApplet.warn(e);
          }
          System.out.println("Creating frame...ok");
          mOwner.setStatus("",0);
        } catch (MessagingException me) {
          BasicApplet.warn(me);
        }}
      });
      run.setPriority(Thread.MIN_PRIORITY);
      run.start();
  }
  public AbstractAction getDeleteAction() {
    return new DeleteAction();
  }
  public AbstractAction getTransfertToDatabaseAction() {
    return new TransfertToDatabaseAction();
  }

  public LaunchAction getLaunchAction() {
    return new LaunchAction();
  }

  class DeleteAction extends AbstractAction {
      public DeleteAction() {
        super("Effacer", BasicApplet.getIcon("/images/Delete24.gif"));
      }
      public void actionPerformed(ActionEvent event) {
          MedicalTable.this.delete(getSelectedRows());
      }
  }

  class TransfertToDatabaseAction extends AbstractAction {
      public TransfertToDatabaseAction() {
        super("b.d.", BasicApplet.getIcon("/images/Export24.gif"));
      }
      public void actionPerformed(ActionEvent event) {
        MedicalTable.this.transfertToDatabase(getSelectedRows());
      }
  }

  class LaunchAction extends AbstractAction {
      public LaunchAction() {
        super("Ouvrir", BasicApplet.getIcon("/images/Open24.gif"));
      }

      public void actionPerformed(ActionEvent event) {
        MedicalTable.this.doubleClick(getSelectedRow());
      }
  }

}



