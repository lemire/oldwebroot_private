package com.emedicalgate.client;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;
import javax.swing.border.*;
import java.net.*;
import javax.mail.*;
import java.io.*;
import java.security.*;
import java.util.*;
import com.ondelette.installer.*;
import com.l2fprod.gui.plaf.skin.*;
import com.emedicalgate.mmf.database.*;
/*
* Cette applet est le prototype d'un client
* pour la nouvelle architecture de transmission
* des dossiers m�dicaux d�velopp� par M�dical Gate.
*/
public class BasicApplet extends JApplet {

  /*
  * param�tres provenant du HTML
  */
  private boolean isStandalone = false;
  private String mServerProtocol, mServerAddress;
  private String mLogin, mPassword;
  private int mServerPort;
  private boolean mSMIME;
  private String mLanguage;
  private String mMMFVersion;
  private boolean mDeleteOnServer;
  private JProgressBar mStatus;
  private URL mDownloadurl;
  /*
  * composantes graphiques
  */
  private MedicalTable mTable;
  private JToolBar mToolBar;
  private MMFDatabasePanel mMMFDatabasePanel;
  private RefreshAction mRefreshAction;

  public static String mNameOfApplication = "M�dical Gate Pimmms 1.7.8 ( java "+System.getProperty("java.version")+" / "+System.getProperty("java.vm.vendor")+")";
  protected String mCapfile = "/simple.mailcap";
  public Thread mLoadingUp = null;
  private JCheckBox mCheckbox;
  /*
  * fonction g�n�rique pour lire les param�tres
  * (soit comme des propri�t�s du syst�me, soit en provenance
  * du HTML
  */
  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  public BasicApplet() {
      super();
  }

  public MMFDatabasePanel getDatabasePanel() {
    return mMMFDatabasePanel;
  }

  protected URL getDownloadURL() {
    mDownloadurl = null;
    if( this.isStandalone ) {
      System.out.println("Is standalone!");
      File user = new File(System.getProperty("user.dir"));
      try {
        mDownloadurl = user.toURL();
      } catch (MalformedURLException mue) {
        mue.printStackTrace();
        mDownloadurl = this.getCodeBase();
      }
    } else {
      System.out.println("Is applet!");
      mDownloadurl = this.getCodeBase();
    }
    System.out.println(mDownloadurl.toString());
    return(mDownloadurl);
  }

  //Initialize the applet
  public void init() {
    String majorversion = System.getProperty("java.version").substring(0,3);
    System.out.println(majorversion);
    double mv = Double.parseDouble(majorversion);
    System.out.println(mv);
    if(mv < 1.3) {
      JOptionPane.showMessageDialog(null,"Vous utilisez une JVM non support�e : "+ System.getProperty("java.version"),BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
      System.out.println("JVM pas ok!");

    } else {
      System.out.println("JVM ok!");
    }
    System.out.println("java.vm.vendor : " + System.getProperty("java.vm.vendor"));
    boolean installed = false;
    try {
      if( installed = Installer.checkInstall(getDownloadURL()) ) {
        System.out.println("Librairies ok!");
      } else {
        System.out.println("Librairies not ok!");
        JOptionPane.showMessageDialog(this,"Les librairies n�cessaires n'ont pas pu �tre install�es correctement!" ,BasicApplet.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
      }
    } catch (Exception e) {
      e.printStackTrace();
      JOptionPane.showMessageDialog(this,"Les librairies n�cessaires n'ont pas pu �tre install�es correctement!\n Un probl�me inattendu est survenu.\n"+e.toString() ,BasicApplet.mNameOfApplication,JOptionPane.ERROR_MESSAGE);
    }
    boolean loadedAqua = loadAquaLookAndFeel();
    try {
      Class.forName("javax.mail.MessagingException");
//      if(!loadedAqua)
  //      JOptionPane.showMessageDialog(null,"Vous pouvez stopper et relancer votre fureteur ou l'application pour terminer l'installation." ,BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
    } catch (ClassNotFoundException cnfe) {
      if(installed)
        JOptionPane.showMessageDialog(null,"Veuillez stopper et relancer votre fureteur ou l'application pour terminer l'installation." ,BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
      else
        JOptionPane.showMessageDialog(null,"Il n'est pas possible de continuer normalement.\nConsultez le support technique." ,BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
    }
    setupGUI();

  }



  private void setupGUI() {
      try {mMMFDatabasePanel = new MMFDatabasePanel();} catch(Exception e) {BasicApplet.warn(e);}
      try {mTable = new MedicalTable(this);} catch(Exception e) {BasicApplet.warn(e);}
      try {readParameters();} catch(Exception e) {BasicApplet.warn(e);}
      try {setupComponents();} catch(Exception e) {BasicApplet.warn(e);}
  }
  /*
  * Initialisation des composantes.
  */
  private void setupComponents() throws Exception {
      mStatus = new JProgressBar(0, 100);
      mStatus.setForeground(Color.blue.brighter());
      mStatus.setBackground(Color.blue.darker());
      mToolBar = new JToolBar();
      mCheckbox = new JCheckBox("Effacer les dossiers sur le serveur", mDeleteOnServer);
      mCheckbox.setToolTipText("<html>Lorsque cette option est d�sactiv�e,<br>cela vous permet de consulter les dossiers<br>sur une machine autre que la v�tre<br>tout en pouvant les r�cup�rer sur celle-ci<br>plus tard.<html>");
      mCheckbox.addItemListener(new ItemListener() {
                public void itemStateChanged(ItemEvent e) {
                  JCheckBox checkbox =(JCheckBox) e.getSource();
                  try {
                    checkbox.setEnabled(false);
                    if (e.getStateChange() == ItemEvent.DESELECTED) {
                      mDeleteOnServer = false;
                      JOptionPane.showMessageDialog(null,"<html>Les dossiers vont maintenant demeurer sur le serveur<br>et pourront �tre r�cup�r� de multiples fois<br>ce qui est utile temporairement si vous avez<br>plus d'une machine. Vous devriez r�cup�rer<br>les dossiers avec l'option d'effacement<br>s�lectionn�e lorsque vous  �tes sur<br>votre machine <i>principale</i>.</html>" ,BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
                    } else {
                      JOptionPane.showMessageDialog(null,"<html>Les dossiers seront effac�s du serveur<br>apr�s t�l�chargement et ne pourront �tre<br>consult�s d'une autre machine par la suite.<br>Il s'agit de l'option recommand�e pour �viter<br>les t�l�chargements multiples d'un m�me dossier.</html>" ,BasicApplet.mNameOfApplication,JOptionPane.INFORMATION_MESSAGE);
                      mDeleteOnServer = true;
                    }
                  } finally {
                     checkbox.setEnabled(true);
                  }
                }
            });
    setupToolBar();
//    this.setSize(new Dimension(400,300));
    this.getContentPane().setLayout(new BorderLayout());
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    panel.add(new JScrollPane(mTable),BorderLayout.CENTER);
    panel.add(mToolBar,BorderLayout.NORTH);
    panel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
    JTabbedPane tabbedpane = new JTabbedPane();
    tabbedpane.add("Bo�te de r�ception",panel);
    tabbedpane.add("Base de donn�es",mMMFDatabasePanel);
    this.getContentPane().add(tabbedpane,BorderLayout.CENTER);
//    new BevelBorder(BevelBorder.RAISED));
  }

  /*
  * Montage de la ToolBar.
  * Voir aussi les classes RefreshAction et AboutAction.
  */
  private void setupToolBar() {
    mToolBar.setToolTipText("Barre de boutons");
    mRefreshAction = new RefreshAction();
    JButton RefreshButton = new JButton(mRefreshAction);
    RefreshButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    RefreshButton.setHorizontalTextPosition(SwingConstants.CENTER);
    RefreshButton.setToolTipText("Tableau de contr�le");
    mToolBar.add(RefreshButton);
    JButton SettingsButton = new JButton(new SettingsAction());
    SettingsButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    SettingsButton.setHorizontalTextPosition(SwingConstants.CENTER);
    SettingsButton.setToolTipText("Param�tres avanc�s");
    mToolBar.add(SettingsButton);
//    mToolBar.add(new LookAndFeelAction());
    JButton DeleteButton = new JButton(this.mTable.getDeleteAction());
    DeleteButton.setToolTipText("Effacer dossier");
    DeleteButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    DeleteButton.setHorizontalTextPosition(SwingConstants.CENTER);
    mToolBar.add(DeleteButton);
    JButton TransfertToDatabaseButton = new JButton(this.mTable.getTransfertToDatabaseAction());
    TransfertToDatabaseButton.setToolTipText("Transf�rer le dossier dans la base de donn�es");
    TransfertToDatabaseButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    TransfertToDatabaseButton.setHorizontalTextPosition(SwingConstants.CENTER);
    mToolBar.add(TransfertToDatabaseButton);
    JButton LaunchButton = new JButton(this.mTable.getLaunchAction());
    LaunchButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    LaunchButton.setHorizontalTextPosition(SwingConstants.CENTER);
    LaunchButton.setToolTipText("Afficher le dossier");
    mToolBar.add(LaunchButton);
    JButton AboutButton = new JButton(new AboutAction());
    AboutButton.setVerticalTextPosition(SwingConstants.BOTTOM);
    AboutButton.setHorizontalTextPosition(SwingConstants.CENTER);
    AboutButton.setToolTipText("� propos de Pimmms");
    mToolBar.add(AboutButton);
    mToolBar.add(mStatus);
    mStatus.setToolTipText("�tat de l'application");
    mStatus.setBorder(BorderFactory.createEtchedBorder());
    mStatus.setStringPainted(true);
    mToolBar.setFloatable(true);
  }


  /*
  * Lectures des param�tres.
  */
  private void readParameters() {
    try {mServerPort = Integer.parseInt(this.getParameter("MailPort", "-1"));} catch(Exception e) {BasicApplet.warn(e); }
    try {mServerAddress = this.getParameter("MailServer", "");} catch(Exception e) {BasicApplet.warn(e);}
    try {mServerProtocol = this.getParameter("MailProtocol", "pop3");} catch(Exception e) {BasicApplet.warn(e);}
    try {mSMIME = Boolean.valueOf(this.getParameter("S/MIME", "false")).booleanValue();} catch(Exception e) {BasicApplet.warn(e);  }
    try {mDeleteOnServer = Boolean.valueOf(this.getParameter("DeleteOnServer","false")).booleanValue();} catch(Exception e) {BasicApplet.warn(e);}
    try {mLanguage = this.getParameter("language", "French");} catch(Exception e) {BasicApplet.warn(e); }
    try {mMMFVersion = this.getParameter("MMF", "0.1");} catch(Exception e) {BasicApplet.warn(e);}
    boolean WarnForViruses = false;
    try {WarnForViruses = Boolean.valueOf(this.getParameter("WarnForViruses", "true")).booleanValue();} catch(Exception e) {BasicApplet.warn(e);}
    System.getProperties().put("WarnForViruses",WarnForViruses ? "true" : "false");
  }


  protected void showConfigDialog() {
      JPanel p = new JPanel(new GridLayout(0,1));
      JLabel Lb1 = new JLabel("Adresse du serveur : ");
      p.add(Lb1);

      JTextField tf1 = new JTextField();
      if(mServerAddress != null)
        tf1.setText(mServerAddress);
      p.add(tf1);

      JLabel Lb2 = new JLabel("port : ");
      p.add(Lb2);
      JTextField tf2= new JTextField(Integer.toString(mServerPort));
      p.add(tf2);

      JLabel Lb3 = new JLabel("protocole : ");
      p.add(Lb3);
      JTextField tf3 = new JTextField();
      if(mServerProtocol != null)
        tf3.setText(mServerProtocol);
      p.add(tf3);
      p.add(mCheckbox);
      JLabel Lb4 = new JLabel("<html><body><u><b>Configuration du proxy<b> (<i>SOCKS4</i>)</u></body></html>");
      p.add(Lb4);
      JLabel Lb5 = new JLabel("adresse du proxy : ");
      p.add(Lb5);
      JTextField tf5 = new JTextField();
      if(System.getProperty("http.proxyHost") != null)
        tf5.setText(System.getProperty("http.proxyHost"));
      p.add(tf5);

      JLabel Lb6 = new JLabel("port du proxy : ");
      p.add(Lb6);
      JTextField tf6 = new JTextField();
      if(System.getProperty("http.proxyPort") != null)
        tf6.setText(System.getProperty("http.proxyPort"));
      p.add(tf6);



      if(JOptionPane.showConfirmDialog(this,p,this.mNameOfApplication,
        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
          mServerAddress = tf1.getText();
          mServerPort = Integer.parseInt(tf2.getText());
          mServerProtocol = tf3.getText();
          if((tf5.getText() != null) && (tf6.getText() != null)) {
            System.setProperty("http.proxyHost",tf5.getText());
            System.setProperty("http.proxyPort",tf6.getText());
          }

      }

  }

  protected boolean showLoginDialog() {
      JPanel p = new JPanel(new GridLayout(0,1));


      JLabel Lb1 = new JLabel("Nom d'usager : ");
      p.add(Lb1);

      JTextField tf1 = new JTextField();
      tf1.setToolTipText("Votre nom d'usager sur le serveur de dossiers MMF.");
      if(mLogin != null)
        tf1.setText( mLogin);
      p.add(tf1);

      JLabel Lb2 = new JLabel("Mot de passe : ");
      p.add(Lb2);
      JPasswordField pf1 = new JPasswordField();
      pf1.setToolTipText("Le mot de passe du serveur de dossiers MMF.");
      if(mPassword != null)
        pf1.setText(mPassword);
      p.add(pf1);
      p.add(mCheckbox);
      if (JOptionPane.showConfirmDialog(this,p,this.mNameOfApplication,
       JOptionPane.OK_CANCEL_OPTION ,JOptionPane.QUESTION_MESSAGE) == JOptionPane.OK_OPTION) {
        mLogin = tf1.getText();
        mPassword = new String(pf1.getPassword());
        if((mLogin == null) || (mPassword == null))
          return(false);
        if((mLogin.length() == 0) || (mPassword.length() == 0))
          return(false);

        return(true);
      } else {
        return(false);
      }
  }



  protected static ImageIcon getIcon (String filename) {
     return(new ImageIcon(BasicApplet.class.getResource(filename)));;
   }

  /*
  * Classe d�finissant le bouton "recharger".
  */
  class RefreshAction extends AbstractAction {
    public RefreshAction() {
        super("recharger",BasicApplet.getIcon("/images/Refresh24.gif"));
    }

    public void actionPerformed(ActionEvent event) {
      // mettre ici les cons�quences de l'action
     // JOptionPane.showMessageDialog(BasicApplet.this, "Devrait v�rifier la pr�sence de nouveaux dossiers sur le serveur. Cette option n'est pas op�rationnelle.",BasicApplet.this.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
      BasicApplet.this.setStatus("Chargement des dossiers... Veuillez patienter...",10);
      RefreshAction.this.setEnabled(false);
      Thread loading = new Thread(new Runnable() {
        public void run() {
          try {
                         while(  mTable.load(getAuthentificator()) ) {
                               // BasicApplet.this.showLoginDialog();
                         }
          } catch(AccessControlException ace) {
            BasicApplet.warn(ace,"Il est impossible de charger les dossiers\nprobablement parce que l'applet n'en a pas la permission.\nVeuillez consulter le support technique.");
          } catch(Exception e) {
            e.printStackTrace();
          }
          BasicApplet.this.setStatus("Chargement des dossiers... Veuillez patienter...",90);
          mTable.sortColumn(mTable.getColumnCount() - 1);
          RefreshAction.this.setEnabled(true);
          BasicApplet.this.setStatus("",0);
        }
      });
      loading.setDaemon(true);
      loading.setPriority(Thread.MIN_PRIORITY);
      loading.start();
    }
  }

  /*
  * Classe d�finissant le bouton "recharger".
  */
  class AboutAction extends AbstractAction {
    public AboutAction() {
        super("� propos", BasicApplet.getIcon("/images/About24.gif"));
    }


    public void actionPerformed(ActionEvent event) {
      // mettre ici les cons�quences de l'action
      String message = "� propos du client r�cepteur M�dical Gate (Pimmms)\n"
        +mNameOfApplication+"\n"
        +"Cette application permet une consultation\nais�e des dossiers m�dicaux �lectroniques.\n"
        +"Nous utilisons les librairies logicielles\nHypersonic SQL et SkinLookAndFeel.";
      JOptionPane.showMessageDialog(BasicApplet.this,message,BasicApplet.mNameOfApplication,JOptionPane.OK_OPTION,BasicApplet.getIcon("/images/logo.jpg"));
    }
  }

  class SettingsAction extends AbstractAction {
    public SettingsAction() {
        super("config.", BasicApplet.getIcon("/images/Preferences24.gif"));
    }


    public void actionPerformed(ActionEvent event) {
      BasicApplet.this.showConfigDialog();
      // mettre ici les cons�quences de l'action
      //JOptionPane.showMessageDialog(BasicApplet.this, "Devrait permettre la configuration des param�tres de l'application. Cette option n'est pas op�rationnelle.",BasicApplet.this.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
    }
  }
/*
  class LookAndFeelAction extends AbstractAction {
    public LookAndFeelAction() {
      super("apparence",BasicApplet.getIcon("/images/Properties24.gif"));

    }

    public void actionPerformed(ActionEvent event) {
      JOptionPane.showMessageDialog(BasicApplet.this, "L'apparence de l'application sera modifi�e.");
      UIManager.LookAndFeelInfo[] lafs = UIManager.getInstalledLookAndFeels();
      boolean failed = false;
      for(int k = 0; k < lafs.length - 1; k++)
        if(UIManager.getLookAndFeel().getName().equals(lafs[k].getName()) || failed) {
            try{
              UIManager.setLookAndFeel(lafs[k + 1].getClassName());
              SwingUtilities.updateComponentTreeUI(BasicApplet.this);
              return;
            } catch(Exception ulafe) {
              failed = true;
            }
        }
      try{
        UIManager.setLookAndFeel(lafs[0].getClassName());
        SwingUtilities.updateComponentTreeUI(BasicApplet.this);
      } catch(Exception ulafe) {
      }
    }
  }
*/
  private static File[] getDirs(String dirs) {
    Vector v = new Vector();
    int pos = 0;
    while (pos < dirs.length()) {
      StringBuffer b = new StringBuffer();
      char c;
      while((c = dirs.charAt(pos))!=File.pathSeparatorChar) {
        b.append(c);
        pos++;
        if(pos == dirs.length())
          break;
      }
      v.add(new File(b.toString()));
    }
    File[] sarray = new File[v.size()];
    v.toArray(sarray);
    return(sarray);

  }
  public boolean loadAquaLookAndFeel() {
      try {
        File[] dirs = getDirs( System.getProperty("java.ext.dirs"));
        File themedir = dirs[0];
//        themedir.mkdirs();
        File aqua = new File(themedir,"aquathemepack.zip");
        System.out.println("On essaie d'ouvrir "+aqua.getCanonicalPath());
        Skin skin = SkinLookAndFeel.loadThemePack(aqua.getCanonicalPath());
        SkinLookAndFeel.setSkin(skin);
        SkinLookAndFeel slaf = new SkinLookAndFeel();
        UIManager.installLookAndFeel(slaf.getName(), "com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
        UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
        SwingUtilities.updateComponentTreeUI(BasicApplet.this);
        return true;
      } catch (Exception e) {
        e.printStackTrace();
      } catch (java.lang.NoClassDefFoundError ncdfe) {
        ncdfe.printStackTrace();
      } catch (java.lang.ExceptionInInitializerError eiie) {
        eiie.printStackTrace();
      }
      return false;
///      SwingUtilities.updateComponentTreeUI(BasicApplet.this);
  }

  public  BasicApplet.MedicalAuthentificator getAuthentificator() {
    return(new MedicalAuthentificator());
  }

  class MedicalAuthentificator extends javax.mail.Authenticator {
        protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
          return(new javax.mail.PasswordAuthentication(BasicApplet.this.mLogin,BasicApplet.this.mPassword));
        }
        public URLName getURLName() {
          final URLName urlname = new URLName(BasicApplet.this.mServerProtocol, BasicApplet.this.mServerAddress,
           BasicApplet.this.mServerPort, null,
            BasicApplet.this.mLogin, BasicApplet.this.mPassword);
          System.out.println(urlname.toString());
          return(urlname);
        }
  }

  /*
  * Lancement de l'applet
  */
  public void start() {
    System.out.println(BasicApplet.this.mLogin);
    if(mLoadingUp == null) {
    Runnable run = new Runnable() {
      public void run() {
        BasicApplet.this.loadLogin();
        if((BasicApplet.this.mLogin == null) || (BasicApplet.this.mPassword == null))
          while( ! BasicApplet.this.showLoginDialog() )
            JOptionPane.showMessageDialog(BasicApplet.this, "Vous devez entrer un nom d'usager et un mot de passe.",BasicApplet.this.mNameOfApplication,JOptionPane.WARNING_MESSAGE);

        while (BasicApplet.this.mServerAddress == null) {
          BasicApplet.this.showConfigDialog();
        }
        while (BasicApplet.this.mServerAddress.length() == 0) {
          BasicApplet.this.showConfigDialog();
        }
        /*
        * � partir de ce point, on pourrait afficher les dossiers sur
        * le disque.
        */
        if(BasicApplet.this.mRefreshAction.isEnabled())
          BasicApplet.this.mRefreshAction.actionPerformed(null);
        BasicApplet.this.mLoadingUp = null;
      }
    };
    mLoadingUp = new Thread(run);
    mLoadingUp.setPriority(Thread.MIN_PRIORITY);
    mLoadingUp.start();
    }
  }

  /*
  * Arr�t de l'applet.
  */
  public void stop() {
    System.out.println(BasicApplet.this.mLogin);
  }

  /*
  * Destruction de l'applet.
  */
  public void destroy() {
    saveLogin();
    mMMFDatabasePanel.dispose();
  }

  /*
  * Information sur l'applet.
  */
  public String getAppletInfo() {
    return "(c) 2000 Daniel Lemire";
  }

  /*
  * Information sur les param�tres de l'applet.
  */
  public String[][] getParameterInfo() {
    String[][] pinfo = {{"MailServer","String", "adresse (IP) du serveur de courrier"},
      {"MailPort","int","port du serveur de courrier (110)"},
      {"MailProtocol", "String", "protocole du serveur de courrier (POP, IMAP, etc.)"},
      {"S/MIME", "boolean", "est-ce que l'encryption S/MIME est permise"},
      {"language", "String", "langue de l usager"},
      {"MMF", "String", "version du protocole MMF"},
      {"DeleteOnServer", "boolean", "est-ce qu'on doit effacer les dossiers sur le serveur"},
      {"WarnForViruses", "boolean", "avertir l'usagers des dangers potentiels"}
      };
    return pinfo;
  }

  /*
  * M�thode main.
  */
  public static void main(String[] args) {
    final BasicApplet applet = new BasicApplet();
    applet.isStandalone = true;
    final JFrame frame = new JFrame();
    //EXIT_ON_CLOSE == 3
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        applet.destroy();
        frame.dispose();
        System.exit(0);
      }
    });
//    frame.setDefaultCloseOperation(3);
    frame.setTitle(BasicApplet.mNameOfApplication);
    frame.getContentPane().add(applet, BorderLayout.CENTER);
    applet.init();
    applet.start();
    frame.setSize(600,450);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
    frame.setVisible(true);
  }

  public static void warn (Exception e) {
    warn(e,"Une erreur inattendue est survenue.");
  }

  public static void warn (Exception e, String s) {
    StringWriter sos = new StringWriter();
    PrintWriter pw = new PrintWriter(sos);
    e.printStackTrace(pw);
    BufferedReader br = new BufferedReader(new StringReader(sos.toString()));
    StringBuffer sb = new StringBuffer();
    sb.append("<html><b>");
    sb.append(s);
    sb.append("</b>");
    String line = null;
    try {
      while ( ( line = br.readLine() ) != null) {
        sb.append("<br>");
        sb.append(line.trim());

      }
    } catch (IOException ioe) {}
    sb.append("</html>");
    JEditorPane pane = new JEditorPane();
    pane.setContentType("text/html");
    pane.setEditable(false);
    pane.setText(sb.toString());
      JScrollPane scrollpane = new JScrollPane(pane);
      scrollpane.setMinimumSize(new Dimension(384,200));
      scrollpane.setPreferredSize(scrollpane.getMinimumSize());

    JOptionPane.showMessageDialog(null,scrollpane ,BasicApplet.mNameOfApplication,JOptionPane.WARNING_MESSAGE);
  }

  public boolean deleteOnServer() {
    System.out.println("deleteOnServer = "+mDeleteOnServer);
    return(mDeleteOnServer);
  }

  public void saveLogin() {
    if(mLogin == null)
      return;
    File medicalGateDir = new File(System.getProperty("user.home"),"MedicalGate");
    File config = new File(medicalGateDir,"lastlogin.txt");
    Properties p = new Properties();
    p.put("login",mLogin);
    try {
      FileOutputStream fos = new FileOutputStream (config);
      try {
        p.store(fos,mNameOfApplication);
      } finally {
        fos.close();
      }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  public void loadLogin() {
    File medicalGateDir = new File(System.getProperty("user.home"),"MedicalGate");
    File config = new File(medicalGateDir,"lastlogin.txt");
    try {
    if(config.exists()) {
      Properties p = new Properties();
      FileInputStream fis = new FileInputStream(config);
      try {
        p.load(fis);
      } finally {
        fis.close();
      }
      if(p.get("login") != null)
        mLogin = (String) p.get("login");

    }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  public void setStatus(String s, int percent) {
    mStatus.setString(s);
    mStatus.setValue(percent);
    if((percent == 0) && (s.length()==0)) {
      mStatus.repaint();
    }
  }
}