package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.activation.CommandObject;
import javax.activation.DataHandler;

public class MMFImageViewer extends SaveAsPanel implements CommandObject, VistaPrintable {
    private ImageViewerCanvas canvas;
    private Image image;

    private boolean DEBUG = false;

    public MMFImageViewer() {
        super(new BorderLayout());
	canvas = new ImageViewerCanvas();
	add(canvas,BorderLayout.CENTER);

    }

    public JComponent getPrintingComponent() {
      JLabel label = new JLabel(new ImageIcon(image));
      label.setSize(label.getPreferredSize());
      return label;
    }

    public void setCommandContext(String string, DataHandler datahandler) throws IOException {
            System.out.println("MMFImageViewer!");
	dh = datahandler;
	setInputStream(dh.getInputStream());
    }

    private void setInputStream(InputStream inputstream) throws IOException {
	MediaTracker mediatracker = new MediaTracker(this);
	boolean bool = false;
	byte[] is = new byte[1024];
	ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
	int i;
	while ((i = inputstream.read(is)) > 0)
	    bytearrayoutputstream.write(is, 0, i);
	inputstream.close();
	image = getToolkit().createImage(bytearrayoutputstream.toByteArray());
	mediatracker.addImage(image, 0);
	try {
	    mediatracker.waitForID(0);
	    mediatracker.waitForAll();
	    if (mediatracker.statusID(0, true) != 8)
		System.out.println("Error occured in image loading = " + mediatracker.getErrorsID(0));
	} catch (InterruptedException interruptedexception) {
	    throw new IOException("Error reading image data");
	}
	canvas.setImage(image);
	if (DEBUG)
	    System.out.println("calling invalidate");
        setSavesAsPopup(canvas, dh.getName());
    }

  /*  public void addNotify() {

	super.addNotify();
	invalidate();
	validate();
	doLayout();
    }*/

    public Dimension getPreferredSize() {
	return canvas.getPreferredSize();
    }

    public void pack() {
      Container c = this.getParent();
      while (!(c instanceof Frame)) {
        c = c.getParent();
      }
      ((Frame) c).pack();

    }

class ImageViewerCanvas extends JComponent
{
    private Image canvas_image;
    protected int width = 200;
    protected int height = 200;

    public ImageViewerCanvas() {
    addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            if(e.getClickCount() == 2) {
              MMFImageViewer.this.pack();
            }
          }
     });

    }

    public void pack() {
      MMFImageViewer.this.pack();

    }

    public void setImage(Image image) {
	canvas_image = image;
        if(canvas_image != null) {
          width = canvas_image.getWidth(this);
          height = canvas_image.getHeight(this);
          this.setToolTipText("image "+width+" par "+height +" ("+(((int)((width * height * 3)/1024.0f)*10)/10) +" Ko)");
        } else {
          this.setToolTipText("Aucune image!");
        }
	invalidate();
	repaint();
    }

    public Dimension getPreferredSize() {
	Object object = null;
	Dimension dimension;
	if (canvas_image == null)
	    dimension = new Dimension(200, 200);
	else {
          int desiredwidth = canvas_image.getWidth(this) > 600 ? 600 : canvas_image.getWidth(this);
          int desiredheight = canvas_image.getHeight(this) > 400 ? 400 : canvas_image.getHeight(this);
          dimension = new Dimension(desiredwidth, desiredheight);
        }
	return dimension;
    }

    public void paint(Graphics graphics) {
	if (canvas_image != null)
	    graphics.drawImage(canvas_image, 0,0, getWidth(), getHeight(), this);
    }
}


  public String whoAmI() {
    return("MMFImageViewer");
  }


}