

package com.emedicalgate.client;


import java.awt.*;
import java.awt.event.*;
import javax.mail.*;
import javax.activation.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import com.emedicalgate.mmf.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.transform.*;
import org.xml.sax.*;
import java.io.*;
import com.emedicalgate.io.*;


public class MMFMessageViewer extends JPanel implements CommandObject {

    private MMFMessage	displayed = null;
    private String	verb = null;
    private Component	mainbody;
    private JLabel	headers;

    public MMFMessageViewer() {
	this(null);
    }

    public MMFMessageViewer(MMFMessage what) {
	// set our layout
	super(new GridBagLayout());



	GridBagConstraints gb = new GridBagConstraints();
	gb.gridwidth = GridBagConstraints.REMAINDER;
	gb.fill = GridBagConstraints.BOTH;
	gb.weightx = 1.0;
	gb.weighty = 0.0;

	// add the headers
	headers = new JLabel("");
//	headers.setEditable(false);
	add(headers, gb);

	// now display our message
	setMessage(what);
    }

    /**
     * sets the current message to be displayed in the viewer
     */
    public void setMessage(MMFMessage what) {
	displayed = what;

	if (mainbody != null)
	    remove(mainbody);

	if (what != null) {
	    loadHeaders();
	    mainbody = getBodyComponent();
	} else {
	    headers.setText("");
	    JTextArea dummy = new JTextArea("", 24, 80);
	    dummy.setEditable(false);
            dummy.setWrapStyleWord(true);
            dummy.setLineWrap(true);
	    mainbody = dummy;
	}

	// add the main body
	GridBagConstraints gb = new GridBagConstraints();
	gb.gridwidth = GridBagConstraints.REMAINDER;
	gb.fill = GridBagConstraints.BOTH;
	gb.weightx = 1.0;
	gb.weighty = 1.0;
	add(mainbody, gb);

//	invalidate();
//	validate();
    }

    public MMFMessage getMMFMessage() {return(displayed);}

   private static String makeStringHTMLSafe(String str) {
   	  StringBuffer s = new StringBuffer();
      char c;
      for(int pos = 0; pos < str.length(); ++pos) {
        switch ( c = str.charAt(pos)) {
          case '<' :
            s.append("&lt;");
            break;
          case '>' :
            s.append("&gt;");
            break;
          case '"' :
            s.append("&quot;");
            break;

          default :
            s.append(c);
            break;
        }
      }
	  return(s.toString());
   }


    protected void loadHeaders() {
	StringBuffer sb = new StringBuffer();
        sb.append("<HTML><BODY><B>Date</B>:&nbsp;");
	try {
            sb.append(makeStringHTMLSafe(MedicalTableRenderer.mDateFormat.format(displayed.getSentDate())));
	} catch (MessagingException me) {
            sb.append(me.toString());
        }
	sb.append("<BR>");
        sb.append("<B>M�decin</B>:&nbsp;");
        try {
	    sb.append(makeStringHTMLSafe(displayed.getDoctor()));
     	} catch (MessagingException me) {
                  sb.append(me.toString());
        }
        sb.append("<BR>");
        sb.append("<B>Sp�cialit�</B>:&nbsp;");
        try {
            sb.append(makeStringHTMLSafe(displayed.getSpeciality()));
       	} catch (MessagingException me) {
           sb.append(me.toString());
        }
	sb.append("<BR>");
        sb.append("<B>Pr�nom du patient</B>:&nbsp;");
        try {
            sb.append(makeStringHTMLSafe(displayed.getPatientFirstName()));
      	} catch (MessagingException me) {
            sb.append(me.toString());
        }
	sb.append("<BR>");
        sb.append("<B>Nom du patient</B>:&nbsp;");
        try {
            sb.append(makeStringHTMLSafe(displayed.getPatientLastName()));
      	} catch (MessagingException me) {
            sb.append(me.toString());
        }
	sb.append("<BR>");
        sb.append("<B>Date de naissance du patient</B>:&nbsp;");
        try {
            sb.append(makeStringHTMLSafe(MedicalTableRenderer.mDateFormat.format(displayed.getPatientBirthDate())));
      	} catch (Exception me) {
            sb.append(me.toString());
        }
	sb.append("<BR>");
        sb.append("<B>Suject</B>:&nbsp;");
        try {
	    sb.append(makeStringHTMLSafe(displayed.getSubject()));
     	} catch (MessagingException me) {
           sb.append(me.toString());
        }
        sb.append("</BODY></HTML>");
            //
        headers.setText(sb.toString());
        headers.setBorder(new BevelBorder(BevelBorder.RAISED));

    }

    protected Component getBodyComponent() {
      System.out.println("Getting body component...");
      if(displayed.getDocument() != null) {
        JTabbedPane pane = new JTabbedPane();
        pane.addTab("Contenu du dossier",BasicApplet.getIcon("/images/Open24.gif"),getMIMEBodyComponent(),"Acc�s � l'ensemble des documents du dossier MMF");
        try {
          pane.addTab("Descripteur MMF",BasicApplet.getIcon("/images/Information24.gif") ,new XMLTreePane(displayed.getDocument()),"Acc�s aux informations d�crivant ce dossier.");
        } catch (Exception e) {
          e.printStackTrace();
        }
        return pane;
      }
      System.out.println("No XML detected... ");
      return getMIMEBodyComponent();
    }

    protected Component getMIMEBodyComponent() {
	//------------
	// now get a content viewer for the main type...
	//------------
           try {
	    DataHandler dh = displayed.getDataHandler();
	    CommandInfo ci = dh.getCommand("view");

	    if (ci == null) {
		throw new MessagingException("view command failed on: " +
					     displayed.getContentType());
	    }
            Object bean = null;
            try {
              bean = ci.getCommandObject(dh,BasicApplet.class.getClassLoader());
              System.out.println("No fail-safe needed!");
            } catch(ClassNotFoundException cnfe) {
              cnfe.printStackTrace();
              System.out.println("Fail-safe, class not found!");
              MMFTextViewer mmfviewer= new MMFTextViewer();
              mmfviewer.setCommandContext("view", dh);
              bean = mmfviewer;
            } catch (Exception e) {
              e.printStackTrace();
              System.out.println("Fail-safe, critical error!");
              MMFTextViewer mmfviewer= new MMFTextViewer();
              mmfviewer.setCommandContext("view", dh);
              bean = mmfviewer;
            }
            if (bean instanceof Component) {
		return (Component)bean;
	    } else {
		throw new MessagingException("bean is not a component " +
					     bean.getClass().toString());
	    }
        } catch (IOException ioe) {
           ioe.printStackTrace();
       	    return new JLabel(ioe.toString());
	} catch (MessagingException me) {
	    return new JLabel(me.toString());
	}
    }

    /**
     * the CommandObject method to accept our dhr
     * @param dh	the dhr used to get the content
     */
    public void setCommandContext(String verb, DataHandler Dh) throws IOException {
        System.out.println("MMFMessageViewer!");
	this.verb = verb;
	Object o = Dh.getContent();
	if (o instanceof MMFMessage) {
	    setMessage((MMFMessage)o);
	}
	else {
	    System.out.println(
		"MessageViewer - content not a Message object, " + o);
	    if (o != null){
		System.out.println(o.getClass().toString());
	    }
	}
    }
  public String whoAmI() {
    return("MMFMessageViewer");
  }

// modeled after Java Tutorial's TreeDemo
}