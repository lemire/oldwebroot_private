package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */


import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.mail.*;
import javax.activation.*;
import java.beans.*;
import javax.swing.*;
import javax.swing.text.*;

public class MMFRTFViewer extends SaveAsPanel implements CommandObject, VistaPrintable  {
    String verb = null;

    JScrollPane scroller = null;
    JEditorPane editorPane = null;
    EditorKit editor = null;
    Document doc = null;


    public MMFRTFViewer() {
        editorPane = new JEditorPane();
        editorPane.setEditable(false);
        scroller = new JScrollPane();
        scroller.getViewport().add( editorPane );
        add( scroller );
        scroller.setPreferredSize( new Dimension( 300, 200 ) );
    }

    public JComponent getPrintingComponent() {
      return editorPane;
    }
    public void  setCommandContext( String verb, DataHandler Dh ) throws IOException {
      System.out.println("MMFRTFViewer!");
      verb = verb;
      dh = Dh;

      InputStream content = dh.getInputStream();
      setMessage( content );
      content.close();
    }


    public void  setMessage( InputStream content )  {
        editorPane.setContentType( dh.getContentType());
        editor = this.editorPane.getEditorKit();
        doc = this.editor.createDefaultDocument();
        try {
          editor.read( content, doc, 0 );

        } catch ( IOException ex ) {
          ex.printStackTrace( System.err );
        } catch ( BadLocationException ex ) {
          ex.printStackTrace( System.err );
        }
        editorPane.setDocument( doc );
        setSavesAsPopup(editorPane, dh.getName());
      }
  public String whoAmI() {
    return("MMFRTFViewer");
  }


}
