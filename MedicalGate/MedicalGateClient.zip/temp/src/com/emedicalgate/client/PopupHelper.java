package com.emedicalgate.client;


import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

 public class PopupHelper {
   static Dictionary d=new Hashtable();

   static MouseListener popupMouseListener = new java.awt.event.MouseAdapter() {
     void tryPopup(MouseEvent e) {
       if (!e.isPopupTrigger())
         return;
       Component c = e.getComponent();
       Object o[] = (Object []) d.get(c);
       if (o == null)
         return;
       JPopupMenu pm = (JPopupMenu) o[0];
       PopupListener l = (PopupListener) o[1];
       int x = e.getX(), y = e.getY();
       boolean go = true;
       if (l != null)
          go = l.startPopup(x, y);
        if (go)
          pm.show(c, x-20, y-10);
     }

     public void mousePressed(MouseEvent e) { tryPopup(e); }
     public void mouseReleased(MouseEvent e) { tryPopup(e); }
   };

   public static void setPopup(JComponent c, JPopupMenu pm, PopupListener l) {
     Object o[]={pm, l};
     d.put(c, o);
     c.addMouseListener(popupMouseListener);
   }

   public static void setPopup(JComponent c, JPopupMenu pm) {
     setPopup(c, pm, null);
   }

   public static void removePopup(JComponent c) {
     d.remove(c);
   }
}

interface PopupListener {
  /*
  * should you start the popup?
  * Also give you a chance to modify the JPopupMenu!!!
  */
  public boolean startPopup(int x, int y);
}
