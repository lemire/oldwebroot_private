package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.io.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.event.*;


public class MMFHTMLViewer extends SaveAsPanel implements CommandObject, VistaPrintable {
    String verb = null;

    JScrollPane scroller = null;
    JEditorPane editorPane = null;
    EditorKit editor = null;
    Document  doc = null;


  public MMFHTMLViewer() {
        setLayout( new BorderLayout() );
        scroller = new JScrollPane();
        scroller.setPreferredSize( new Dimension( 300, 400 ) );
        add( scroller );
  }

  public void  setCommandContext( String verb, DataHandler Dh ) throws IOException {
        System.out.println("MMFHTMLViewer!");
        verb = verb;
        dh = Dh;
        setMessage();
        System.out.println("MMFHTMLViewer ok!");
   }

   private void setMessage() throws IOException {
        System.out.println("Setting message for HTML content...");
        InputStream content2 = dh.getInputStream() ;
        scroller.getViewport().removeAll();
        File temphtml = File.createTempFile("Pimms",".html");
        temphtml.deleteOnExit();
        System.out.println("creating file "+temphtml.getAbsolutePath());
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(temphtml)));
        try {
          BufferedReader br = new BufferedReader(new InputStreamReader(content2));
          try {
            String line = null;
            while((line = br.readLine()) != null) {
              bw.write(line);
              bw.newLine();
            }
          } finally {
              br.close();
          }
        } finally {
          bw.close();
        }
        System.out.println("creating editorpane ");
        editorPane = new JEditorPane(temphtml.toURL());
        editorPane.setEditable(false);
        System.out.println("Adding listener ");
        editorPane.addHyperlinkListener(new Hyperactive());
        System.out.println("putting into scroller ");
        scroller.getViewport().add( editorPane );
       // invalidate();
       // validate();
        System.out.println("ok! ");
        setSavesAsPopup(editorPane, dh.getName());
    }


  public String whoAmI() {
    return("MMFTextViewer");
  }

  public JComponent getPrintingComponent() {
    if (editorPane == null)
      return new JEditorPane();
    return editorPane;
  }



     class Hyperactive implements HyperlinkListener {

         public void hyperlinkUpdate(HyperlinkEvent e) {
                  if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                      JEditorPane pane = (JEditorPane) e.getSource();
                      if (e instanceof HTMLFrameHyperlinkEvent) {
                          HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
                          HTMLDocument doc = (HTMLDocument)pane.getDocument();
                          doc.processHTMLFrameHyperlinkEvent(evt);
                      } else {
                          try {
                              pane.setPage(e.getURL());
                          } catch (Throwable t) {
                              t.printStackTrace();
                          }
                      }
                  }
              }
     }

}
