
package com.emedicalgate.client;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.text.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;

public class MedicalTableRenderer extends DefaultTableCellRenderer {

  private static Locale mCurrentLocale = new Locale("fr","FR","");
  public static DateFormat mDateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,mCurrentLocale);
  private Calendar mCalendar = Calendar.getInstance();
  private Date mCurrentDate;
  private int mCurrentYear;
  private int mCurrentDay;
  private javax.swing.Timer mTimer;
  public final static int ONE_SECOND = 1000;
  public final static int ONE_MINUTE = 60 * ONE_SECOND;
  public final static int ONE_HOUR = 60 * ONE_MINUTE;
  private Color mColor = new Color(255,255,204);

  public MedicalTableRenderer() {
    mCurrentDate = new Date();
    mCalendar.setTime(mCurrentDate);
    mCurrentDay = mCalendar.get(Calendar.DAY_OF_YEAR);
    mCurrentYear = mCalendar.get(Calendar.YEAR);
    mTimer = new javax.swing.Timer(ONE_HOUR, new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        mCurrentDate = new Date();
        mCalendar.setTime(mCurrentDate);
        mCurrentDay = mCalendar.get(Calendar.DAY_OF_YEAR);
        mCurrentYear = mCalendar.get(Calendar.YEAR);

      }
    });
  }



 public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    if((row / 2) * 2 == row) {
      setBackground(mColor);
    } else {
      setBackground(UIManager.getColor("Label.background"));
    }
    return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);;
 }

  public void setValue(Object value) {
    if(value instanceof Date) {
      Date date = (Date)value;
      if(date.getTime() == 0)
        super.setValue("");
      mCalendar.setTime(date);
      final int day = mCalendar.get(Calendar.DAY_OF_YEAR);
      final int year = mCalendar.get(Calendar.YEAR);

      if((day == mCurrentDay) && (year == mCurrentYear))
        super.setValue("<html><font color=blue>"+mDateFormat.format(date)+"</font></html>");
      else
        super.setValue(mDateFormat.format(date));
    } else {
      super.setValue(value);
    }
  }

}