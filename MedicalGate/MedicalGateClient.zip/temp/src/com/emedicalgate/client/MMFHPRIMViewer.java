package com.emedicalgate.client;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */


import java.awt.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;
import javax.swing.*;
import com.emedicalgate.io.*;
import com.emedicalgate.hprim.*;
import java.util.*;

public class MMFHPRIMViewer extends SaveAsPanel implements CommandObject, VistaPrintable {
  private String verb = null;
  private HPRIMFile mHPRIMFile;
  private JLabel mHeaderLabel = new JLabel();
  private JPanel mPanel = new JPanel();
  private JTextArea mPrintingComponent = null;

  public MMFHPRIMViewer() {
    mHPRIMFile = new HPRIMFile(DefaultHPRIMPasswordProvider.getInstance());
    setLayout(new BorderLayout());
    add(mHeaderLabel,BorderLayout.NORTH);
    mPanel.setPreferredSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
    add(mPanel,BorderLayout.CENTER);

  }




  public String whoAmI() {
    return("MMFHPRIMViewer");
  }

  public void setCommandContext(String verb, DataHandler Dh) throws IOException {
	this.verb = verb;
	this.dh = Dh;
        InputStream is = dh.getInputStream();
	try {
          this.setInputStream( new BufferedInputStream( is ));
        } finally {
          is.close();
        }
  }

  public JComponent getPrintingComponent() {
    if(mPrintingComponent != null)
      return mPrintingComponent;
    StringBuffer sbprint = new StringBuffer("Dossier HPRIM\n");
    sbprint.append(mHPRIMFile.getTextHeader());
    Vector v = mHPRIMFile.getDossiers();
    Enumeration enum = v.elements();
    while (enum.hasMoreElements()) {
            DossierHPRIM dossier = (DossierHPRIM)enum.nextElement();
            sbprint.append("DOSSIER\n");
            sbprint.append("Identification du patient\n");
            sbprint.append(dossier.getZoneDIndentificationDuPatient().getText());
            sbprint.append("Compte-Rendu\n");
            sbprint.append(dossier.getCompteRendu());
            if(dossier.getResultatCodifie() != null) {
              sbprint.append("R�sultats codifi�s\n");
              sbprint.append(dossier.getResultatCodifie().getText());
            }
    }
    mPrintingComponent = new JTextArea();
    mPrintingComponent.setText(sbprint.toString());
    mPrintingComponent.setSize(mPrintingComponent.getPreferredSize());
    return mPrintingComponent;
  }

  public void setInputStream (InputStream is) throws IOException {
    mPrintingComponent = null;
    mHPRIMFile.read(is);


    mHeaderLabel.setText("<html>"+mHPRIMFile.getHMTLHeader()+"</html>");
    mPanel.removeAll();
    mPanel.setLayout(new GridLayout(1,0,0,0));
    Vector v = mHPRIMFile.getDossiers();
    if(v.size() > 1) {
          JTabbedPane pane = new JTabbedPane();
          Enumeration enum = v.elements();
          int k = 0;
          while (enum.hasMoreElements()) {
            DossierHPRIM dossier = (DossierHPRIM)enum.nextElement();
            pane.add(Integer.toString(++k),new DossierHPRIMComponent(dossier));
            //
          }
          mPanel.add(pane);
    } else {
          mPanel.add(new DossierHPRIMComponent((DossierHPRIM)v.elementAt(0)));
    }
    if(dh != null) {
        setSavesAsPopup(mHeaderLabel, dh.getName()+".dec");
    } else {
        setSavesAsPopup(mHeaderLabel, "resutext.dec");
    }
  }

}



class DossierHPRIMComponent extends JPanel {
  ZoneIDComponent mZoneIDComponent;
  JTextArea mTextArea = new JTextArea();
  ResultatsCodifiesComponent mResultatsCodifiesComponent;

  public DossierHPRIMComponent(DossierHPRIM dossier) {
    super(new GridLayout(0,1,0,0));
    mZoneIDComponent = new ZoneIDComponent(dossier.getZoneDIndentificationDuPatient());
    mTextArea.setText(dossier.getCompteRendu());
    if(dossier.getResultatCodifie() != null)
      mResultatsCodifiesComponent = new ResultatsCodifiesComponent(dossier.getResultatCodifie());
    setupComponents();
  }

  private void setupComponents() {
    JTabbedPane pane = new JTabbedPane();
    pane.add("identification",new JScrollPane(mZoneIDComponent));
    pane.add("compte-rendu",new JScrollPane(mTextArea));
    pane.setSelectedIndex(1);
    if( mResultatsCodifiesComponent != null ) {
      pane.add("r�sultats codifi�s",new JScrollPane(mResultatsCodifiesComponent));
      pane.setSelectedIndex(2);
    }
    add(pane);

  }
}

class ZoneIDComponent extends JEditorPane {
  public ZoneIDComponent(ZoneDIndentificationDuPatient zone) {
    super("text/html","<html>"+zone.getHTML()+"</html>");
    setEditable(false);
  }
}

class ResultatsCodifiesComponent extends JEditorPane {
  public ResultatsCodifiesComponent(ResultatsCodifies result) {
    super("text/html","<html>"+result.getHTML()+"</html>");
    setEditable(false);
  }
}