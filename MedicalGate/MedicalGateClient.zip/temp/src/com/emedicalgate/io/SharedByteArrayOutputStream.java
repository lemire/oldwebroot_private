package com.emedicalgate.io;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.io.*;

public class SharedByteArrayOutputStream extends ByteArrayOutputStream {
    public SharedByteArrayOutputStream() {
	super();
    }
    public SharedByteArrayOutputStream(int size) {
	super(size);
    }

    public InputStream toStream() {
	return new ByteArrayInputStream(buf, 0, count);
    }
}