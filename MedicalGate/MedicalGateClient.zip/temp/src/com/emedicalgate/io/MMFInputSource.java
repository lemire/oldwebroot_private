package com.emedicalgate.io;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import java.io.*;
import org.xml.sax.*;
import java.net.*;

public class MMFInputSource extends InputSource {
    public MMFInputSource(InputStream is) {
          super();
          String contentstring = null;
          try { BufferedReader bis = new BufferedReader(new InputStreamReader(is));
            StringWriter sw = new StringWriter();
            PrintWriter pw = new  PrintWriter(sw);
            String line = null;
            while((line = bis.readLine()) != null) {
              pw.println(line);
            }
            contentstring = sw.toString();
          } catch (IOException ioe) {
            ioe.printStackTrace();
            return;
          }
          try {
            setByteStream(new ByteArrayInputStream(contentstring.getBytes("UTF-8"))) ;
            setEncoding("UTF-8");
          } catch (UnsupportedEncodingException uee) {
            setByteStream(new ByteArrayInputStream(contentstring.getBytes())) ;
          }
          setSystemId(getXMLSystemID());
    }

    public static String getXMLSystemID() {
          URL systemid = MMFInputSource.class.getResource("/MMF.DTD");
          if(systemid != null)
            return(systemid.toExternalForm());
          else
            return ("/MMF.DTD");

    }


  }