package com.emedicalgate.mmf;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import javax.mail.*;

public interface MMFMessageProvider {

  public int getMessageCount()  throws javax.mail.MessagingException;
  public MMFDescriptor getMMFDescriptor(int i)  throws javax.mail.MessagingException;
  public Message getMessage(int i)  throws javax.mail.MessagingException;
  public Message getMessage(MMFDescriptor mmfdesc)  throws javax.mail.MessagingException;
}