
package com.emedicalgate.mmf;

import javax.mail.*;
import javax.mail.internet.*;
import java.text.*;
import java.util.*;
import java.io.*;
import javax.activation.*;
import java.io.File;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import javax.swing.*;
import java.net.*;
import com.emedicalgate.io.*;
import com.emedicalgate.hprim.*;
/*
* Encapsulation de la norme MMF
* en Java.
*/
public class MMFMessage extends MimeMessage  implements MMF  {


  protected static Locale mCurrentLocale = new Locale("fr","FR","");
  protected static DateFormat mDateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,mCurrentLocale);
  protected static SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ("dd/MM/yyyy");
  private Document mDocument;
  private BodyPart mXMLBodyPart, mHPRIMBodyPart;
  String mPatientFirstName = "-";
  String mPatientLastName = "--";
  String mDoctor = "---";
  //String mDateString = "";
  String mSpeciality ="aucune";
  String mSubject = "biologie";
  private static Date mBadDate = new Date(0);
  Date mDate = mBadDate;
  Date mPatientBirthDate = mBadDate;
  HPRIMPasswordProvider mPasswordProvider;
  List mMMFList;


  public MMFMessage(MimeMessage m, HPRIMPasswordProvider PasswordProvider) throws MessagingException {
    super(m);
    mPasswordProvider = PasswordProvider;
    try {
      findDescriptor();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    if (mPatientBirthDate == null)
      throw new NullPointerException("La date de naissance ne devrait pas �tre nulle!");

  }

  public MMFMessage(Folder folder, InputStream is, int msgnumber, MMFDescriptor descriptor) throws MessagingException {
    super(folder,is,msgnumber);
    try {
      findDescriptor();
    } catch (Exception ioe) {
      ioe.printStackTrace();
      readDescriptor(descriptor);
    }
    if (mPatientBirthDate == null)
      throw new NullPointerException("La date de naissance ne devrait pas �tre nulle!");
  }

  public String getDoctor() throws MessagingException {
    if(mDoctor == null) {
        try {
	  Address[] adds = super.getFrom();
	  if (adds != null && adds.length != 0) {
	    return(adds[0].toString());
	  } else {
	    return("<inconnu>");
	  }
        } catch (Exception e) {
          e.printStackTrace();
          return("<inconnu>");
        }
    }
    if(mDoctor.length() == 0) {
        try {
	  Address[] adds = super.getFrom();
	  if (adds != null && adds.length != 0) {
	    return(adds[0].toString());
	  } else {
	    return("<inconnu>");
	  }
        } catch (Exception e) {
          e.printStackTrace();
          return("<inconnu>");
        }

      }
      return(mDoctor);
  }

  public String getSpeciality() throws MessagingException {
    if(mSpeciality != null)
      return(mSpeciality);
    else
      return("non disponible");
  }

  public String getPatientFirstName()  throws MessagingException{
    return mPatientFirstName;
  }

  public String getPatientLastName()  throws MessagingException{
    return mPatientLastName;
  }

  public String getSubject() throws MessagingException {
      if(mSubject == null) {
	// Subject
	String subject = super.getSubject();
	if (subject != null) {
	    return(subject);
	} else {
	    return("<pas de sujet>");
	}
      }
      if(mSubject.length() == 0) {
	// Subject
	String subject = super.getSubject();
	if (subject != null) {
	    return(subject);
	} else {
	    return("<pas de sujet>");
	}
      }
      return(mSubject);
  }
/*  public String getSentDateString() throws MessagingException {
    if(mDateString == null) {
      if(super.getSentDate() == null)
        return (mDateString ="");
      return(mDateString = mDateFormat.format(super.getSentDate()));
    }
    if(mDateString.length() == 0) {
      if(super.getSentDate() == null)
        return (mDateString="");
       return(mDateString=mDateFormat.format(super.getSentDate()));
    }
    return(mDateString);
  }*/


  public Date getSentDate() throws javax.mail.MessagingException {
    return mDate;
  }
  public java.util.Date getPatientBirthDate() {
    return mPatientBirthDate;
  }

  private boolean isXML(BodyPart bp) throws MessagingException, IOException  {
    if( bp.getContentType()!= null ) {
      try {
        MimeType mime = new MimeType( bp.getContentType() );
        if(mime.match("text/xml") || mime.match("text/xmmf"))
          return(true);
      } catch (MimeTypeParseException mtpe) {
        mtpe.printStackTrace();
      }

    }
    if(bp.getFileName() != null) {
        if(bp.getFileName().toLowerCase().endsWith("xml"))
          return true;
    }
    return false;
  }
  private boolean isHPRIM(BodyPart bp) throws MessagingException, IOException  {
    if( bp.getContentType()!= null ) {
      try {
        MimeType mime = new MimeType( bp.getContentType() );
        if(mime.match("application/x-hprim"))
          return(true);
      } catch (MimeTypeParseException mtpe) {
        mtpe.printStackTrace();
      }

    }
    if(bp.getFileName() != null) {
        if(bp.getFileName().toLowerCase().startsWith("resutext"))
          return true;
    }
    return false;
  }

  private void findDescriptor() throws MessagingException, IOException {
    DataHandler dh = this.getDataHandler();
    Object content = dh.getContent();
    if (content instanceof Multipart) {
      Multipart mp = (Multipart) content;
      int count = 1;
      try {
          count = mp.getCount();
      } catch (MessagingException me) {
        System.out.println("Le message est mal formatt�, incapable de compter le nombre de documents attach�s!");
        System.out.println("Est-ce que le message se terminait bien par une ligne vide???");
        me.printStackTrace();
        System.out.println("Nous allons continuer en supposant qu'il n'y a qu'un document!");
      }
      for (int k = 0; k < count; ++k) {
        try {
          if(isXML(mp.getBodyPart(k))) {
            System.out.println("J'ai trouv� un fichier XML!");
            mXMLBodyPart =  mp.getBodyPart(k);
            readXMLDescriptor(mXMLBodyPart.getInputStream());
            System.out.println("Le descripteur est lu!");
            if(getDocument() == null) {
              System.out.println("Quelque chose ne va pas!!! Pas de XML???");
            }
            return;
           }
         } catch (MessagingException me) {
          me.printStackTrace();
         }
      }
      // on cherche maintenant du HPRIM!
      for (int k = 0; k < count; ++k) {
        try {
          if(isHPRIM(mp.getBodyPart(k))) {
            System.out.println("J'ai trouv� un fichier HPRIM et je l'utilise comme descripteur!");
            mHPRIMBodyPart =  mp.getBodyPart(k);
            readHPRIMDescriptor(mHPRIMBodyPart.getInputStream());
            System.out.println("J'ai trouv� un fichier HPRIM et je l'ai utilis� comme descripteur!");
            return;
           }
         } catch (MessagingException me) {
          me.printStackTrace();
         }
      }
    }
  }

  private void readDescriptor(MMF hprimfile) {
      System.out.println("Found a MMF descriptor!");
      try {
        System.out.println("Found a MMF descriptor! getting patient fist name...");
        mPatientFirstName = hprimfile.getPatientFirstName();
        System.out.println("Found a MMF descriptor! getting patient fist name...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting patient last name...");
        mPatientLastName = hprimfile.getPatientLastName();
        System.out.println("Found a MMF descriptor! getting patient last name...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting patient doctor...");
        mDoctor = hprimfile.getDoctor();
        System.out.println("Found a MMF descriptor! getting patient doctor...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting speciality...");
        mSpeciality =hprimfile.getSpeciality();
        System.out.println("Found a MMF descriptor! getting speciality...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting subject...");
        mSubject = hprimfile.getSubject();
        System.out.println("Found a MMF descriptor! getting subject...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting date...");
        mDate = hprimfile.getSentDate();
        System.out.println("Found a MMF descriptor! getting date...ok");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      try {
        System.out.println("Found a MMF descriptor! getting birth date...");
        mPatientBirthDate = hprimfile.getPatientBirthDate();
        System.out.println("Found a MMF descriptor! getting birth date...ok");
        if (mPatientBirthDate == null)
          throw new NullPointerException("La date de naissance ne devrait pas �tre nulle!");
      } catch (javax.mail.MessagingException me) {
        me.printStackTrace();
      }
      System.out.println("Found a MMF descriptor! ok");
  }

  private void readHPRIMDescriptor(InputStream is) throws MessagingException {
    HPRIMFile hprimfile = new HPRIMFile(mPasswordProvider);
    try {
      System.out.println("Reading HPRIM...");
      hprimfile.read(is);
      System.out.println("Reading HPRIM...ok, getting MMF descriptors...");
      mMMFList  = hprimfile.getMMFDescriptors();
      System.out.println("getting MMF descriptors...ok");
      if(mMMFList.size() == 0)
        throw new MessagingException("Aucun dossier dans le fichier HPRIM!");
      System.out.println("reading descriptor0...");
      readDescriptor((MMF)mMMFList.get(0));
      System.out.println("reading descriptor0...ok");
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  public MMF[] getMMFDescriptors() {
    System.out.println("Requesting descriptors...");
    MMF[] ans = new MMF[1];
    if(mMMFList == null) {
      ans[0] = this;
      return ans;
    }
    return (MMF[]) mMMFList.toArray(ans);
  }

  /*
  * On devrait pouvoir lire un MMFDescriptor � partir d'un descripteur
  * en XML... � faire!
  */
  private void readXMLDescriptor(InputStream is) {
            System.out.println("Reading descriptor!");
            MMFErrorHandler errorhandler = new MMFErrorHandler();
  	    DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setValidating(true);
            docBuilderFactory.setIgnoringComments(true);
            docBuilderFactory.setIgnoreElementContentWhitespace(true);
            try {
	      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
              docBuilder.setErrorHandler(errorhandler);
              System.out.println("parsing!");
	      mDocument = docBuilder.parse (new  MMFInputSource( is) );
              mDocument.normalize();
              try {
                Element EnteteNode = (Element) mDocument.getElementsByTagName("ENTETE").item(0);
                try {
                  mSubject = EnteteNode.getElementsByTagName("ObjetDossier").item(0).getFirstChild().getNodeValue();
                  System.out.println(mSubject);
                } catch(NullPointerException e) {
                  mSubject = "aucun objet sp�cifi�";
                  //e.printStackTrace();
                }
                try {
                  mDate = mDateFormat.parse(EnteteNode.getElementsByTagName("DateDossier").item(0).getFirstChild().getNodeValue());
                } catch(NullPointerException e) {
                  mDate = new Date();
                  e.printStackTrace();
                } catch (java.text.ParseException pe) {
                  pe.printStackTrace();
                  mDate = new Date();
                }
              } catch (Exception e) {
                e.printStackTrace();
              }
              try {
                Element  ExpediteurNode = (Element) mDocument.getElementsByTagName("MEDECINEXPEDITEUR").item(0);
                StringBuffer sb = new StringBuffer();
                try {
                  sb.append(ExpediteurNode.getElementsByTagName("TitreMedLoc").item(0).getFirstChild().getNodeValue());
                  sb.append(" ");
                } catch (NullPointerException e) {e.printStackTrace();}
                try {
                  sb.append(ExpediteurNode.getElementsByTagName("PrenomMedLoc").item(0).getFirstChild().getNodeValue());
                  sb.append(" ");
                  sb.append(ExpediteurNode.getElementsByTagName("NomMedLoc").item(0).getFirstChild().getNodeValue());
                  mDoctor = sb.toString();
                  System.out.println(mDoctor);
                } catch (NullPointerException e) {e.printStackTrace();}
                mSpeciality = ExpediteurNode.getElementsByTagName("SpecialiteMedLoc").item(0).getFirstChild().getNodeValue();
              } catch (Exception e) {
                e.printStackTrace();
              }
              try {
                Element  PatientNode = (Element) mDocument.getElementsByTagName("PATIENT").item(0);
                /*StringBuffer sb = new StringBuffer();
                try {
                  sb.append( PatientNode.getElementsByTagName("TitrePatient").item(0).getFirstChild().getNodeValue());
                  sb.append(" ");
                } catch (NullPointerException e) {
                  e.printStackTrace();
                }*/
                try {
                  mPatientFirstName = PatientNode.getElementsByTagName("PrenomPatient").item(0).getFirstChild().getNodeValue();
                } catch (NullPointerException e) {
                  e.printStackTrace();
                }
                try {
                  mPatientLastName = PatientNode.getElementsByTagName("NomPatient").item(0).getFirstChild().getNodeValue();
                } catch (NullPointerException e) {
                  e.printStackTrace();
                }
                try {
                  mPatientBirthDate = mSimpleDateFormat.parse(PatientNode.getElementsByTagName("DatenaissPatient").item(0).getFirstChild().getNodeValue());
                } catch (NullPointerException e) {
                  e.printStackTrace();
                  mPatientBirthDate = new Date();
                } catch (java.text.ParseException pe) {
                  pe.printStackTrace();
                  try {
                    mPatientBirthDate = mDateFormat.parse(PatientNode.getElementsByTagName("DatenaissPatient").item(0).getFirstChild().getNodeValue());
                  } catch (Exception e) {
                    mPatientBirthDate = new Date();
                  }

                }
              } catch (Exception e) {
                e.printStackTrace();
              }
/*
              DocumentType dt = doc.getDoctype();
              System.out.println("Document type: "+dt.getName());

              System.out.println("root element!");
              Element root = doc.getDocumentElement();
              System.out.println("root element : "+root.getTagName());*/
            } catch (ParserConfigurationException pce) {
              pce.printStackTrace();
            } catch (SAXException saxe) {
              saxe.printStackTrace();
            } catch (IOException ioe) {
              ioe.printStackTrace();
            }
            errorhandler.display();
      if (mPatientBirthDate == null)
        throw new NullPointerException("La date de naissance ne devrait pas �tre nulle!");
  }

  class MMFErrorHandler implements ErrorHandler {
    StringBuffer sb = new StringBuffer();
    int mNumberOfErrors = 0;
    int mNumberOfFatalErrors = 0;
    int mNumberOfWarnings = 0;
    public void display() {

      if ((mNumberOfErrors == 0) && (mNumberOfFatalErrors == 0) && (mNumberOfWarnings == 0))
        return;
      StringBuffer header = new StringBuffer();
      final int errors = mNumberOfErrors + mNumberOfFatalErrors + mNumberOfWarnings;
      header.append("Il y a ");
      header.append(errors);
      header.append(" probl�me");
      if(errors > 1)
        header.append('s');
      header.append(" dans le descripteur XML.");
      header.append(Character.LINE_SEPARATOR);
      sb.insert(0,header.toString());
      JOptionPane.showMessageDialog(null,new JScrollPane(new JTextArea(sb.toString())),"XML",JOptionPane.ERROR_MESSAGE);
    }

    public void error(SAXParseException exception) {
      sb.append("Erreur non critique: ");
      print(exception);
    }
    public void  fatalError(SAXParseException exception) {
      sb.append("Erreur critique: ");
      print(exception);
    }

    public void warning(SAXParseException exception) {
      sb.append("Avertissement: ");
      print(exception);

    }
    private void print(SAXParseException exception) {
      sb.append(exception.toString());
      sb.append(" ( ligne ");
      sb.append(exception.getLineNumber());
      sb.append(", colonne ");
      sb.append(exception.getColumnNumber());
      sb.append(")");
      sb.append(Character.LINE_SEPARATOR);
    }
  }

  public static DateFormat getDateFormat() {
    return mDateFormat;
  }

  public Document getDocument() {
    return(mDocument);
  }
  public InputStream getXMLInputStream() throws IOException, MessagingException {

    return((new  MMFInputSource(  mXMLBodyPart.getInputStream() )).getByteStream());
  }

}