package com.emedicalgate.mmf;

import java.io.*;
import java.lang.ref.*;
import java.util.*;
import javax.mail.*;
import com.emedicalgate.io.*;
import com.emedicalgate.hprim.*;

class FolderIndexFile implements VersionManagement, DescriptorListener, Status  {

  int mMajorVersionNumber, mMinorVersionNumber;
  final static int mHeaderSize = 8;
  int mNumberOfDescriptors;
  File mIndexFile;
  File mDataFile;
  SoftReference mDescriptorArrayReference = new SoftReference(new Vector());
  MMFLocalFolder mOwner;
  public static final byte[] mEndOfMessage = {10,46,13,0};

  public FolderIndexFile(MMFLocalFolder owner, File indexfile, File datafile) throws IOException {
    mOwner = owner;
    mIndexFile = indexfile;
    mIndexFile.createNewFile();
    mDataFile = datafile;
    mDataFile.createNewFile();
    DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(mIndexFile)));
    try {
      if(dis.available() != 0) {
        mMajorVersionNumber = dis.readInt();
        System.out.println("Major version = "+mMajorVersionNumber);
        mMinorVersionNumber = dis.readInt();
        System.out.println("Minor version = "+mMinorVersionNumber);
        System.out.println("MMFLibraryMajorVersion = "+MMFLibraryMajorVersion);
        mNumberOfDescriptors = dis.available()/MMFDescriptor.getSizeOfDescriptor();
        dis.close();
        if(mMajorVersionNumber < MMFLibraryMajorVersion) {
          System.out.println("On remet � z�ro le fichier d'index.");
          DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(mIndexFile)));
          try {
            dos.writeInt(MMFLibraryMajorVersion);
            dos.writeInt(MMFLibraryMinorVersion);
          } finally {
            dos.close();
          }
          mNumberOfDescriptors = 0;
        }
      } else {
        DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(mIndexFile)));
        try {
          dos.writeInt(MMFLibraryMajorVersion);
          dos.writeInt(MMFLibraryMinorVersion);
        } finally {
          dos.close();
        }
        mNumberOfDescriptors = 0;
      }
    } finally {
      dis.close();
    }
  }

  public int getNumberOfDescriptors() {
    return mNumberOfDescriptors;
  }

  public MMFDescriptor getDescriptor(int i)  throws IOException {
        Object o = null;
        if(( o = mDescriptorArrayReference.get()) == null) {
          o = new Vector();
          mDescriptorArrayReference = new SoftReference(o);
        }
        Vector descriptors = (Vector) o;
        descriptors.setSize(mNumberOfDescriptors);
        Object od = null;
        if ((od = descriptors.get(i)) == null) {
          od = getDescriptorFromDisk(i);
          descriptors.setElementAt(od,i);
        }
        return((MMFDescriptor) od);
  }

  private MMFDescriptor getDescriptorFromDisk(int i) throws IOException {
    MMFDescriptor descriptor = null;
    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(mIndexFile));
    try {
      bis.skip(getMMFDescriptorIndex(i));
      descriptor = new MMFDescriptor(bis, i);
      descriptor.addDescriptorListener(this);
    } finally {
      bis.close();
    }
    return descriptor;
  }

  private int getMMFDescriptorIndex(int i) {
    return(i * MMFDescriptor.getSizeOfDescriptor() + mHeaderSize);
  }

  public void statusHasChanged(MMFDescriptor descriptor) {
    int pos = getMMFDescriptorIndex(descriptor.getIndex());
    try {
      RandomAccessFile raf = new RandomAccessFile(mIndexFile,"rw");
      try {
        raf.seek(pos);
        raf.writeByte(descriptor.getStatus());
      } finally {
        raf.close();
      }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

  public MMFMessage getMMFMessage(MMFDescriptor descriptor) {
    final long pos = descriptor.getPositionInDataFile();
    final int index = descriptor.getIndex();
    MMFMessage message = null;
    try {
      BufferedInputStream bis = new BufferedInputStream(new FileInputStream(mDataFile));
      try {
        System.out.println("available:"+bis.available());
        System.out.println("Skipping : "+pos);
        bis.skip(pos);
        message = new MMFMessage(mOwner,getMIMEMessageInputStream(bis, descriptor.getSize()),index,descriptor);
      } catch (Exception ioe) {
        ioe.printStackTrace();
      } finally {
        bis.close();
      }
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    descriptor.setSeen(true);
    return(message);
  }

  protected static InputStream getMIMEMessageInputStream(InputStream input, int size) throws IOException {
  	SharedByteArrayOutputStream sharedbytearrayoutputstream = new SharedByteArrayOutputStream(size);
	int old = 10;
	int current;
	while ((current = input.read()) >= 0) {
	    if (old == 10 && current == 46) {
		current = input.read();
		if (current == 13) {
		    input.read();
		    break;
		}
	    }
	    sharedbytearrayoutputstream.write(current);
	    old = current;
	}
	if (current < 0)
	    throw new EOFException("EOF");
	return(sharedbytearrayoutputstream.toStream());
  }

  /*
  * return the (new) index of the message added)
  */
  public int[] appendMessage(MMFMessage m) throws IOException, MessagingException {
      int[] indices;
      synchronized (this) {
        final boolean append = true;
        // on d�termine la taille du fichier d'archive
        RandomAccessFile raf = new RandomAccessFile(mDataFile,"r");
        long pos = 0;
        try {
          pos = raf.length();
        } finally {
          raf.close();
        }
        // on �crit notre nouveau message, � la fin du fichier d'archives
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(mDataFile.getAbsolutePath(),append));
        try {
          m.writeTo(bos);
          bos.write(mEndOfMessage);
        } finally {
          bos.close();
        }
        //
        MMF[] mmfs = m.getMMFDescriptors();
        indices = new int[mmfs.length];
        for(int k = 0; k < indices.length; ++k) {
          indices[k] = k + mNumberOfDescriptors;
        }
        Object o = null;
        if((o = mDescriptorArrayReference.get()) == null) {
          o = new Vector();
          mDescriptorArrayReference = new SoftReference(o);
        }
        Vector descriptors = (Vector) o;
        BufferedOutputStream bosdesc = new BufferedOutputStream(new FileOutputStream(mIndexFile.getAbsolutePath(),append));
        try {
          descriptors.setSize(mNumberOfDescriptors + mmfs.length);
          for(int k = 0; k < mmfs.length; ++k) {
            MMFDescriptor descriptor = new MMFDescriptor(mmfs[k], RECENT, pos);
            descriptors.setElementAt(descriptor,mNumberOfDescriptors);
            mNumberOfDescriptors ++;
            descriptor.save(bosdesc);
          }
        } catch (java.lang.OutOfMemoryError err) {
          err.printStackTrace();
          System.out.print("Une nouvelle impl�mentation de la m�moire cache est requise");
          System.out.print("ou alors vous devez revoir les param�tres de la JVM.");
          mDescriptorArrayReference.clear();
        } finally {
          bosdesc.close();
        }
        //
      }
      return (indices);
  }

  protected void setDirectory(File directory) {
      mIndexFile = new File(directory,"mmf.idx");
      mDataFile = new File(directory,"mmf.ctt");
  }

}
