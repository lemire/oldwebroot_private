
package com.emedicalgate.mmf;

public interface DescriptorListener {
  public void statusHasChanged(MMFDescriptor mmfdescrip);

  public MMFMessage getMMFMessage(MMFDescriptor mmfdescrip);
}