
package com.emedicalgate.mmf;


import java.io.*;
import javax.mail.*;
import java.util.*;
import java.text.*;
/*
* Ceci est une alternative l�g�re pour les objets Message. �a
* permet aussi l'�criture sans probl�me d'un fichier compact
* comprenant juste l'info n�cessaire.
*/
public class MMFDescriptor implements MMF, Status, Serializable, Comparable {

  private String mDoctor, mSpeciality, mPatientFirstName, mPatientLastName, mSubject;
  private Date mSentDate, mPatientBirthDate;

  private final static int mDoctorLength = 32;
  private final static int mSpecialityLength = 32;
  private final static int mPatientFirstNameLength = 32;
  private final static int mPatientLastNameLength = 32;
  private final static int mSubjectLength = 80;
//  private final static int mSentDateStringLength = 32;

  private byte mStatus;
  private volatile long mPos;// data pos
  private int mSize;
  private int mIndex;//index file index
  private DescriptorListener mDescriptorListener;
  private Vector mDescriptorListeners = new Vector();
  private transient final static String mSpaces = "                                                                                 ";
  private static char[] mCharBuffer = new char[256];




  public MMFDescriptor(String doctor, String speciality, String patientfirstname, String patientlastname, Date patientbirthdate, String subject, Date SentDate, byte status, long pos, int size) {
    mIndex = -1;
    mDoctor = doctor;
    mSpeciality = speciality;
    mPatientFirstName = patientfirstname;
    mPatientLastName = patientlastname;
    mSubject = subject;
    mSentDate = SentDate;
    mPatientBirthDate = patientbirthdate;
    if(mPatientBirthDate == null)
      throw new NullPointerException("Trying to pass a null pointer!");
    mStatus = status;
    mPos = pos;
    mSize = size;

  }

/*  public MMFDescriptor(String doctor, String speciality, String patientfirstname, String patientlastname, Date patientbirthdate, String subject, Date SentDate, byte status, long pos, int size) {
    mIndex = -1;
    mDoctor = doctor;
    mSpeciality = speciality;
    mPatientFirstName = patientfirstname;
    mPatientLastName = patientlastname;
    mSubject = subject;
//    mSentDateString = MMFMessage.getDateFormat().format(SentDate);
    mSentDate = SentDate;
    mPatientBirdthDate = patientbirthdate;
    mStatus = status;
    mPos = pos;
    mSize = size;

  }
*/
  public MMFDescriptor(MMF mmf, byte status, long pos) throws MessagingException {
    mIndex = -1;
    mDoctor = mmf.getDoctor();
    mSpeciality = mmf.getSpeciality();
    mPatientFirstName = mmf.getPatientFirstName();
    mPatientLastName = mmf.getPatientLastName();
    mSubject = mmf.getSubject();
    mSentDate = mmf.getSentDate();
    mPatientBirthDate = mmf.getPatientBirthDate();
    if(mPatientBirthDate == null)
      throw new NullPointerException("Trying to pass a null pointer!");
    mStatus = status;
    mPos = pos;
    mSize = mmf. getSize();

  }


  public MMFDescriptor (InputStream in, int index) throws IOException {
    DataInputStream dis = new DataInputStream(in);
    mStatus = dis.readByte();
    mPos = dis.readLong();
    mSize = dis.readInt();
    mPatientBirthDate = new Date(dis.readLong());
    mSentDate = new Date(dis.readLong());
    mIndex = index;
    BufferedReader sr = new BufferedReader(new InputStreamReader(in));
    mDoctor = readString(mDoctorLength,sr);
    mSpeciality = readString(mSpecialityLength,sr);
    mPatientFirstName = readString(mPatientFirstNameLength,sr);
    mPatientLastName = readString(mPatientLastNameLength,sr);
    mSubject = readString(mSubjectLength,sr);
//    mSentDate = readString(mSentDateStringLength,sr);
  }

  protected int getIndex() { return mIndex; }

  public void save(OutputStream os) throws IOException {
    DataOutputStream dos = new DataOutputStream(os);
    dos.writeByte(mStatus);
    dos.writeLong(mPos);
    dos.writeInt(mSize);
    dos.writeLong(mPatientBirthDate.getTime());
    dos.writeLong(mSentDate.getTime());
    dos.flush();
    BufferedWriter sw = new BufferedWriter(new OutputStreamWriter(os));
    writeString(mDoctorLength,mDoctor,sw);
    writeString(mSpecialityLength,mSpeciality,sw);
    writeString(mPatientFirstNameLength,mPatientFirstName,sw);
    writeString(mPatientLastNameLength,mPatientLastName,sw);
    writeString(mSubjectLength,mSubject,sw);
//    writeString(mSentDateStringLength,mSentDateString,sw);
    sw.flush();
  }

  private static char[] getCharBuffer(final int length) {
      if(length <= mCharBuffer.length)
        return(mCharBuffer);
      return(mCharBuffer = new char[length]);
  }

  private static String readString(final int length, BufferedReader sr) throws IOException {
    char[] charbuf = getCharBuffer(length);
    sr.read(charbuf,0,length);
    return((new String(charbuf)).trim());
  }

  private static void writeString(final int length, String s, BufferedWriter sr) throws IOException {
    if(s.length() >= length) {
      sr.write(s,0,length);
    } else {
      sr.write(s);
      sr.write(mSpaces,0,length - s.length());
    }
  }

  public final static int getSizeOfDescriptor() {
    return(1 + 8 +  4 + 8 + 8 +  mDoctorLength + mSpecialityLength + mPatientFirstNameLength + mPatientLastNameLength + mSubjectLength);
  }

  public int getSize() {
    return(mSize);
  }

  public String getDoctor() throws MessagingException {
    return mDoctor;
  }

  public String getSpeciality() throws MessagingException {
    return mSpeciality;
  }

  public String getPatientFirstName()  throws MessagingException {
    return mPatientFirstName;
  }

  public String getPatientLastName()  throws MessagingException {
    return mPatientLastName;
  }

  public java.util.Date getPatientBirthDate()  throws MessagingException {
    return mPatientBirthDate;
  }


  public String getSubject() throws MessagingException {
    return mSubject;
  }

  /*public long getPosition() {
    return mPos;
  }*/
  public long getPositionInDataFile() {
    return(mPos);
  }

  public byte getStatus() {
    return mStatus;
  }

  public int compareTo(Object o) {
    if(o instanceof MMFDescriptor) {
      return(getSentDate().compareTo(((MMFDescriptor)o).getSentDate()));
    } else if (o instanceof MMF) {
      try {
        return(getSentDate().compareTo(((MMF)o).getSentDate()));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return 0;

  }

  public Date getSentDate() {
    return mSentDate;
  }


  public boolean isRecent() {
    return((mStatus & RECENT) != 0);
  }

  public boolean isDeleted() {
    return((mStatus & DELETED) != 0);
  }

  public boolean hasBeenSeen() {
    return((mStatus & SEEN) != 0);
  }

  public void setDeleted(boolean b) {
    byte newstatus = mStatus;
    if(b)
      newstatus |= DELETED;
    else
      newstatus -= (mStatus & DELETED);

    if( newstatus != mStatus) {
      mStatus = newstatus;
      fireStatusHasChanged(this);
    }

  }

  public void setRecent(boolean b) {
    byte newstatus = mStatus;
    if(b)
      newstatus |= RECENT;
    else
      newstatus -= (mStatus & RECENT);
    if( newstatus != mStatus) {
      mStatus = newstatus;
      fireStatusHasChanged(this);
    }
  }

  public void setSeen(boolean b) {
    byte newstatus = mStatus;
    if(b)
      newstatus |= SEEN;
    else
      newstatus -= (mStatus & SEEN);
    if( newstatus != mStatus) {
      mStatus = newstatus;
      fireStatusHasChanged(this);
    }
  }


  public MMFMessage getMMFMessage() {
    return(mDescriptorListener.getMMFMessage(this));
  }



  public boolean addDescriptorListener(DescriptorListener dl) {
    return(mDescriptorListeners.add(dl));
  }

  public boolean removeDescriptorListener(DescriptorListener dl) {
    return(mDescriptorListeners.remove(dl));
  }

  public void fireStatusHasChanged(MMFDescriptor de) {
    Enumeration enum = mDescriptorListeners.elements();
    while(enum.hasMoreElements()) {
      DescriptorListener listener = (DescriptorListener) enum.nextElement();
      listener.statusHasChanged(de);
    }
  }

  public String toString() {
    if(mSpeciality != null) {
      if(mDoctor != null) {
        return(mSpeciality +" ("+mDoctor+")");
      } else
        return(mSpeciality);
    } else if (mPatientLastName != null) {
      if(mPatientFirstName != null)
        return (mPatientFirstName + " " + mPatientLastName);
      return(mPatientLastName);
    }
    return(super.toString());
  }

  public String toHTMLString() {
    if(mSpeciality != null) {
      if(mDoctor != null) {
          return("<html><b>"+mSpeciality +"</b> <i>("+mDoctor+")</i></html>");
      } else
          return("<html><b>"+mSpeciality +"</b></html>");

    } else if (mPatientLastName != null) {
      if(mPatientFirstName != null)
        return (mPatientFirstName + " " + mPatientLastName);
      return(mPatientLastName);
    }
    return(super.toString());
  }

}