
package com.emedicalgate.mmf;

public interface Status {
  public final byte NORMAL = 0;
  public final byte DELETED = 3;
  public final byte RECENT = 15;
  public final byte SEEN = 31;
}