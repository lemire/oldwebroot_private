

package com.emedicalgate.mmf;

import javax.mail.*;
import java.lang.ref.*;
import java.io.*;
import java.util.*;
import com.emedicalgate.io.*;
import com.emedicalgate.mmf.database.*;

public class MMFLocalFolder extends Folder implements MMFMessageProvider {

//  File mIndexFile;
//  File mDataFile;
  protected File mDirectory;
  protected FolderIndexFile mFolderIndexFile;
  private Flags mFlags;
  private MMFQuickFolder mMMFQuickFolder;

  public MMFLocalFolder(MMFLocalStore store,File dir) throws MessagingException, IOException {
    super(store);
    dir.mkdirs();
    if(!dir.isDirectory())
      throw new MessagingException("No such folder! A file was found instead");
    mDirectory = dir;
    mFlags = new Flags();
    mFolderIndexFile = new FolderIndexFile(this,new File(mDirectory,"mmf.idx"),new File(mDirectory,"mmf.ctt"));
  }

  public int getType() throws javax.mail.MessagingException {
    return(HOLDS_FOLDERS & HOLDS_MESSAGES);
  }

  public Flags getPermanentFlags() {
    return(mFlags);
  }

  public String getName() {
    return(mDirectory.getName());
  }

  public Message[] expunge() throws javax.mail.MessagingException {
     return(new Message[0]);
  }

  public void close(boolean b) throws javax.mail.MessagingException {
  }

  public boolean hasNewMessages() throws javax.mail.MessagingException {
    return(false);
  }

  public boolean renameTo(Folder f) throws javax.mail.MessagingException {
    boolean success = mDirectory.renameTo(new File(mDirectory.getParent(),f.getName()));
    if(success) {
      mFolderIndexFile.setDirectory(mDirectory);
      notifyFolderRenamedListeners(this) ;
    }
    return success;
  }

  public int getMessageCount() throws javax.mail.MessagingException {
    return(mFolderIndexFile.getNumberOfDescriptors());
  }

  /*
  * Ceci donne le MMFMessage (donc le truc lourd). Voir getMMF
  * pour une version "l�g�re".
  */
  public Message getMessage(int index) throws javax.mail.MessagingException {
    return(getMessage(getMMFDescriptor(index)));
  }
  public Message getMessage(MMFDescriptor desc) throws javax.mail.MessagingException {
    return(mFolderIndexFile.getMMFMessage(desc));
  }
  public MMFDescriptor getMMFDescriptor(int index) throws javax.mail.MessagingException {
    try {
      return(mFolderIndexFile.getDescriptor(index));
    } catch (IOException ioe) {
      throw new MessagingException(ioe.toString());
    }
  }

  public void appendMessages(Message[] m) throws javax.mail.MessagingException {

    try {
      //MMFDescriptor[] indexes = new MMFDescriptor[m.length];
      for(int k = 0; k < m.length; ++k) {
        System.out.println("Appending message number "+k);
        final int[] index = mFolderIndexFile.appendMessage((MMFMessage)m[k]);
        //indexes[k] = mFolderIndexFile.getDescriptor(index);
        for(int i = 0; i < index.length; ++i) {
          System.out.println("Got index "+index[i]);
          getMMFQuickFolderInstance().addIndex(index[i],false);
          System.out.println("Added to quick index! ");
        }
      }
      getMMFQuickFolderInstance().write();
   //   db.addMMFDescriptors(indexes);
    } catch(IOException ioe) {
     throw new MessagingException(ioe.toString());
    }
    notifyMessageAddedListeners(m);

  }
/*
  public void appendMessages(Message[] m) throws javax.mail.MessagingException {
    try {
      for(int k = 0; k < m.length; ++k) {
        System.out.println("Appending message number "+k);
        final int index = mFolderIndexFile.appendMessage((MMFMessage)m[k]);
        System.out.println("Got index "+index);
        getMMFQuickFolderInstance().addIndex(index,false);
        System.out.println("Added to quick index! ");
      }
      getMMFQuickFolderInstance().write();
    } catch(IOException ioe) {
     throw new MessagingException(ioe.toString());
    }
    notifyMessageAddedListeners(m);
  }
*/
  public void open(int i) throws javax.mail.MessagingException {
    /*
    * On est toujours ouvert.
    */
  }

  public boolean delete(boolean b) throws javax.mail.MessagingException {
    /*
    * On refuse d'effacer... pour des raisons de s�curit�
    */
    return(false);
  }


  public Folder[] list(String parm1) throws javax.mail.MessagingException {
    File[] files = mDirectory.listFiles(new FileFilter() {
      public boolean accept(File f) {return(f.isDirectory());}
    });
    Folder[] folders = new Folder[files.length];
    try {
    for(int k = 0; k < files.length; ++k) {
      folders[k] = new MMFLocalFolder((MMFLocalStore) getStore(),files[k]);
    }
    } catch (IOException ioe) {
      throw new MessagingException(ioe.toString());
    }
    return(folders);
  }

  public String getFullName() {
    return(mDirectory.getAbsolutePath());
  }

  public Folder getParent() throws javax.mail.MessagingException {
    if(this.mDirectory.equals( ((MMFLocalStore)getStore()).getStoreDirectory()))
      return(this);
    try {
      return(new MMFLocalFolder((MMFLocalStore)getStore(),mDirectory.getParentFile()));
    } catch(IOException ioe) {
      throw new MessagingException(ioe.toString());
    }
  }

  public boolean create(int i) throws javax.mail.MessagingException {
    return(true);
  }

  public char getSeparator() throws javax.mail.MessagingException {
    return(System.getProperty("file.separator").charAt(0));
  }

  public boolean exists() throws javax.mail.MessagingException {
    return(true);
  }

  public Folder getFolder(String name) throws javax.mail.MessagingException {
    try {
      return(new MMFLocalFolder((MMFLocalStore)getStore(),new File(((MMFLocalStore)getStore()).getStoreDirectory(),name)));
    } catch (IOException ioe) {
      throw new MessagingException(ioe.toString());
    }
  }

  public boolean isOpen() {
    return(true);
  }

  public MMFQuickFolder getMMFQuickFolderInstance() throws IOException {
    if(mMMFQuickFolder == null)
      mMMFQuickFolder = new MMFQuickFolder();
    return mMMFQuickFolder;
  }


/*
* Alors que MMFLocalFolder doit contenir un index de tous les messages,
* MMFQuickFolder est une impl�mentation qui vise � donner un acc�s
* rapide � un petit sous-ensemble de messages. Essentiellement, le QuickFolder
* n'est qu'un acc�s � un petit fichier binaire comprenant tout d'abord le nombre
* de messages dans le QuickFolder suivi d'un indice pour chaque message.
* Le fichier MMFQuickFolder peut donc �tre rapidement modifi�.
* Supposons donc que nous avons r�cup�r� des milliers de messages. Le
* MMFLocalFolder deviendra donc tr�s lourd, mais cet index demeurera
* rapide.
* Il est � noter qu'on pourrait avoir ajouter des "folders", par exemple "INBOX", etc.
* au lieu de cette classe. Cependant, il semble plus judicieux de faire ici un
* impl�mentation l�g�re en gardant derri�re un index g�ant. La gestion en sera
* facilit�.
*/
public class MMFQuickFolder implements MMFMessageProvider {

  File mFile;
  int mVersion;
  int mLength;
  private int mExtraBuffer = 64;
  int[] mIndex;

  /*
  * throws an exception if we can't read nor create the file!
  */
  private MMFQuickFolder() throws IOException {
    mFile = new File(mDirectory, "mmf.qck");
    try {
      read();
    } catch(FileNotFoundException fnfe) {
      try {
        mFile.createNewFile();
      } catch (IOException ioe ) {
        throw ioe;
      }
      defaultValues();
    } catch(Exception e) {
      e.printStackTrace();
      defaultValues();
    }
  }

  private void defaultValues() {
      mVersion = 1;
      mLength = 0;
      mIndex = new int[mExtraBuffer];
  }

  /*
  * return true if remove was succesful.
  */
  public boolean addIndex(int i, boolean write)  throws IOException {
      for (int k = 0; k < mLength; ++k)
        if(mIndex[k] == i)
          return false;
      if(mLength > mIndex.length) {
        mIndex[mLength++] = i;
      } else {
        int[] newindex = new int[mIndex.length + mExtraBuffer];
        System.arraycopy(mIndex,0,newindex,0,mLength);
        mIndex = newindex;
        mIndex[mLength++] = i;
      }
      if (write) write();
      return true;
  }

  /*
  * return true if remove was succesful.
  */
  public boolean removeIndexNumber(int i, boolean write)  throws IOException  {
    if(( i < 0 ) || (i >= mLength))
      return false;
    System.arraycopy(mIndex,i + 1, mIndex, i , mLength - i - 1);
    --mLength;
    if (write) write();
    return true;
  }

  public void dump() {
    StringBuffer sb = new StringBuffer("length = ");
    sb.append(mLength);
    sb.append(" ");
    for(int k = 0; k < mLength; ++k) {
          sb.append(mIndex[k]);
          sb.append(" ");

    }
    System.out.println(sb.toString());
  }

  public boolean removeIndex(int i, boolean write) throws IOException {
    for(int k = 0; k < mLength; ++k) {
      if(mIndex[k] == i) {
        removeIndexNumber(k,write);
        return true;
      }
    }
    return false;
  }

  public synchronized void read() throws IOException {
    DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(mFile)));
    if(dis.available() == 0) {
      defaultValues();
      dis.close();
      return;
    }
    try {
      mVersion = dis.readInt();
      mLength = dis.readInt();
      mIndex = new int[mLength + mExtraBuffer];
      for(int k = 0; k < mLength; ++k) {
        mIndex[k] = dis.readInt();
      }
    } finally {
      dis.close();
    }
  }

  public synchronized void write() throws IOException {
    DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(mFile)));
    try {
      dos.writeInt(mVersion);
      dos.writeInt(mLength);
      for(int k = 0; k < mLength; ++k ) {
        dos.writeInt(mIndex[k]);
      }
    } finally {
      dos.close();
    }
  }


  public int getMessageCount()  throws javax.mail.MessagingException {
    return(mLength);
  }

  public MMFDescriptor getMMFDescriptor(int i)  throws javax.mail.MessagingException {
    if((i < 0 ) || (i >= mLength))
      throw new javax.mail.MessagingException("Array index out of bounds "+i+" legal range = (0, "+(mLength - 1)+")");
    return(MMFLocalFolder.this.getMMFDescriptor(mIndex[i]));
  }

  public Message getMessage(int i)  throws javax.mail.MessagingException {
    if((i < 0 ) || (i >= mLength))
      throw new javax.mail.MessagingException("Array index out of bounds "+i+" legal range = (0, "+(mLength - 1)+")");
    return(MMFLocalFolder.this.getMessage(mIndex[i]));
  }
  public Message getMessage(MMFDescriptor mmfdesc)  throws javax.mail.MessagingException {
    return(MMFLocalFolder.this.getMessage(mmfdesc));
  }

  public MMFLocalFolder getMMFLocalFolder() {
    return(MMFLocalFolder.this);
  }

}



}






