

package com.emedicalgate.mmf;

import javax.mail.*;

public interface MMF {
  public String getDoctor() throws MessagingException;
  public String getSpeciality() throws MessagingException;
  public String getPatientFirstName()  throws MessagingException;
  public String getPatientLastName()  throws MessagingException;
  public java.util.Date getPatientBirthDate()  throws MessagingException;
  public String getSubject() throws MessagingException;
 // public String getSentDateString() throws MessagingException;
  public java.util.Date getSentDate() throws MessagingException;
  public int getSize() throws MessagingException;
}