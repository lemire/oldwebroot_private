package com.emedicalgate.mmf.database.CustomCalendar;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * @version 1.03 07/13/00
 * @author  Kai Toedter
 * @version 1.0
 *
 * Modified by Daniel Lemire
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
import java.text.*;
import javax.swing.*;
import javax.swing.border.*;


/**
 * JCalendar is a bean for choosing a day.
 *
 */
public class JDayChooser extends JPanel
{
   /**
    * Default JDayChooser constructor.
    */
   public JDayChooser()
   {
      locale = Locale.getDefault();
      days = new JLabel[49];
      selectedDay = null;
      Calendar calendar = Calendar.getInstance( locale );


      setLayout( new GridLayout( 7, 7, 0, 0 ) );

      for( int y=0; y<7; y++ )
      {
         for( int x=0; x<7; x++ )
         {
            int index = x + 7 * y;
            if( y == 0 )
            {

               // Create a button that does'nt react on clicks
               days[index] = new JLabel();/*new JButton() {

                  public void addMouseListener(MouseListener l) {}
               };*/
               days[index].setBackground( new Color( 200, 200, 255 ) );
                 days[index].setBorder(BorderFactory.createEtchedBorder());

            }
            else
            {
               days[index] = new JLabel("x");/*Button( "x" );*/
               days[index].setBorder(BorderFactory.createEtchedBorder());
/*               days[index].addActionListener( this );*/
            }

//            days[index].setMargin( new Insets( 0, 0, 0, 0 ) );
  //          days[index].setFocusPainted( false );
            add( days[ index ] );
         }
      }

      init();
      setDay( Calendar.getInstance().get( Calendar.DAY_OF_MONTH ) );
   }

   /**
    * Initilizes the locale specific names for the days of the week.
    */
   protected void init()
   {
      calendar = Calendar.getInstance( locale );
      int firstDayOfWeek = calendar.getFirstDayOfWeek();
      DateFormatSymbols dateFormatSymbols = new DateFormatSymbols( locale );
      dayNames = dateFormatSymbols.getShortWeekdays();
      int day = firstDayOfWeek;
      for( int i = 0 ; i<7; i++ )
      {
         days[i].setText( dayNames[day] );
         if( day == 1 )
            days[i].setForeground( Color.red );
         else
            days[i].setForeground( Color.blue );

         if( day < 7 )
            day++;
         else
            day -= 6;

      }
      oldDayBackground = (new JLabel()).getBackground();
      drawDays();
   }

   /**
    * Hides and shows the day buttons.
    */
   protected void drawDays()
   {
      Calendar tmpCalendar = (Calendar) calendar.clone();
      int firstDayOfWeek = tmpCalendar.getFirstDayOfWeek();
      tmpCalendar.set( Calendar.DAY_OF_MONTH, 1 );

      int firstDay = tmpCalendar.get( Calendar.DAY_OF_WEEK ) - firstDayOfWeek;
      if( firstDay < 0 )
         firstDay += 7;

      int i;

      for( i=0; i< firstDay; i++ )
      {
         days[ i+7 ].setVisible( false );
         days[ i+7 ].setText( "" );
      }

      tmpCalendar.add( Calendar.MONTH, 1 );
      Date firstDayInNextMonth = tmpCalendar.getTime();
      tmpCalendar.add( Calendar.MONTH, -1 );

      Date day = tmpCalendar.getTime();
      int n = 0;
      Color foreground = getForeground();
      while( day.before( firstDayInNextMonth ) )
      {
         days[i+n+7].setText( Integer.toString( n+1 ) );
         days[i+n+7].setVisible( true );
         if( tmpCalendar.get( Calendar.DAY_OF_YEAR ) == calendar.get( Calendar.DAY_OF_YEAR ) &&
             tmpCalendar.get( Calendar.YEAR ) == calendar.get( Calendar.YEAR ) )
         {
            days[i+n+7].setForeground( Color.red );
         }
         else
            days[i+n+7].setForeground( foreground );

       if( n+1 == calendar.get(Calendar.DAY_OF_MONTH) )
         {
            days[i+n+7].setBackground( Color.gray );
            selectedDay = days[i+n+7];
         }
        else
            days[i+n+7].setBackground( oldDayBackground );

         n++;
         tmpCalendar.add( Calendar.DATE, 1 );
         day = tmpCalendar.getTime();
      }

      for( int k=n+i+7; k<49; k++ )
      {
         days[k].setVisible( false );
         days[k].setText( "" );
      }
   }

   /**
    * Returns the locale.
    *
    * @see #setLocale
    */
   public Locale getLocale()
   {
      return locale;
   }

   /**
    * Sets the locale.
    *
    * @see #getLocale
    */
   public void setLocale( Locale l )
   {
      locale = l;
      init();
   }

   /**
    * Sets the day.
    * This is a bound property.
    *
    * @param d the day
    * @see #getDay
    */
   public void setDay( int d )
   {
      if( d < 1 )
         d = 1;

      Calendar tmpCalendar = (Calendar) calendar.clone();
      tmpCalendar.set( Calendar.DAY_OF_MONTH, 1 );
      tmpCalendar.add( Calendar.MONTH, 1 );
      tmpCalendar.add( Calendar.DATE, -1 );
      int maxDaysInMonth = tmpCalendar.get( Calendar.DATE );

      if( d > maxDaysInMonth )
         d = maxDaysInMonth;


      if( selectedDay != null )
      {
         selectedDay.setBackground( oldDayBackground );
         selectedDay.repaint(); // Bug: needed for Swing 1.0.3
      }

      for( int i=7; i<49; i++ )
      {
         if( days[i].getText().equals( Integer.toString( calendar.get(Calendar.DAY_OF_MONTH)) ))
         {
            selectedDay = days[i];
            selectedDay.setBackground( Color.gray );
            break;
         }
      }
//      firePropertyChange( "day", oldDay, day );
   }

   /**
    * Returns the selected day.
    *
    * @see #setDay
    */
   public int getDay()
   {
      return calendar.get(Calendar.DAY_OF_MONTH);
   }

   /**
    * Sets a specific month. This is needed for correct graphical
    * representation of the days.
    *
    * @param month the new month
    */
   public void setMonth( int month )
   {
      calendar.set( Calendar.MONTH, month );
//      setDay( day );
      drawDays();
   }

   /**
    * Sets a specific year. This is needed for correct graphical
    * representation of the days.
    *
    * @param year the new year
    */
   public void setYear( int year )
   {
      calendar.set( Calendar.YEAR, year );
      drawDays();
   }

   /**
    * Sets a specific calendar. This is needed for correct graphical
    * representation of the days.
    *
    * @param c the new calendar
    */
   public void setCalendar( Calendar c )
   {
      calendar = c;
      drawDays();
   }

   /**
    * Sets the font property.
    *
    * @param font the new font
    */
   public void setFont( Font font )
   {
      if( days != null )
      {
         for( int i=0; i<49; i++ )
            days[i].setFont( font );
      }
   }

   /**
    * Sets the foreground color.
    *
    * @param fg the new foreground
    */
   public void setForeground( Color fg)
   {
      super.setForeground( fg);
      if( days != null )
      {
         for( int i=7; i<49; i++ )
            days[i].setForeground( fg);
         drawDays();
      }
   }

   /**
    * Returns "JDayChooser".
    */
   public String getName()
   {
      return "JDayChooser";
   }



   /**
    * Creates a JFrame with a JDayChooser inside and can be used for testing.
    */
   static public void main( String[] s )
   {
      JFrame frame = new JFrame( "JDayChooser" );
      frame.getContentPane().add( new JDayChooser() );
      frame.pack();
      frame.setVisible( true );
   }

   public Dimension getPreferredSize() {
    return this.getMinimumSize();
   }

   public Dimension getMaximumSize() {
    return this.getMinimumSize();
   }

   private JLabel  days[];
   private JLabel  selectedDay;
   private Color    oldDayBackground;
   private String   dayNames[];
   private Calendar calendar;
   private Locale   locale;
}


