package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.emedicalgate.mmf.database.CustomCalendar.*;
import com.emedicalgate.mmf.*;
import java.util.*;
import java.text.*;
import javax.swing.event.*;
import com.emedicalgate.client.*;

public class SpecialityVSTimeComponent extends JPanel {
  private static Locale mCurrentLocale = new Locale("fr","FR","");
  public static DateFormat mDateFormat =  new SimpleDateFormat ("dd/MM/yyyy");
  Vector mVector = new Vector();
  JList mJList = new JList(mVector);
  JLabel mDateLabel = new JLabel();
  //String mDefaultSubject = "Aucun dossier pr�sent�";
  //JLabel mSubjectLabel = new JLabel(mDefaultSubject);
  JButton mLaunchButton = new JButton( "Consulter le dossier");
  //JDayChooser mDayChooser = new JDayChooser();
//  Calendar mCalendar = Calendar.getInstance();
  MMFMessageProvider mMMFMessageProvider;
  Dimension mDayChooserMinimumSize;


  public SpecialityVSTimeComponent() {
    setLayout(new BorderLayout());
    //mSubjectLabel.setEditable(false);
    //mSubjectLabel.setBackground(this.getBackground());
    mLaunchButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
             doubleClick(SpecialityVSTimeComponent.this.mJList.getSelectedIndex());
     }
    });

    mLaunchButton.setEnabled(false);
    mJList.setBorder(BorderFactory.createTitledBorder("Liste des dossiers correspondants"));
//    MiddlePanel.setLayout(new GridLayout(0,2));
    JPanel listpanel = new JPanel(new BorderLayout());
    listpanel.add(mLaunchButton,BorderLayout.SOUTH);
    listpanel.add(new JScrollPane(mJList),BorderLayout.CENTER);
    listpanel.add(mDateLabel,BorderLayout.NORTH);
    mJList.setBackground(this.getBackground());
    mJList.setCellRenderer(new IconListRenderer(new ImageIcon(SpecialityVSTimeComponent.class.getResource("/images/mime/text.gif"))));
    add(listpanel,BorderLayout.CENTER);
    mJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    mJList.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          mLaunchButton.setEnabled(true);
          show(SpecialityVSTimeComponent.this.mJList.getSelectedIndex());
        }
    });
  }

  public void setMMFDescriptors(Vector v) {
    mVector = v;
    mJList.setListData(mVector);
    if(mVector.size() > 0) {
      show(0);
      mJList.setSelectedIndex(0);
    } else {
      mLaunchButton.setEnabled(false);
    }
  }

  private void doubleClick(final int row) {
    if ( mMMFMessageProvider == null ) {
          JOptionPane.showMessageDialog(this,"Impossible d'affichier le dossier: pas de MMFMessageProvider." ,"Veuillez faire rapport de cette erreur",JOptionPane.ERROR_MESSAGE);
          return;
    }
    Thread run = new Thread(new Runnable() {
    public void run() {
        //mSubjectLabel.setText("Chargement du dossier...");
        mJList.setEnabled(false);
        mLaunchButton.setEnabled(false);
        try {
          MMFDescriptor mmfdesc = (MMFDescriptor) mVector.get(row);
          MMFMessage m = (MMFMessage) mMMFMessageProvider.getMessage(mmfdesc);
          //mSubjectLabel.setText("Chargement du dossier... ok... Traitement du dossier...");
          MMFMessageViewer Viewer = new MMFMessageViewer(m);
          //mSubjectLabel.setText("Traitement du dossier...ok... Affichage");
          try {
            FrameComponentWrapper fcw = new FrameComponentWrapper(Viewer,m.getSubject());
            fcw.setVisible(true);
          } catch (javax.mail.MessagingException me) {
            FrameComponentWrapper fcw = new FrameComponentWrapper(Viewer,me.toString());
            fcw.setVisible(true);
          } catch(Exception e) {
            BasicApplet.warn(e);
          }
          System.out.println("Creating frame...ok");
          //mSubjectLabel.setText(m.getSubject());
        } catch (javax.mail.MessagingException me) {
          MMFDatabasePanel.warn(me);
        }
        mJList.setEnabled(true);
        mLaunchButton.setEnabled(true);
        }
      });
      run.setPriority(Thread.MIN_PRIORITY);
      run.start();
  }

  private void show(final int row) {
    if (row < 0)
      return;
    if (row >= mVector.size())
      return;
    show((MMFDescriptor) mVector.get(row));
  }

  private void show(MMFDescriptor mmf) {
    try {
      mDateLabel.setText(mDateFormat.format(mmf.getSentDate()));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void setMMFMessageProvider (MMFMessageProvider provider) {
    mMMFMessageProvider = provider;
  }
}