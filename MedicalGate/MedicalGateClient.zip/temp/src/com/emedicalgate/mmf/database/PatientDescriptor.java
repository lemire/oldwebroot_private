package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

public class PatientDescriptor {
  String mFirstName, mLastName;
  java.sql.Timestamp mBirthDate;

  public PatientDescriptor(String FirstName, String LastName, java.sql.Timestamp BirthDate) {
    mFirstName  = FirstName;
    mLastName = LastName;
    mBirthDate = BirthDate;
  }

  public String getFirstName() {
    return mFirstName;
  }

  public String getLastName() {
    return mLastName;
  }

  public java.sql.Timestamp getBirthDate() {
    return mBirthDate;
  }

  public String toString() {
    if (mBirthDate != null)
      return (mFirstName+" "+mLastName+" ["+SpecialityVSTimeComponent.mDateFormat.format(mBirthDate)+"]");
    return (mFirstName+" "+mLastName);
  }
}