package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import com.emedicalgate.mmf.*;

public class MMFDatabasePanel extends JComponent implements ActionListener {

  static Object[] mCandidateListDefault = {new PatientDescriptor("Aucun candidat","",null)};
  Vector mCandidateVector = null;
  static String mName = "Panneau HypersonicSQL";



  MMFDatabaseManager mDatabaseManager;
  JList mCandidateList = new JList(mCandidateListDefault);
  JTextField mCandidateFirstNameField = new JTextField("");
  JTextField mCandidateLastNameField = new JTextField("");
  static java.util.Date mStartingDate;
  static {
    try {
      mStartingDate = DateDocument.mSimpleDateFormat.parse("01/01/1900");
    } catch (java.text.ParseException pe) {}
  }
  static java.util.Date mFinishingDate = new java.util.Date();
  JDateTextField mStartingDateField = new JDateTextField(mStartingDate);
  JDateTextField mFinishingDateField = new JDateTextField(mFinishingDate);
  JDateTextField mStartingBirthDateField = new JDateTextField(mStartingDate);
  JDateTextField mFinishingBirthDateField = new JDateTextField(mFinishingDate);
  JTextField mDoctorField = new JTextField("");
  JTextField mSubjectField = new JTextField("");
  JTextField mSpecialityField = new JTextField("");

  JLabel mSQLLabel = new JLabel("Hypersonic SQL");
  SpecialityVSTimeComponent mWhatHere = new SpecialityVSTimeComponent();
  JButton mOKButton = new JButton ("rechercher");
  Thread mLoadDB;

  public void loadDatabase( final File Databasedir, final String databasename) {
       Thread mLoadDB = new Thread(new Runnable() {
          public void run() {
            setEnabled(false);
            if(mDatabaseManager != null) {
              try {
                mDatabaseManager.closeConnection();
              } catch (java.sql.SQLException exception) {
                exception.printStackTrace();
              }
            }
            mDatabaseManager = new MMFDatabaseManager(Databasedir, databasename);
            setEnabled(true);

          }
        });
        mLoadDB.setPriority(Thread.MIN_PRIORITY);
        mLoadDB.start();
  }

  public void setEnabled(boolean enabled) {
    mOKButton.setEnabled(enabled);
    mCandidateFirstNameField.setEnabled(enabled);
    mCandidateLastNameField.setEnabled(enabled);
    if( enabled ) {
      if (mLoadDB != null) {
        try { mLoadDB.join(); } catch (java.lang.InterruptedException e) {e.printStackTrace();}
        mLoadDB = null;
      }
      mSQLLabel.setText("Base de donn�es Hypersonic SQL en fonction");
    }
    else
      mSQLLabel.setText("Base de donn�es Hypersonic SQL en chargement");
  }

  public MMFDatabasePanel( ) {
    setLayout(new BorderLayout());
    JPanel toppanel = new JPanel();
    toppanel.setLayout(new GridLayout(0,5));
    JLabel prenom = new JLabel("Pr�nom du patient:");
    prenom.setHorizontalAlignment(JLabel.RIGHT);
    toppanel.add(prenom);
    toppanel.add(mCandidateFirstNameField);
    JLabel nom = new JLabel("Nom du patient:");
    nom.setHorizontalAlignment(JLabel.RIGHT);
    toppanel.add(nom);
    toppanel.add(mCandidateLastNameField);
    toppanel.add(mOKButton);
    //
    toppanel.add(new JLabel("Date du dossier:"));
    JLabel de = new JLabel("de");
    de.setHorizontalAlignment(JLabel.CENTER);
    toppanel.add(de);
    toppanel.add(mStartingDateField);
    JLabel a = new JLabel("�");
    a.setHorizontalAlignment(JLabel.CENTER);
    toppanel.add(a);
    toppanel.add(mFinishingDateField );
    //
    toppanel.add(new JLabel("Date de naissance:"));
    JLabel denaiss = new JLabel("de");
    denaiss.setHorizontalAlignment(JLabel.CENTER);
    toppanel.add(denaiss);
    toppanel.add(mStartingBirthDateField);
    JLabel anaiss = new JLabel("�");
    anaiss.setHorizontalAlignment(JLabel.CENTER);
    toppanel.add(anaiss);
    toppanel.add(mFinishingBirthDateField );
    //
    JLabel doctor = new JLabel("Nom du m�decin:");
    doctor.setHorizontalAlignment(JLabel.RIGHT);
    toppanel.add(doctor);
    toppanel.add(mDoctorField);
    JLabel speciality = new JLabel("Sp�cialit�:");
    speciality.setHorizontalAlignment(JLabel.RIGHT);
    toppanel.add(speciality);
    toppanel.add(mSpecialityField);
    toppanel.add(new JLabel());
    //
    JLabel subject = new JLabel("Sujet:");
    subject.setHorizontalAlignment(JLabel.RIGHT);
    toppanel.add(subject);
    toppanel.add(mSubjectField);

    toppanel.setBorder(BorderFactory.createRaisedBevelBorder());
    add(new JScrollPane(toppanel),BorderLayout.NORTH);
    add(mSQLLabel,BorderLayout.SOUTH);

    JSplitPane splitPane = new JSplitPane (JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(mCandidateList), mWhatHere);
    splitPane.setOneTouchExpandable(true);
    //splitPane.setDividerLocation(120);
    add(splitPane,BorderLayout.CENTER);
    mCandidateList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    mCandidateList.setCellRenderer(new DatabaseListRenderer());
    mCandidateList.setBackground(this.getBackground());
    //mCandidateList.setBorder(BorderFactory.createTitledBorder("Patients"));
    mCandidateFirstNameField.setToolTipText("Entrez le pr�nom d'un patient");
    mCandidateLastNameField.setToolTipText("Entrez le nom d'un patient");
    mCandidateList.setToolTipText("Vous voyez ici une liste des patients correspondants � votre recherche");
    mSQLLabel.setToolTipText("Ce logiciel utilise le moteur de base de donn�es Hypersonic.");
    mStartingDateField.setToolTipText("Entre la date d'examen min.");
    mFinishingDateField.setToolTipText("Entrez la date d'examen max.");
    mStartingBirthDateField.setToolTipText("Entrez la date de naissance min.");
    mFinishingBirthDateField.setToolTipText("Entrez la date de naissance max.");
    mDoctorField.setToolTipText("Entrez le nom du m�decin");
    mSpecialityField.setToolTipText("Entrez la sp�cialit� recherch�e");
    mSubjectField.setToolTipText("Entrez le sujet de l'examen");
    mCandidateFirstNameField.addActionListener(this);
    mCandidateLastNameField.addActionListener(this);
    mOKButton.addActionListener(this);
    mStartingDateField.addActionListener(this);
    mFinishingDateField.addActionListener(this);
    mStartingBirthDateField.addActionListener(this);
    mFinishingBirthDateField.addActionListener(this);
    mDoctorField.addActionListener(this);
    mSpecialityField.addActionListener(this);
    mSubjectField.addActionListener(this);
    mCandidateList.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          show(MMFDatabasePanel.this.mCandidateList.getSelectedIndex());
        }
    });
    setEnabled(false);
  }

  public void actionPerformed(ActionEvent e) {
    MMFSearch search = new MMFSearch();
    search.setFirstName(mCandidateFirstNameField.getText());
    search.setLastName(mCandidateLastNameField.getText());
    search.setStartingDate(mStartingDateField.getDate());
    search.setFinishingDate(mFinishingDateField.getDate());
    search.setStartingBirthDate(mStartingBirthDateField.getDate());
    search.setFinishingBirthDateField(mFinishingBirthDateField.getDate());
    search.setDoctor(mDoctorField.getText());
    search.setSpeciality(mSpecialityField.getText());
    search.setSubject(mSubjectField.getText());
    updateList(search);
   }

  public void show(final int row) {
    try {
      if (mCandidateVector != null) {
        if ((row < mCandidateVector.size()) && (row >= 0))
          show((PatientDescriptor)mCandidateVector.get(row));
        else if (mCandidateVector.size() > 0)
          show((PatientDescriptor)mCandidateVector.get(0));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void show(PatientDescriptor patient) {
    if (mDatabaseManager == null) {
      if ( mLoadDB != null) {
        try { mLoadDB.join(); } catch (java.lang.InterruptedException e) {e.printStackTrace();}
        if (mDatabaseManager == null) {
          System.out.println("L'initialisation de la base de donn�e a �chou�e!");
        }
      } else {
        System.out.println("La base de donn�e n'a pas encore �t� initialis�e!");
        return;
      }
    }
    try {
      mWhatHere.setMMFDescriptors(mDatabaseManager.getMMFDescriptorsFromPatient(patient));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void updateList(MMFSearch search) {
    if (mDatabaseManager == null) {
      if ( mLoadDB != null) {
        try { mLoadDB.join(); } catch (java.lang.InterruptedException e) {e.printStackTrace();}
        if (mDatabaseManager == null) {
          System.out.println("L'initialisation de la base de donn�e a �chou�e!");
        }
      } else {
        System.out.println("La base de donn�e n'a pas encore �t� initialis�e!");
        return;
      }
    }
    Vector ans = null;
    try {
      ans = mDatabaseManager.getCandidates(search);
    } catch (SQLException e) {
      warn(e,"Erreur lors de la recherche de patients candidats");
      return;
    }
    if( ans == null)
      mCandidateList.setListData(mCandidateListDefault);
    else if (ans.size() == 0)
      mCandidateList.setListData(mCandidateListDefault);
    else {
      mCandidateVector = ans;
      mCandidateList.setListData(mCandidateVector);
    }
  }


  public static void warn (Exception e) {
    warn(e,"Une erreur inattendue est survenue avec la base de donn�es.");
  }

  public static void warn (Exception e, String s) {
    StringWriter sos = new StringWriter();
    PrintWriter pw = new PrintWriter(sos);
    e.printStackTrace(pw);
    BufferedReader br = new BufferedReader(new StringReader(sos.toString()));
    StringBuffer sb = new StringBuffer();
    sb.append("<html><b>");
    sb.append(s);
    sb.append("</b>");
    String line = null;
    try {
      while ( ( line = br.readLine() ) != null) {
        sb.append("<br>");
        sb.append(line.trim());

      }
    } catch (IOException ioe) {}
    sb.append("</html>");
    JEditorPane pane = new JEditorPane();
    pane.setContentType("text/html");
    pane.setEditable(false);
    pane.setText(sb.toString());
    JScrollPane scrollpane = new JScrollPane(pane);
    scrollpane.setMinimumSize(new Dimension(384,200));
    scrollpane.setPreferredSize(scrollpane.getMinimumSize());
    JOptionPane.showMessageDialog(null,scrollpane ,mName,JOptionPane.WARNING_MESSAGE);
  }

  public void setMMFMessageProvider (MMFMessageProvider provider) {
    mWhatHere.setMMFMessageProvider(provider);
  }
  public boolean addMMFDescriptor(MMFDescriptor descriptor) {
    if (mDatabaseManager == null) {
      if ( mLoadDB != null) {
        try { mLoadDB.join(); } catch (java.lang.InterruptedException e) {e.printStackTrace();}
        if (mDatabaseManager == null) {
          System.out.println("L'initialisation de la base de donn�e a �chou�e!");
        }
      } else {
        System.out.println("La base de donn�e n'a pas encore �t� initialis�e!");
        return false;
      }
    }
    return mDatabaseManager.addMMFDescriptor(descriptor);
  }
  public boolean addMMFDescriptors(MMFDescriptor[] descriptors) {
    if (mDatabaseManager == null) {
      if ( mLoadDB != null) {
        try { mLoadDB.join(); } catch (java.lang.InterruptedException e) {e.printStackTrace();}
        if (mDatabaseManager == null) {
          System.out.println("L'initialisation de la base de donn�e a �chou�e!");
        }
      } else {
        System.out.println("La base de donn�e n'a pas encore �t� initialis�e!");
        return false;
      }
    }
    return mDatabaseManager.addMMFDescriptors(descriptors);
  }
  public void dispose() {
    if( mLoadDB != null)
      try {mLoadDB.join();} catch (java.lang.InterruptedException e) {e.printStackTrace();}
    if( mDatabaseManager != null) {
       try {
         mDatabaseManager.closeConnection();
       } catch (java.sql.SQLException exception) {
          exception.printStackTrace();
       }
    }
  }


}