package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import javax.swing.*;
import java.util.*;
import javax.swing.text.*;

public class JDateTextField extends JTextField {

  private Date mDefaultDate;
  private DateDocument mDateDocument;

  public JDateTextField(Date DefaultDate) {
    super(10);
    mDefaultDate = DefaultDate;
    mDateDocument = new DateDocument(this, mDefaultDate);
    this.setDocument(mDateDocument);
  }


  public Date getDate() {
    try {
      return mDateDocument.getDate();
    } catch (java.text.ParseException pe) {
      pe.printStackTrace();
      mDateDocument.setDate(mDefaultDate);
      return mDefaultDate;
    }
  }


}