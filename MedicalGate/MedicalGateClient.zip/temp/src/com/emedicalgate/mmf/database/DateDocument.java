package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */

import javax.swing.*;
import java.util.*;
import java.text.*;
import javax.swing.text.*;

public class DateDocument extends PlainDocument {

  public static String initstring = "JJ/MM/AAAA";
  private static int sep1 = 2, sep2 = 5;
  private JTextComponent textComponent;
  private int newOffset;
  protected static SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat ("dd/MM/yyyy");

  public DateDocument(JTextComponent tc, Date DefaultDate) {
    textComponent = tc;
    setDate(DefaultDate);
  }

  public void setDate(Date date) {
    initstring = mSimpleDateFormat.format(date);
    try {
      insertString(0, initstring, null);
    } catch (Exception ex) {}
  }

  public void insertString (int offset, String s, AttributeSet attributeSet) throws javax.swing.text.BadLocationException {
    if( s.equals(initstring) ) {
      super.insertString(offset, s, attributeSet);
    } else {
      if (offset >= initstring.length()) {
        return;
      }
      try {
        Integer.parseInt(s);
      } catch (Exception ex) {
        return;
      }
      newOffset = offset;
      if(atSeparator(offset)) {
        newOffset++;
        textComponent.setCaretPosition(newOffset);
      }
      super.remove(newOffset, 1);
      super.insertString(newOffset,s,attributeSet);
    }
  }

  public void remove(int offset, int length) {
    if (atSeparator(offset))
      textComponent.setCaretPosition(offset - 1);
    else
      textComponent.setCaretPosition(offset);
  }

  private boolean atSeparator(int offset) {
    return offset == sep1 || offset == sep2;
  }

  protected Date getDate() throws java.text.ParseException {
    return mSimpleDateFormat.parse(textComponent.getText());
  }
  public static Date parse(String text) throws java.text.ParseException {
    return mSimpleDateFormat.parse(text);
  }

}