package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import com.emedicalgate.mmf.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import javax.swing.*;

public class MMFDatabaseManager {

  private static Locale mCurrentLocale = new Locale("fr","FR","");
  private static DateFormat mDateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,mCurrentLocale);
  private File mDatabaseDir, mDatabaseLocator;
  private String mDatabaseName;
  private static String mCreateTable = "CREATE TABLE MMFDescriptor10 (Doctor varchar_ignorecase(32),Speciality varchar_ignorecase(32),PatientFirstName varchar_ignorecase(32),PatientLastName varchar_ignorecase(32),PatientBirthDate TIMESTAMP,Subject varchar_ignorecase(80),Date TIMESTAMP, Status TINYINT, Position BIGINT, Size INT)";
  private static String mInsert = "INSERT INTO MMFDescriptor10 VALUES (";
  private static String sampledata[]= {
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bo','v�t�','Daniel', 'LaMire','1940-02-25 20:05:35.000', 'prise de sang','2001-02-25 20:05:35.000',0,0,10)",
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bodo','v�t�','Herv�', 'Barge','1940-02-25 20:05:35.000', 'prise de sang(2)','2001-04-25 20:05:35.000',0,10,10)",
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bopa','v�t�ri','�tienne', 'Mille','1940-02-25 20:05:35.000', 'prise de sang(3)','2001-05-25 20:05:35.000',0,20,10)",
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bopa','v�t�ri','Herv�', 'Barge','1920-02-25 20:05:35.000', 'prise de sang(3)','2001-05-25 20:05:35.000',0,30,10)",
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bopa','v�t�ri','Herv�', 'Math','1940-02-25 20:05:35.000', 'prise de sang(3)','2001-05-25 20:05:35.000',0,40,10)",
    "INSERT INTO MMFDescriptor10 VALUES ('Ti-bopa','v�t�ri','Herv�', 'Bert','1940-02-25 20:05:35.000', 'prise de sang(3)','2001-05-25 20:05:35.000',0,50,10)"};
  private Connection mConnection;
  private boolean busy = false;

  public synchronized Connection getConnection() {
      if(busy)
        try {
          wait();
        } catch (InterruptedException ie ) {
          return(getConnection());
        }
      busy = true;
      return mConnection;
  }

  public synchronized void doneWithConnection() {
        busy = false;
        notify();
  }

  public void closeConnection() throws SQLException {
    mConnection.commit();
    mConnection.close();
  }

  /*
  * On s'assure que la casse est correcte (bug windows!)
  */


  public MMFDatabaseManager( File Databasedir, String DatabaseName) {
    mDatabaseName = DatabaseName;
    /*
    * On s'assure d'avoir un r�pertoire "database" o� nous
    * mettrons la base.
    */

    mDatabaseDir = Databasedir;
    mDatabaseDir.mkdirs();
    mDatabaseLocator = new File(mDatabaseDir, DatabaseName);
    try {
      Class.forName("org.hsql.jdbcDriver");

      mConnection = DriverManager.getConnection(
        "jdbc:HypersonicSQL:"+mDatabaseLocator.getCanonicalPath(),"SA",""
      );
      mConnection.setAutoCommit(true);
    } catch (Exception e) {
      e.printStackTrace();
    }
    // on s'assure ensuite que la table existe bel et bien
    try {
      Statement stat = mConnection.createStatement();
      stat.executeQuery(mCreateTable);
    } catch (Exception e) {}

  }


  private void storeSampleData() {
    Connection conn = getConnection();
    try {
      try {
        Statement stat = conn.createStatement();
        try {
          for(int k = 0; k < sampledata.length;  ++k ) {
            try {
              stat.executeQuery(sampledata[k]);
            } catch (SQLException e) {
              System.out.println(e.toString());
            }
          }
        } finally {
          stat.close();
        }
      } catch (SQLException es) {
        es.printStackTrace();
      }
    } finally {
        doneWithConnection();
    }

  }

  private boolean addMMFDescriptor(Connection conn, MMFDescriptor descriptor) {
    StringBuffer sb = new StringBuffer(mInsert);
    sb.append('\'');
    try {
      sb.append(descriptor.getDoctor());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getSpeciality());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getPatientFirstName());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getPatientLastName());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append((new Timestamp(descriptor.getPatientBirthDate().getTime())).toString());
    } catch (Exception e) {
      e.printStackTrace();
    }

    sb.append("','");
    try {
      sb.append(descriptor.getSubject());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append((new Timestamp(descriptor.getSentDate().getTime())).toString());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getStatus());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getPositionInDataFile());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("','");
    try {
      sb.append(descriptor.getSize());
    } catch (Exception e) {
      e.printStackTrace();
    }
    sb.append("')");
//'Ti-bo','v�t�','Daniel LaMire', 'prise de sang','2001-02-25 20:05:35.000',0,0,10)",
    boolean added = false;
      try {
        Statement stat = conn.createStatement();
        try {
//          for(int k = 0; k < sampledata.length;  ++k ) {

              System.out.println(sb.toString());
              stat.executeQuery(sb.toString());
              added = true;
        } catch (SQLException e) {
           System.out.println(e.toString());
  //        }
        } finally {
          stat.close();
        }
      } catch (SQLException es) {
        es.printStackTrace();
      }
    return added;

}

  /*
  * Return true if remove was succesful.
  * You have to check the return value!!!
  */
  public boolean addMMFDescriptor(MMFDescriptor descriptor) {
    Connection conn = getConnection();
    boolean added = false;
    try {
      added = addMMFDescriptor(conn, descriptor);
    } finally {
      //conn.commit();
      doneWithConnection();
    }
    return added;
  }



  public boolean addMMFDescriptors(MMFDescriptor[] descriptors) {
    System.out.println("Adding "+descriptors.length+" descriptors.");
    boolean added = true;
    Connection conn = getConnection();
    try {
      //try { conn.setAutoCommit(false); } catch (java.sql.SQLException e) { e.printStackTrace(); }

      try {
        for (int k = 0 ; k < descriptors.length ; ++k) {
          System.out.println("Adding "+k + " out of "+descriptors.length+" descriptors.");
          if ( !addMMFDescriptor(conn, descriptors[k]) )
            added = false;
        }
      } finally {
        try { conn.commit(); } catch (java.sql.SQLException e) { e.printStackTrace(); }
        //try { conn.setAutoCommit(true); } catch (java.sql.SQLException e) { e.printStackTrace(); }
      }
    } finally {
      this.doneWithConnection();
    }
    return added;

  }

  public Vector getMMFDescriptorsFromPatient(PatientDescriptor pd) throws SQLException {
    System.out.println("getMMFDescriptorsFromPatient");
    System.out.println("On r�cup�re du patient : "+pd.toString());
    Vector ans = new Vector();
    try {
      Statement stat = getConnection().createStatement();
      try {
        ResultSet rs = null;
        if ( (pd.getLastName().length() == 0) && (pd.getBirthDate() == null) ) {
          System.out.println("Patient null!");
          rs = stat.executeQuery("SELECT * FROM MMFDESCRIPTOR10 ORDER BY Date");// lorsqu'il n'y a pas un patient de s�lectionn�
        } else {
          rs = stat.executeQuery("SELECT * FROM MMFDESCRIPTOR10 WHERE PatientFirstName IS '"+ pd.getFirstName()+"' INTERSECT SELECT * FROM MMFDESCRIPTOR10 WHERE PatientLastName IS '"+ pd.getLastName()+"' INTERSECT  SELECT * FROM MMFDESCRIPTOR10 WHERE PatientBirthDate IS '"+ pd.getBirthDate().toString()+"' ORDER BY Date");
        }
        System.out.println("R�sultat de la recherche...");
        System.out.println(rs.toString());
        while(rs.next())
          ans.add(convertToMMFDescriptor(rs));
      } finally {
        stat.close();
      }
    } finally {
      doneWithConnection();
    }
    return(ans);
  }

  private MMFDescriptor convertToMMFDescriptor(final ResultSet rs) throws SQLException {
    final String Doctor = rs.getString(1);
    System.out.println("Doctor:"+Doctor);
    final String Speciality = rs.getString(2);
    System.out.println("Speciality:"+Speciality);
    final String PatientFirstName = rs.getString(3);
    System.out.println("PatientFirstName:"+PatientFirstName);
    final String PatientLastName = rs.getString(4);
    System.out.println("PatientLastName:"+PatientLastName);
    final Timestamp PatientBirthDate = rs.getTimestamp(5);
    final String Subject = rs.getString(6);
    System.out.println("Subject:"+Subject);
    final Timestamp SentDate = rs.getTimestamp(7);
    final byte Status = rs.getByte(8);
    final long Pos = rs.getLong(9);
    System.out.println("Pos:"+Pos);
    final int Size = rs.getInt(10);
    System.out.println("Size:"+Size);
    return(new MMFDescriptor(Doctor,Speciality,PatientFirstName, PatientLastName, PatientBirthDate,Subject,SentDate,Status,Pos,Size));
  }

  public Vector getCandidates(MMFSearch search) throws SQLException {
    Vector ans = new Vector();
    Connection conn = getConnection();
    try {
      Statement stat = conn.createStatement();
      try {
        StringBuffer sb = new StringBuffer("SELECT PatientFirstName, PatientLastName, PatientBirthDate FROM MMFDescriptor10 ");
        sb.append(search.getSQLString());
        sb.append(" GROUP BY PatientFirstName, PatientLastName, PatientBirthDate");
        ResultSet rs = stat.executeQuery( sb.toString() );
        while(rs.next())
          if(rs.getString(1) != null)
            ans.add(new PatientDescriptor(rs.getString(1),rs.getString(2),rs.getTimestamp(3)));
      } finally {
        stat.close();
      }

    } finally {
      doneWithConnection();
    }
    return ans;
  }

  private void displayTable() throws SQLException {
    Connection conn = getConnection();
    try {
      Statement stat = conn.createStatement();
      DatabaseMetaData dbmd = conn.getMetaData();
      System.out.println("product name = "+dbmd.getDatabaseProductName());
      System.out.println("product version = "+dbmd.getDatabaseProductVersion());
      ResultSet rs = null;
      try {
        rs = stat.executeQuery("SELECT * FROM MMFDESCRIPTOR10 WHERE PatientLastName LIKE '%Barge%' ORDER BY Date");
        if( rs != null) {
          System.out.println("Something in the result set!");
          ResultSetMetaData rsmd = rs.getMetaData();
          System.out.println("Nombre de colonnes = " + rsmd.getColumnCount());
          for(int k = 1; k <= rsmd.getColumnCount(); ++k) {
            try {
              System.out.print(rsmd.getColumnName(k)+" (");
              System.out.print(rsmd.getColumnTypeName(k)+") ");
            } catch (NullPointerException npe) {}
          }
          System.out.println();
          while (rs.next()) {
            for(int k = 1; k <= 4; ++k) {
              System.out.print(rs.getString(k)+" ");
            }
            System.out.print(mDateFormat.format(rs.getTimestamp("Date")));
            System.out.println();
          }
        } else {
          System.out.println("null result set!");
        }
      } catch (SQLException e) {
        e.printStackTrace();
      } finally {
        stat.close();
      }
    } finally {
      doneWithConnection();
    }
  }

  public static void main(String[] arg) throws SQLException {
    System.out.println(System.getProperty("java.vendor"));
    System.out.println(System.getProperty("java.version"));
    System.out.println(System.getProperty("java.home"));
    File UserHome = new File(System.getProperty("user.home"));
    File MGDir = new File(UserHome,"MedicalGate");
    MGDir.mkdirs();
    File PimmsDir = new File(MGDir,"Pimmms");
    PimmsDir.mkdirs();
    File DatabaseDir = new File(PimmsDir,"Database");
    MMFDatabaseManager db = new MMFDatabaseManager(DatabaseDir, "test");
    try {
      try {
        db.storeSampleData();
        db.displayTable();
      } finally {
        JFrame frame = new JFrame();
        MMFDatabasePanel dbpane = new MMFDatabasePanel();
        frame.getContentPane().add( dbpane );
        frame.setSize(640,480);
        frame.setVisible(true);
        dbpane.loadDatabase(DatabaseDir,"test");
      }
    } finally {
      db.closeConnection();
    }
  }

}