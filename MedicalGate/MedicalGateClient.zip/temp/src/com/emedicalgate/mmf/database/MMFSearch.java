package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import java.util.*;
import java.sql.Timestamp;
public class MMFSearch {

  String mFirstName, mLastName, mDoctor, mSpeciality, mSubject;
  java.sql.Timestamp mStartingDate, mFinishingDate, mStartingBirthDate, mFinishingBirthDate;

  public MMFSearch() {
  }


  public void setFirstName(String s) {
    mFirstName = s;
  }

  public void setLastName(String s) {
    mLastName = s;
  }

  public void setStartingDate(Date d) {
    if (d != null) mStartingDate = new java.sql.Timestamp(d.getTime());
  }

  public void setFinishingDate(Date d) {
    if (d != null) mFinishingDate = new java.sql.Timestamp(d.getTime());
  }

  public void setStartingBirthDate(Date d) {
    if (d != null) mStartingBirthDate = new java.sql.Timestamp(d.getTime());
  }

  public void setFinishingBirthDateField(Date d) {
    if (d != null) mFinishingBirthDate = new java.sql.Timestamp(d.getTime());
  }

  public void setDoctor(String s) {
    mDoctor = s;
  }

  public void setSpeciality(String s) {
    mSpeciality = s;
  }

  public void setSubject(String s) {
    mSubject = s;
  }


  public String getSQLString() {
    // on v�rifie d'abord s'il y a une requ�te � faire!
    if( mFirstName== null && mLastName == null && mDoctor == null && mSpeciality == null && mSubject == null
      && mStartingDate == null && mFinishingDate == null && mStartingBirthDate == null && mFinishingBirthDate == null) {
      return "";
    }
    // ok, on construit la requ�te
    StringBuffer sb = new StringBuffer(" WHERE ");
    boolean first = true;
    if(mLastName != null) {
      sb.append(" PatientLastName LIKE '%");
      sb.append(mLastName);
      sb.append("%' ");
      first = false;
    }
    if( mFirstName != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" PatientFirstName LIKE '%");
      sb.append(mFirstName);
      sb.append("%' ");
    }
    if( mDoctor != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" Doctor LIKE '%");
      sb.append(mDoctor);
      sb.append("%' ");
    }
    if( mSpeciality  != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" Speciality LIKE '%");
      sb.append(mSpeciality );
      sb.append("%' ");
    }
    if( mSubject != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" Subject LIKE '%");
      sb.append(mSubject);
      sb.append("%' ");
    }
    if( mStartingDate != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" Date >= '");
      sb.append( mStartingDate.toString() );
      sb.append("' ");
    }
    if( mFinishingDate != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" Date <= '");
      sb.append( mFinishingDate.toString() );
      sb.append("' ");
    }
    if( mStartingBirthDate != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" PatientBirthDate >= '");
      sb.append( mStartingBirthDate.toString() );
      sb.append("' ");
    }
    if( mFinishingBirthDate != null) {
      if(first) {
        first = false;
      } else {
        sb.append(" AND ");
      }
      sb.append(" PatientBirthDate <= '");
      sb.append( mFinishingBirthDate.toString() );
      sb.append("' ");
    }
    return sb.toString();
  }
}