package com.emedicalgate.mmf.database;

/**
 * Title:        M�dical Gate Java client
 * Description:  Un client SMTP/MIME �crit en Java pour la transmission de
 * dossiers m�dicaux avec int�gration Web.
 * Copyright:    Copyright (c) M�dical Gate
 * Company:      M�dical Gate
 * @author M�dical Gate
 * @version 1.0
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class DatabaseListRenderer extends DefaultListCellRenderer implements ListCellRenderer
{
  private Border SelectedBorder = BorderFactory.createLoweredBevelBorder();
  private Border UnselectedBorder = BorderFactory.createRaisedBevelBorder();

  public DatabaseListRenderer() {
    setOpaque(true);
  }
  public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {

//        setComponentOrientation(list.getComponentOrientation());

	if (isSelected) {
	    setBackground(list.getSelectionBackground());
	    setForeground(list.getSelectionForeground());
	}
	else {
	    setBackground(list.getBackground());
	    setForeground(list.getForeground());
	}

	/*if (value instanceof Icon) {
	    setIcon((Icon)value);
	    setText("");
	}
	else {
	    setIcon(null);
	    setText((value == null) ? "" : value.toString());
	}*/
         setText((value == null) ? "" : value.toString());

	setEnabled(list.isEnabled());
	setFont(list.getFont());
//	setBorder((cellHasFocus) ? UIManager.getBorder("List.focusCellHighlightBorder") : noFocusBorder);


        if(cellHasFocus) {
          setBorder(SelectedBorder);
        } else {
          setBorder(UnselectedBorder);
        }

    return this;
  }
}