
package com.emedicalgate.mmf;

import javax.mail.*;
import java.io.*;
import java.util.*;

public class MMFLocalStore extends Store {

  private File mStoreDir;

  public MMFLocalStore(Session session, URLName name) {
    super(session, name);
    File UserHome = new File(System.getProperty("user.home"));
    File MGDir = new File(UserHome,"MedicalGate");
    MGDir.mkdirs();
    File PimmsDir = new File(MGDir,"Pimmms");
    PimmsDir.mkdirs();
    File StoreDir = new File(PimmsDir,"Stores");
    StoreDir.mkdirs();
    File UserNameDir = new File(StoreDir,name.getUsername().toLowerCase());
    // on fait maintenant un truc compliqu� pour s'assurer que la casse
    // du r�pertoire est modifi�e au besoin pour �tre en minuscules!
    File[] usersdir = StoreDir.listFiles();
    for(int k = 0; k < usersdir.length;++k) {
      System.out.println(usersdir[k].getName()+" ==? "+name.getUsername().toLowerCase());
      if(usersdir[k].equals(UserNameDir)) {
        System.out.println("Il existe d�j� un "+name.getUsername().toLowerCase());
        if (!usersdir[k].getName().equals(name.getUsername().toLowerCase())) {
          if(usersdir[k].renameTo(UserNameDir)) {
            System.out.println("J'ai pu renommer avec succ�s vers "+UserNameDir.getPath());
          } else {
            System.out.println("Je n'ai pu renommer vers "+UserNameDir.getPath());
          }
        }
        break;
      }
    }
    UserNameDir.mkdirs();
    File ProtocolDir = new File(UserNameDir, name.getProtocol());
    ProtocolDir.mkdirs();
    File RefDir = new File(ProtocolDir,name.getHost());
    RefDir.mkdirs();
    mStoreDir = new File(RefDir,"Local");
    File InboxDir = new File(mStoreDir,"inbox");
    InboxDir.mkdirs();
  }



  public File getStoreDirectory() {
    return(mStoreDir);
  }

  public Folder getFolder(URLName name) throws javax.mail.MessagingException {
    try {
      return(new MMFLocalFolder(this,new File(mStoreDir,name.getFile().toLowerCase())));
    } catch(IOException ioe) {
      ioe.printStackTrace();
      throw new javax.mail.MessagingException(ioe.toString());
    }

  }

  public Folder getDefaultFolder() throws javax.mail.MessagingException {
    //TODO: implement this javax.mail.Store abstract method
    try {
      return(new MMFLocalFolder(this,mStoreDir));
    } catch(IOException ioe) {
      ioe.printStackTrace();
      throw new javax.mail.MessagingException(ioe.toString());
    }
  }


  public Folder getFolder(String name) throws javax.mail.MessagingException {
    try {
      return(new MMFLocalFolder(this,new File(mStoreDir,name.toLowerCase())));
    } catch(IOException ioe) {
      ioe.printStackTrace();
      throw new javax.mail.MessagingException(ioe.toString());
    }
  }
}