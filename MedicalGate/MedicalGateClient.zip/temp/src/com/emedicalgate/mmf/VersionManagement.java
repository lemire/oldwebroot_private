
package com.emedicalgate.mmf;

public interface VersionManagement {

  public String MMFLibraryName = "Medical Gate MMF Java library (c) 2000 Daniel Lemire";
  public int MMFLibraryMajorVersion = 1;
  public int MMFLibraryMinorVersion = 0;
}