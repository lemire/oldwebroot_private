socksify java -cp .:../libraries/activation.jar:../libraries/imap.jar:../libraries/mail.jar:../librairies/pop3.jar:../libraries/smtp.jar  com.emedicalgate.client.BasicApplet
