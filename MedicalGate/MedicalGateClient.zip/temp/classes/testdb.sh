java -cp .:../libraries/hsql.jar:../libraries/activation.jar:../libraries/mail.jar:../libraries/jaxp.jar:../librairies/crimson.jar:../libraries/xalan.jar com.emedicalgate.mmf.database.MMFDatabaseManager


